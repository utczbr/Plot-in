#!/usr/bin/env python3
"""
LYLAA Hyperparameter Tuning System
==================================

A gradient-based hyperparameter optimization system for the LYLAA spatial classification
implementation. This system uses error propagation to automatically find optimal scoring
parameters based on ground truth data from generator.py.

Technical Implementation:
- 24 optimizable parameters across Gaussian kernels, region weights, and thresholds
- Differentiable scoring functions for gradient computation
- Cross-entropy loss with softmax for multi-class classification
- Adam optimizer with parameter constraints for stability
- Early stopping and training history tracking

Based on DARTS-style differentiable architecture search principles adapted for
computer vision parameter optimization.

Author: Expert Computer Vision Engineer
Date: October 2024
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, List, Tuple, Any, Optional
import json
from pathlib import Path
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LYLAAHypertuner(nn.Module):
    """
    Hyperparameter tuning system for LYLAA spatial classification using gradient-based optimization.
    
    This system implements error propagation for automatic parameter optimization based on
    classification accuracy against ground truth labels from generator.py.
    
    Key Features:
    - 24 optimizable parameters with automatic differentiation
    - Differentiable Gaussian kernels and scoring functions
    - Parameter constraints for numerical stability
    - Cross-entropy loss for multi-class classification
    - GPU/CPU compatibility
    """
    
    def __init__(self, device: str = 'cpu', learning_rate: float = 0.01):
        super().__init__()
        self.device = device
        
        # Initialize optimizable parameters as PyTorch tensors
        self.params = nn.ParameterDict({
            # Gaussian kernel parameters - control region probability smoothness
            'sigma_x': nn.Parameter(torch.tensor(0.09, dtype=torch.float32)),
            'sigma_y': nn.Parameter(torch.tensor(0.09, dtype=torch.float32)),
            
            # Region weights - importance of different spatial zones
            'left_y_axis_weight': nn.Parameter(torch.tensor(5.0, dtype=torch.float32)),
            'right_y_axis_weight': nn.Parameter(torch.tensor(4.0, dtype=torch.float32)),
            'bottom_x_axis_weight': nn.Parameter(torch.tensor(5.0, dtype=torch.float32)),
            'top_title_weight': nn.Parameter(torch.tensor(4.0, dtype=torch.float32)),
            'center_data_weight': nn.Parameter(torch.tensor(2.0, dtype=torch.float32)),
            
            # Feature weights - multi-criteria scoring parameters
            'size_constraint_primary': nn.Parameter(torch.tensor(3.0, dtype=torch.float32)),
            'size_constraint_secondary': nn.Parameter(torch.tensor(2.5, dtype=torch.float32)),
            'aspect_ratio_weight': nn.Parameter(torch.tensor(2.5, dtype=torch.float32)),
            'position_weight_primary': nn.Parameter(torch.tensor(5.0, dtype=torch.float32)),
            'position_weight_secondary': nn.Parameter(torch.tensor(4.0, dtype=torch.float32)),
            'distance_weight': nn.Parameter(torch.tensor(2.0, dtype=torch.float32)),
            'context_weight_primary': nn.Parameter(torch.tensor(4.0, dtype=torch.float32)),
            'context_weight_secondary': nn.Parameter(torch.tensor(5.0, dtype=torch.float32)),
            'ocr_numeric_boost': nn.Parameter(torch.tensor(2.0, dtype=torch.float32)),
            'ocr_numeric_penalty': nn.Parameter(torch.tensor(1.0, dtype=torch.float32)),
            
            # Clustering parameters
            'eps_factor': nn.Parameter(torch.tensor(0.12, dtype=torch.float32)),
            
            # Classification thresholds
            'classification_threshold': nn.Parameter(torch.tensor(1.5, dtype=torch.float32)),
            'size_threshold_width': nn.Parameter(torch.tensor(0.08, dtype=torch.float32)),
            'size_threshold_height': nn.Parameter(torch.tensor(0.04, dtype=torch.float32)),
            'aspect_ratio_min': nn.Parameter(torch.tensor(0.5, dtype=torch.float32)),
            'aspect_ratio_max': nn.Parameter(torch.tensor(3.5, dtype=torch.float32)),
        })
        
        # Parameter constraints to ensure valid ranges during optimization
        self.param_constraints = {
            'sigma_x': (0.01, 0.5),
            'sigma_y': (0.01, 0.5),
            'left_y_axis_weight': (0.1, 10.0),
            'right_y_axis_weight': (0.1, 10.0),
            'bottom_x_axis_weight': (0.1, 10.0),
            'top_title_weight': (0.1, 10.0),
            'center_data_weight': (0.1, 10.0),
            'size_constraint_primary': (0.1, 10.0),
            'size_constraint_secondary': (0.1, 10.0),
            'aspect_ratio_weight': (0.1, 10.0),
            'position_weight_primary': (0.1, 10.0),
            'position_weight_secondary': (0.1, 10.0),
            'distance_weight': (0.1, 10.0),
            'context_weight_primary': (0.1, 10.0),
            'context_weight_secondary': (0.1, 10.0),
            'ocr_numeric_boost': (0.1, 10.0),
            'ocr_numeric_penalty': (0.1, 10.0),
            'eps_factor': (0.01, 0.5),
            'classification_threshold': (0.1, 5.0),
            'size_threshold_width': (0.01, 0.5),
            'size_threshold_height': (0.01, 0.5),
            'aspect_ratio_min': (0.1, 2.0),
            'aspect_ratio_max': (1.5, 10.0),
        }
        
        # Move to device
        self.to(device)
        
        # Initialize optimizer - Adam with adaptive learning rates
        self.optimizer = optim.Adam(self.parameters(), lr=learning_rate)
        
        # Training history for analysis and visualization
        self.history = {
            'losses': [],
            'accuracies': [],
            'parameters': [],
            'parameter_gradients': []
        }
        
        logger.info(f"LYLAAHypertuner initialized with {len(self.params)} parameters on {device}")
    
    def constrain_parameters(self):
        """Apply constraints to parameters to ensure valid ranges during training"""
        with torch.no_grad():
            for name, param in self.params.items():
                if name in self.param_constraints:
                    min_val, max_val = self.param_constraints[name]
                    param.data.clamp_(min_val, max_val)
    
    def get_current_params_dict(self) -> Dict[str, float]:
        """Get current parameter values as a dictionary for analysis"""
        return {name: param.item() for name, param in self.params.items()}
    
    def get_parameter_gradients(self) -> Dict[str, float]:
        """Get current parameter gradients for gradient analysis"""
        gradients = {}
        for name, param in self.params.items():
            if param.grad is not None:
                gradients[name] = param.grad.item()
            else:
                gradients[name] = 0.0
        return gradients
    
    def differentiable_gaussian_score(self, nx: torch.Tensor, ny: torch.Tensor, 
                                    center_x: float, center_y: float) -> torch.Tensor:
        """
        Compute Gaussian kernel score in a differentiable manner
        
        This replaces the original numpy-based Gaussian computation with
        a differentiable PyTorch implementation for gradient flow.
        """
        dx = (nx - center_x) / self.params['sigma_x']
        dy = (ny - center_y) / self.params['sigma_y']
        return torch.exp(-(dx**2 + dy**2) / 2)
    
    def differentiable_region_scores(self, normalized_pos: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Compute region probability scores in a differentiable manner
        
        Implements the LYLAA octant region scoring with differentiable operations
        for gradient-based optimization.
        """
        nx, ny = normalized_pos[0], normalized_pos[1]
        
        scores = {}
        
        # Left Y-axis region: x < 0.20, 0.1 < y < 0.9
        left_mask = (nx < 0.20) & (ny > 0.1) & (ny < 0.9)
        scores['left_y_axis'] = torch.where(
            left_mask,
            self.differentiable_gaussian_score(nx, ny, 0.08, 0.5) * self.params['left_y_axis_weight'],
            torch.tensor(0.0, device=self.device)
        )
        
        # Right Y-axis region: x > 0.80, 0.1 < y < 0.9  
        right_mask = (nx > 0.80) & (ny > 0.1) & (ny < 0.9)
        scores['right_y_axis'] = torch.where(
            right_mask,
            self.differentiable_gaussian_score(nx, ny, 0.92, 0.5) * self.params['right_y_axis_weight'],
            torch.tensor(0.0, device=self.device)
        )
        
        # Bottom X-axis region: 0.15 < x < 0.85, y > 0.80
        bottom_mask = (nx > 0.15) & (nx < 0.85) & (ny > 0.80)
        scores['bottom_x_axis'] = torch.where(
            bottom_mask,
            self.differentiable_gaussian_score(nx, ny, 0.5, 0.92) * self.params['bottom_x_axis_weight'],
            torch.tensor(0.0, device=self.device)
        )
        
        # Top title region: 0.15 < x < 0.85, y < 0.15
        top_mask = (nx > 0.15) & (nx < 0.85) & (ny < 0.15)
        scores['top_title'] = torch.where(
            top_mask,
            self.differentiable_gaussian_score(nx, ny, 0.5, 0.08) * self.params['top_title_weight'],
            torch.tensor(0.0, device=self.device)
        )
        
        # Center data region: 0.2 < x < 0.8, 0.2 < y < 0.8
        center_mask = (nx > 0.2) & (nx < 0.8) & (ny > 0.2) & (ny < 0.8)
        center_dist = torch.sqrt((nx - 0.5)**2 + (ny - 0.5)**2)
        scores['center_data'] = torch.where(
            center_mask,
            torch.exp(-center_dist**2 / 0.08) * self.params['center_data_weight'],
            torch.tensor(0.0, device=self.device)
        )
        
        return scores
    
    def differentiable_multi_feature_scores(self, features: Dict[str, torch.Tensor], 
                                          region_scores: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        Compute multi-feature classification scores in a differentiable manner
        
        Implements the LYLAA multi-criteria scoring system with differentiable
        operations for each feature type.
        """
        rel_width = features['rel_width']
        rel_height = features['rel_height']
        aspect_ratio = features['aspect_ratio']
        nx, ny = features['nx'], features['ny']
        
        scores = {
            'scale_label': torch.tensor(0.0, device=self.device),
            'tick_label': torch.tensor(0.0, device=self.device),
            'axis_title': torch.tensor(0.0, device=self.device)
        }
        
        # Size constraints for scale labels (small labels are typically scale values)
        size_mask = (rel_width < self.params['size_threshold_width']) & (rel_height < self.params['size_threshold_height'])
        scores['scale_label'] += torch.where(size_mask, self.params['size_constraint_primary'], torch.tensor(0.0, device=self.device))
        
        # Aspect ratio constraints for scale labels (reasonable text proportions)
        aspect_mask = (aspect_ratio > self.params['aspect_ratio_min']) & (aspect_ratio < self.params['aspect_ratio_max'])
        scores['scale_label'] += torch.where(aspect_mask, self.params['aspect_ratio_weight'], torch.tensor(0.0, device=self.device))
        
        # Position-based scoring (left/right axis positions favor scale labels)
        left_right_max = torch.max(region_scores['left_y_axis'], region_scores['right_y_axis'])
        scores['scale_label'] += left_right_max * self.params['position_weight_primary']
        
        # Distance from center (peripheral labels are more likely to be scales)
        center_dist = torch.sqrt((nx - 0.5)**2 + (ny - 0.5)**2)
        distance_bonus = torch.where(center_dist > 0.3, (center_dist - 0.3) * self.params['distance_weight'], torch.tensor(0.0, device=self.device))
        scores['scale_label'] += distance_bonus
        
        # Title detection based on extreme aspect ratios (very wide or tall)
        title_mask = (aspect_ratio > 4.0) | (aspect_ratio < 0.25)
        scores['axis_title'] += torch.where(title_mask, self.params['context_weight_primary'], torch.tensor(0.0, device=self.device))
        
        # Large size indicates potential title
        large_size_mask = (rel_width > 0.15) | (rel_height > 0.08)
        scores['axis_title'] += torch.where(large_size_mask, self.params['context_weight_secondary'], torch.tensor(0.0, device=self.device))
        
        # Bottom region scoring for tick labels (categories often appear at bottom)
        scores['tick_label'] += region_scores['bottom_x_axis'] * self.params['position_weight_secondary']
        
        return scores
    
    def forward(self, label_features: Dict[str, Any]) -> torch.Tensor:
        """
        Forward pass: classify a single label in a differentiable manner
        
        Args:
            label_features: Dictionary containing normalized position, size, aspect ratio, etc.
            
        Returns:
            torch.Tensor with shape [3] representing [scale_label, tick_label, axis_title] logits
        """
        # Convert features to tensors for differentiation
        nx = torch.tensor(label_features['normalized_pos'][0], device=self.device, dtype=torch.float32)
        ny = torch.tensor(label_features['normalized_pos'][1], device=self.device, dtype=torch.float32)
        rel_width = torch.tensor(label_features['relative_size'][0], device=self.device, dtype=torch.float32)
        rel_height = torch.tensor(label_features['relative_size'][1], device=self.device, dtype=torch.float32)
        aspect_ratio = torch.tensor(label_features['aspect_ratio'], device=self.device, dtype=torch.float32)
        
        # Compute region scores using differentiable Gaussian kernels
        region_scores = self.differentiable_region_scores(torch.stack([nx, ny]))
        
        # Prepare features for multi-feature scoring
        features = {
            'nx': nx, 'ny': ny,
            'rel_width': rel_width, 'rel_height': rel_height,
            'aspect_ratio': aspect_ratio
        }
        
        # Compute classification scores using differentiable operations
        class_scores = self.differentiable_multi_feature_scores(features, region_scores)
        
        # Convert to logits tensor for loss computation
        logits = torch.stack([
            class_scores['scale_label'],
            class_scores['tick_label'], 
            class_scores['axis_title']
        ])
        
        # Apply threshold-based decision with differentiable approximation
        max_score = torch.max(logits)
        
        # Use sigmoid to make threshold decision differentiable
        threshold_weight = torch.sigmoid(10 * (max_score - self.params['classification_threshold']))
        
        # Enhanced logits based on threshold
        enhanced_logits = logits * threshold_weight
        
        # If below threshold, boost scale_label (default classification)
        default_boost = torch.tensor([2.0, 0.0, 0.0], device=self.device)
        final_logits = enhanced_logits + (1 - threshold_weight) * default_boost
        
        return final_logits
    
    def compute_loss(self, predictions: List[torch.Tensor], ground_truth: List[int]) -> torch.Tensor:
        """
        Compute cross-entropy loss between predictions and ground truth
        
        Args:
            predictions: List of logit tensors from forward pass
            ground_truth: List of integer class labels (0=scale, 1=tick, 2=title)
            
        Returns:
            Cross-entropy loss tensor for backpropagation
        """
        # Stack all predictions into a batch
        pred_tensor = torch.stack(predictions)  # Shape: [N, 3]
        gt_tensor = torch.tensor(ground_truth, device=self.device, dtype=torch.long)
        
        # Cross-entropy loss with softmax
        loss = nn.functional.cross_entropy(pred_tensor, gt_tensor)
        
        return loss
    
    def compute_accuracy(self, predictions: List[torch.Tensor], ground_truth: List[int]) -> float:
        """
        Compute classification accuracy for monitoring training progress
        """
        with torch.no_grad():
            pred_classes = [torch.argmax(pred).item() for pred in predictions]
            correct = sum(1 for p, g in zip(pred_classes, ground_truth) if p == g)
            return correct / len(ground_truth) if len(ground_truth) > 0 else 0.0


class LYLAATrainer:
    """
    Training orchestrator that integrates the hypertuner with generator.py data
    
    This class handles:
    - Loading ground truth data from generator.py outputs
    - Training loop with backpropagation and parameter updates
    - Early stopping and convergence monitoring
    - Result saving and analysis
    """
    
    def __init__(self, hypertuner: LYLAAHypertuner, generator_output_dir: str):
        self.hypertuner = hypertuner
        self.generator_output_dir = Path(generator_output_dir)
        logger.info(f"LYLAATrainer initialized with data from {generator_output_dir}")
        
    def load_training_data(self) -> Tuple[List[Dict], List[int]]:
        """
        Load ground truth data from generator.py outputs
        
        Returns:
            Tuple of (feature_list, ground_truth_labels)
        """
        training_data = []
        ground_truth_labels = []
        
        labels_dir = self.generator_output_dir / 'labels'
        
        if not labels_dir.exists():
            logger.error(f"Labels directory not found: {labels_dir}")
            return [], []
        
        # Process all detailed annotation files from generator.py
        for detailed_file in labels_dir.glob('*_detailed.json'):
            try:
                with open(detailed_file, 'r') as f:
                    data = json.load(f)
                
                # Extract axis labels with their ground truth classifications
                for label_type in ['scale_labels', 'tick_labels', 'axis_title']:
                    labels = data.get(label_type, [])
                    for label in labels:
                        if 'xyxy' in label:
                            # Convert to the format expected by our classifier
                            xyxy = label['xyxy']
                            
                            # Get image dimensions (assuming standard size or from metadata)
                            img_width = 800  # Can be extracted from metadata if available
                            img_height = 600
                            
                            # Calculate normalized features
                            cx = (xyxy[0] + xyxy[2]) / 2
                            cy = (xyxy[1] + xyxy[3]) / 2
                            width = xyxy[2] - xyxy[0]
                            height = xyxy[3] - xyxy[1]
                            
                            features = {
                                'normalized_pos': (cx / img_width, cy / img_height),
                                'relative_size': (width / img_width, height / img_height),
                                'aspect_ratio': width / (height + 1e-6),
                                'area': width * height,
                                'centroid': (cx, cy),
                                'bbox': xyxy,
                                'dimensions': (width, height)
                            }
                            
                            training_data.append(features)
                            
                            # Ground truth mapping: 0=scale_label, 1=tick_label, 2=axis_title
                            if label_type == 'scale_labels':
                                ground_truth_labels.append(0)
                            elif label_type == 'tick_labels':
                                ground_truth_labels.append(1)
                            else:  # axis_title
                                ground_truth_labels.append(2)
                                
            except Exception as e:
                logger.warning(f"Error processing {detailed_file}: {e}")
                continue
        
        logger.info(f"Loaded {len(training_data)} training samples")
        return training_data, ground_truth_labels
    
    def train_epoch(self, training_data: List[Dict], ground_truth: List[int]) -> Tuple[float, float]:
        """
        Train for one epoch with backpropagation
        
        Args:
            training_data: List of feature dictionaries
            ground_truth: List of integer class labels
            
        Returns:
            Tuple of (loss, accuracy) for this epoch
        """
        self.hypertuner.optimizer.zero_grad()
        
        # Forward pass through all training samples
        predictions = []
        for features in training_data:
            pred_logits = self.hypertuner(features)
            predictions.append(pred_logits)
        
        # Compute loss for backpropagation
        loss = self.hypertuner.compute_loss(predictions, ground_truth)
        
        # Backward pass - compute gradients
        loss.backward()
        
        # Store gradient information for analysis
        gradients = self.hypertuner.get_parameter_gradients()
        self.hypertuner.history['parameter_gradients'].append(gradients)
        
        # Update parameters using optimizer
        self.hypertuner.optimizer.step()
        
        # Apply parameter constraints to maintain valid ranges
        self.hypertuner.constrain_parameters()
        
        # Compute accuracy for monitoring
        accuracy = self.hypertuner.compute_accuracy(predictions, ground_truth)
        
        return loss.item(), accuracy
    
    def train(self, epochs: int = 100, patience: int = 15, min_improvement: float = 1e-6) -> Dict[str, Any]:
        """
        Full training loop with early stopping and convergence monitoring
        
        Args:
            epochs: Maximum number of training epochs
            patience: Number of epochs to wait for improvement before stopping
            min_improvement: Minimum improvement threshold for early stopping
            
        Returns:
            Dictionary containing optimal parameters and training results
        """
        logger.info("Loading training data...")
        training_data, ground_truth = self.load_training_data()
        
        if len(training_data) == 0:
            logger.error("No training data found! Make sure generator.py has been run.")
            return {}
        
        logger.info(f"Starting hyperparameter optimization with {len(training_data)} samples...")
        
        best_loss = float('inf')
        best_accuracy = 0.0
        patience_counter = 0
        
        for epoch in range(epochs):
            loss, accuracy = self.train_epoch(training_data, ground_truth)
            
            # Store training history
            self.hypertuner.history['losses'].append(loss)
            self.hypertuner.history['accuracies'].append(accuracy)
            self.hypertuner.history['parameters'].append(
                self.hypertuner.get_current_params_dict().copy()
            )
            
            # Print progress
            if epoch % 10 == 0 or epoch == epochs - 1:
                logger.info(f"Epoch {epoch:3d}: Loss = {loss:.6f}, Accuracy = {accuracy:.4f}")
                
                # Print current parameter values periodically
                if epoch % 50 == 0:
                    params = self.hypertuner.get_current_params_dict()
                    logger.info("Current key parameters:")
                    key_params = ['sigma_x', 'sigma_y', 'classification_threshold', 
                                'position_weight_primary', 'size_constraint_primary']
                    for name in key_params:
                        if name in params:
                            logger.info(f"  {name}: {params[name]:.4f}")
            
            # Early stopping based on loss improvement
            if loss < best_loss - min_improvement:
                best_loss = loss
                best_accuracy = accuracy
                patience_counter = 0
            else:
                patience_counter += 1
                
            if patience_counter >= patience:
                logger.info(f"Early stopping at epoch {epoch} (no improvement for {patience} epochs)")
                break
        
        # Training completed
        final_params = self.hypertuner.get_current_params_dict()
        logger.info("Training completed!")
        logger.info(f"Final loss: {loss:.6f}")
        logger.info(f"Final accuracy: {accuracy:.4f}")
        logger.info(f"Best accuracy achieved: {best_accuracy:.4f}")
        
        # Prepare results
        results = {
            'optimal_parameters': final_params,
            'best_loss': best_loss,
            'best_accuracy': best_accuracy,
            'final_loss': loss,
            'final_accuracy': accuracy,
            'epochs_trained': epoch + 1,
            'training_history': self.hypertuner.history,
            'total_samples': len(training_data)
        }
        
        return results
    
    def save_results(self, results: Dict[str, Any], filename: str = 'lylaa_hypertuning_results.json'):
        """Save training results to file"""
        try:
            with open(filename, 'w') as f:
                json.dump(results, f, indent=2)
            logger.info(f"Results saved to {filename}")
        except Exception as e:
            logger.error(f"Error saving results: {e}")


def run_hypertuning_experiment(generator_output_dir: str = "test_generation", 
                              epochs: int = 200, 
                              learning_rate: float = 0.01,
                              device: str = None) -> Dict[str, Any]:
    """
    Main function to run the LYLAA hyperparameter tuning experiment
    
    Args:
        generator_output_dir: Directory containing generator.py outputs
        epochs: Maximum training epochs
        learning_rate: Adam optimizer learning rate
        device: 'cpu', 'cuda', or None (auto-detect)
        
    Returns:
        Dictionary containing optimization results
    """
    # Auto-detect device if not specified
    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    logger.info(f"Starting LYLAA hypertuning experiment on {device}")
    logger.info(f"Generator data directory: {generator_output_dir}")
    logger.info(f"Max epochs: {epochs}, Learning rate: {learning_rate}")
    
    # Initialize hypertuner
    hypertuner = LYLAAHypertuner(device=device, learning_rate=learning_rate)
    
    # Initialize trainer
    trainer = LYLAATrainer(hypertuner, generator_output_dir)
    
    # Run training
    try:
        results = trainer.train(epochs=epochs, patience=20)
        
        if results:
            # Save results
            trainer.save_results(results, 'lylaa_hypertuning_results.json')
            
            # Print summary
            logger.info("\n" + "="*50)
            logger.info("HYPERTUNING EXPERIMENT COMPLETED")
            logger.info("="*50)
            logger.info(f"Best accuracy: {results['best_accuracy']:.4f}")
            logger.info(f"Final accuracy: {results['final_accuracy']:.4f}")
            logger.info(f"Epochs trained: {results['epochs_trained']}")
            logger.info(f"Total samples: {results['total_samples']}")
            logger.info("Optimal parameters saved to 'lylaa_hypertuning_results.json'")
            
            return results
        else:
            logger.error("Training failed - no results generated")
            return {}
            
    except Exception as e:
        logger.error(f"Training failed with error: {e}")
        return {}


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="LYLAA Hyperparameter Tuning System")
    parser.add_argument('--data-dir', type=str, default='test_generation',
                        help='Directory containing generator.py outputs')
    parser.add_argument('--epochs', type=int, default=200,
                        help='Maximum training epochs')
    parser.add_argument('--lr', type=float, default=0.01,
                        help='Learning rate for Adam optimizer')
    parser.add_argument('--device', type=str, choices=['cpu', 'cuda'], default=None,
                        help='Device to use (auto-detect if not specified)')
    
    args = parser.parse_args()
    
    # Run the experiment
    results = run_hypertuning_experiment(
        generator_output_dir=args.data_dir,
        epochs=args.epochs,
        learning_rate=args.lr,
        device=args.device
    )
    
    if results:
        print(f"\nOptimal parameters found with {results['best_accuracy']:.4f} accuracy")
    else:
        print("Hypertuning experiment failed")