import matplotlib
from matplotlib import patches, rcParams, transforms, colormaps
import matplotlib.pyplot as plt
import numpy as np
import random
from matplotlib.colors import ListedColormap
from matplotlib import colormaps
from scipy import stats
from themes import THEMES, SCIENTIFIC_Y_LABELS, BUSINESS_Y_LABELS, SCIENTIFIC_X_LABELS, BUSINESS_X_LABELS, COMPARATIVE_LABELS, HISTOGRAM_Y_LABELS

# ===================================================================================
# == DATA GENERATION & THEMES ==
# ===================================================================================

def generate_realistic_data(num_points, max_scale, allow_negative=False, pattern_type=None, domain='scientific'):
    """
    Generate statistically realistic data based on real-world scientific and business patterns.
    
    Critical improvements:
    - Domain-specific parameter constraints based on published literature
    - Heteroscedastic noise models matching measurement error characteristics
    - Realistic coefficient of variation (CV) ranges for biological systems
    - Enforced monotonicity and physical plausibility constraints
    - Measurement precision limitations
    """
    
    if pattern_type is None:
        # Weight patterns by actual frequency in scientific literature
        if domain == 'scientific':
            pattern_type = np.random.choice(
                ['dose_response', 'replicates', 'exponential_decay', 'power_law', 
                 'sigmoid_growth', 'linear_regression', 'gaussian_peak', 'enzyme_kinetics'],
                p=[0.25, 0.20, 0.15, 0.10, 0.10, 0.10, 0.05, 0.05]
            )
        else:  # business
            pattern_type = np.random.choice(
                ['seasonal_trend', 'pareto_distribution', 'exponential_growth', 
                 'market_saturation', 'random_walk_drift', 'step_intervention'],
                p=[0.30, 0.25, 0.15, 0.15, 0.10, 0.05]
            )
    
    data = np.zeros(num_points)
    
    # === SCIENTIFIC PATTERNS WITH REALISTIC CONSTRAINTS ===
    if pattern_type == 'dose_response':
        # Hill equation with literature-validated parameter ranges
        log_conc = np.linspace(-10, -3, num_points)  # pM to mM range (realistic drug concentrations)
        
        # Realistic EC50 values from drug databases (ChEMBL, PubChem)
        ec50 = np.random.uniform(-8.5, -4.5)  # 3nM to 30µM range
        
        # Hill slopes from literature (rarely exceed 4, typically 0.7-2.5)
        hill_slope = np.random.choice([
            np.random.uniform(0.7, 1.3),   # 60% - physiological range
            np.random.uniform(1.3, 2.0),   # 30% - cooperative binding
            np.random.uniform(2.0, 3.5)    # 10% - strong cooperativity
        ], p=[0.6, 0.3, 0.1])
        
        # Realistic baseline and maximum response
        baseline = np.random.uniform(0, 0.08) * max_scale  # 0-8% baseline activity
        max_response = np.random.uniform(0.85, 0.98) * max_scale  # 85-98% max response
        
        # Hill equation
        data = baseline + (max_response - baseline) / (1 + 10**((ec50 - log_conc) * hill_slope))
        
        # Heteroscedastic noise: CV increases at curve inflection points
        response_fraction = (data - baseline) / (max_response - baseline)
        cv = 0.05 + 0.10 * np.sqrt(response_fraction * (1 - response_fraction))
        noise = np.random.normal(0, data * cv, num_points)
        data += noise
        
        # Enforce non-negativity for biological measurements
        data = np.clip(data, 0, max_response * 1.05)
    
    elif pattern_type == 'replicates':
        # Biological replicates with realistic technical variation
        mean_val = np.random.uniform(0.25, 0.75) * max_scale
        
        # CV based on measurement type (qPCR: 5-15%, Western: 10-25%, Cell assays: 15-35%)
        measurement_type = np.random.choice(['qpcr', 'western', 'cell_assay'], p=[0.3, 0.3, 0.4])
        cv_ranges = {
            'qpcr': (0.05, 0.15),
            'western': (0.10, 0.25), 
            'cell_assay': (0.15, 0.35)
        }
        cv = np.random.uniform(*cv_ranges[measurement_type])
        
        # Log-normal distribution for biological variability (more realistic than normal)
        sigma = np.sqrt(np.log(1 + cv**2))
        mu = np.log(mean_val) - 0.5 * sigma**2
        data = np.random.lognormal(mu, sigma, num_points)
        
        # Clip to realistic bounds
        data = np.clip(data, 0, max_scale * 1.2)
    
    elif pattern_type == 'exponential_decay':
        # Realistic pharmacokinetic/radioactive decay parameters
        t = np.linspace(0, np.random.uniform(5, 20), num_points)
        
        # Half-life ranges based on actual pharmacokinetic data
        half_life = np.random.choice([
            np.random.uniform(0.5, 2),    # Fast clearance (minutes to hours)
            np.random.uniform(2, 12),     # Moderate clearance (hours)
            np.random.uniform(12, 72)     # Slow clearance (days)
        ], p=[0.3, 0.5, 0.2])
        
        decay_constant = np.log(2) / half_life
        
        initial_value = np.random.uniform(0.8, 0.95) * max_scale
        baseline = np.random.uniform(0, 0.1) * max_scale
        
        data = (initial_value - baseline) * np.exp(-decay_constant * t) + baseline
        
        # Proportional error model (higher error at higher concentrations)
        error_proportional = 0.08  # 8% proportional error
        error_additive = 0.02 * max_scale  # 2% additive error
        noise = np.random.normal(0, data * error_proportional + error_additive, num_points)
        data += noise
        
        data = np.clip(data, baseline * 0.8, initial_value * 1.1)
    
    elif pattern_type == 'enzyme_kinetics':
        # Michaelis-Menten kinetics with realistic parameters
        substrate = np.logspace(-1, 2, num_points)  # 0.1 to 100 units
        
        # Realistic Km values (µM to mM range for most enzymes)
        km = np.random.uniform(0.5, 50)
        vmax = np.random.uniform(0.7, 0.95) * max_scale
        
        # Michaelis-Menten equation
        data = (vmax * substrate) / (km + substrate)
        
        # Add realistic experimental noise (CV = 5-15% for enzyme assays)
        cv = np.random.uniform(0.05, 0.15)
        noise = np.random.normal(0, data * cv, num_points)
        data += noise
        
        data = np.clip(data, 0, vmax * 1.05)
    
    elif pattern_type == 'gaussian_peak':
        # Spectroscopy peak or chromatography data
        x = np.arange(num_points)
        
        # Peak position and width
        mu = np.random.uniform(num_points * 0.3, num_points * 0.7)
        sigma = np.random.uniform(num_points * 0.05, num_points * 0.20)
        
        amplitude = max_scale * np.random.uniform(0.80, 0.95)
        baseline = max_scale * np.random.uniform(0, 0.10)
        
        data = amplitude * np.exp(-((x - mu)**2) / (2 * sigma**2)) + baseline
        
        # Poisson-like noise (typical for photon counting/mass spectrometry)
        noise_factor = np.sqrt(np.abs(data - baseline))
        noise = np.random.normal(0, noise_factor * 0.3, num_points)
        data += noise
        
        data = np.clip(data, baseline * 0.9, amplitude * 1.1)
    
    # === BUSINESS PATTERNS WITH REALISTIC CONSTRAINTS ===
    elif pattern_type == 'seasonal_trend':
        # Realistic business seasonality with multiple components
        x = np.arange(num_points)
        
        # Multiple seasonality (annual + quarterly + monthly if enough points)
        components = []
        
        if num_points >= 12:  # Annual seasonality
            annual_freq = 2 * np.pi / 12
            annual_amp = max_scale * np.random.uniform(0.15, 0.30)
            annual_phase = np.random.uniform(0, 2*np.pi)
            components.append(annual_amp * np.cos(annual_freq * x + annual_phase))
        
        if num_points >= 4:   # Quarterly seasonality
            quarterly_freq = 2 * np.pi / 4
            quarterly_amp = max_scale * np.random.uniform(0.08, 0.15)
            quarterly_phase = np.random.uniform(0, 2*np.pi)
            components.append(quarterly_amp * np.cos(quarterly_freq * x + quarterly_phase))
        
        # Base level with trend
        base_level = max_scale * np.random.uniform(0.3, 0.5)
        trend_slope = max_scale * np.random.uniform(-0.05, 0.20) / num_points
        trend = x * trend_slope
        
        # Combine components
        seasonal = np.sum(components, axis=0) if components else np.zeros(num_points)
        data = base_level + trend + seasonal
        
        # Business-appropriate noise (higher during peak seasons)
        noise_base = max_scale * 0.03
        noise_seasonal = np.abs(seasonal) * 0.2
        noise = np.random.normal(0, noise_base + noise_seasonal, num_points)
        data += noise
        
        data = np.clip(data, 0, max_scale * 1.5)
    
    elif pattern_type == 'pareto_distribution':
        # Pareto principle (80/20 rule) - realistic for business data
        shape = np.random.uniform(1.05, 2.5)  # Literature range for business data
        
        # Generate Pareto samples
        samples = np.random.pareto(shape, num_points) + 1
        
        # Sort in descending order for typical business visualization
        data = np.sort(samples)[::-1]
        
        # Scale to max_scale with realistic ceiling
        data = (data / data.max()) * max_scale * np.random.uniform(0.6, 0.9)
        
        # Add small multiplicative noise (log-normal)
        noise = np.random.lognormal(0, 0.10, num_points)
        data *= noise
    
    elif pattern_type == 'exponential_growth':
        # Realistic business growth with saturation
        t = np.linspace(0, 1, num_points)
        
        # Growth rates based on actual business metrics
        growth_rate = np.random.choice([
            np.random.uniform(2, 5),      # Moderate growth
            np.random.uniform(5, 10),     # High growth
            np.random.uniform(10, 15)     # Exponential phase
        ], p=[0.5, 0.3, 0.2])
        
        initial_value = max_scale * np.random.uniform(0.05, 0.20)
        
        # Exponential with eventual saturation (logistic-like)
        data = initial_value * np.exp(growth_rate * t)
        
        # Apply market saturation
        carrying_capacity = max_scale * np.random.uniform(0.8, 1.0)
        saturation_factor = 1 / (1 + (data / carrying_capacity))
        data *= saturation_factor
        
        # Business noise (proportional to current value)
        cv = np.random.uniform(0.08, 0.20)
        noise = np.random.normal(0, data * cv, num_points)
        data += noise
        
        data = np.clip(data, initial_value * 0.8, carrying_capacity * 1.1)
    
    # === FALLBACK PATTERNS ===
    elif pattern_type == 'linear':
        start = max_scale * np.random.uniform(0.10, 0.40)
        end = max_scale * np.random.uniform(0.50, 0.90)
        
        if domain == 'scientific' and np.random.random() < 0.7:
            start, end = min(start, end), max(start, end)
        
        data = np.linspace(start, end, num_points)
        
        noise_cv = np.random.uniform(0.05, 0.15)
        noise = np.random.normal(0, data * noise_cv + max_scale * 0.01, num_points)
        data += noise
    
    elif pattern_type == 'plateau':
        p1, p2 = sorted(random.sample(range(num_points + 1), 2))
        low = max_scale * np.random.uniform(0.1, 0.3)
        high = max_scale * np.random.uniform(0.7, 0.9)
        
        data = np.concatenate([
            np.full(p1, low), 
            np.full(p2 - p1, high), 
            np.full(num_points - p2, low)
        ])
        
        noise = np.random.normal(0, max_scale * 0.05, num_points)
        data += noise
    
    else:  # Default: random_walk
        start = max_scale * np.random.uniform(0.3, 0.7)
        steps = np.random.normal(0, max_scale * 0.1, num_points)
        data = start + np.cumsum(steps)
        
        noise = np.random.normal(0, max_scale * 0.05, num_points)
        data += noise
    
    # === POST-PROCESSING FOR MEASUREMENT REALISM ===
    
    # Apply measurement constraints
    if not allow_negative:
        data = np.clip(data, 0, max_scale * 1.2)
    else:
        data = np.clip(data, -max_scale * 0.4, max_scale * 1.2)
    
    # Realistic measurement precision (instruments have limited precision)
    if max_scale >= 1000:
        precision = np.random.choice([0, 1], p=[0.7, 0.3])
    elif max_scale >= 100:
        precision = np.random.choice([1, 2], p=[0.6, 0.4])
    elif max_scale >= 10:
        precision = np.random.choice([2, 3], p=[0.7, 0.3])
    else:
        precision = 3
    
    data = np.round(data, precision)
    
    # Remove impossible values
    if domain == 'scientific' and not allow_negative:
        data = np.abs(data)
    
    return data

def apply_chart_theme(ax, theme_name, orientation='vertical'):
    theme = THEMES.get(theme_name, THEMES.get('default', {}))
    if not theme:
        theme = {'facecolor': 'white', 'grid_color': '#CCCCCC', 'grid_style': 'solid', 'font': 'Arial'}
    
    ax.set_facecolor(theme.get('facecolor', 'white'))
    
    grid_axis = 'y' if orientation == 'vertical' else 'x'
    
    if theme.get('grid_style', 'none') != 'none':
        ax.grid(axis=grid_axis, color=theme.get('grid_color', '#CCCCCC'), 
                linestyle=theme.get('grid_style', 'solid'),
                linewidth=theme.get('grid_linewidth', 1.0), zorder=0)
    
    try: 
        rcParams['font.sans-serif'] = [theme.get('font', 'Arial'), 'DejaVu Sans', 'Arial']
    except Exception: 
        pass
    
    for spine, visible in theme.get('spines', {}).items():
        if spine in ax.spines: 
            ax.spines[spine].set_visible(visible)
    
    if theme.get('spine_width'):
        for spine in ax.spines.values():
            spine.set_linewidth(theme['spine_width'])
    
    if theme.get('tick_direction'): 
        ax.tick_params(axis='both', direction=theme['tick_direction'])
    
    return theme

# ===================================================================================
# == CHART ELEMENT ADDITIONS (CRITICAL FOR YOLO ANNOTATION) ==
# ===================================================================================

def add_bar_shadows(ax, bars, fig):
    """Add realistic drop shadows to bars"""
    for bar in bars:
        dx, dy = 2 / fig.dpi, -2 / fig.dpi
        shadow_transform = ax.transData + transforms.ScaledTranslation(dx, dy, fig.dpi_scale_trans)
        shadow = patches.Rectangle(bar.get_xy(), bar.get_width(), bar.get_height(),
                                 transform=shadow_transform, facecolor='black',
                                 alpha=0.2, zorder=bar.get_zorder() - 0.1)
        ax.add_patch(shadow)

def add_significance_markers(ax, bar_info, y_max, orientation='vertical', error_tops=None):
    """Add statistical significance markers between bars"""
    annotations = []
    
    if len(bar_info) < 2 or random.random() < 0.4: 
        return annotations
    
    mode = random.choice(['bracket', 'letters'])
    
    if mode == 'bracket':
        try:
            idx1, idx2 = random.sample(range(len(bar_info)), 2)
        except ValueError:
            return annotations
        
        bracket_style = random.choice(['standard', 'extended'])
        
        # Get bar positions
        pos1, pos2 = bar_info[idx1]['center'], bar_info[idx2]['center']
        text = random.choice(['*', '**', '***', 'ns'])
        
        start_idx = min(idx1, idx2)
        end_idx = max(idx1, idx2)
        
        max_height_in_range = 0
        
        if orientation == 'vertical':
            # Find maximum height of ANY bar or error bar within range
            for i in range(start_idx, end_idx + 1):
                bar_height = error_tops[i] if error_tops and i < len(error_tops) else bar_info[i]['height']
                if abs(bar_height) > max_height_in_range:
                    max_height_in_range = abs(bar_height)
            
            y_for_level = max_height_in_range
            level = max_height_in_range * (1 + random.uniform(0.10, 0.20))
            
            height1 = error_tops[idx1] if error_tops and idx1 < len(error_tops) else bar_info[idx1]['height']
            height2 = error_tops[idx2] if error_tops and idx2 < len(error_tops) else bar_info[idx2]['height']
            
            if bracket_style == 'extended':
                gap = y_for_level * 0.05
                start_y1 = height1 + gap
                start_y2 = height2 + gap
                ax.plot([pos1, pos1, pos2, pos2], [start_y1, level, level, start_y2], 
                       lw=1.2, c='black', zorder=15)
            else:  # 'standard'
                tip_height = y_for_level * 0.05
                ax.plot([pos1, pos1, pos2, pos2], 
                       [level - tip_height, level, level, level - tip_height], 
                       lw=1.2, c='black', zorder=15)
            
            txt = ax.text((pos1 + pos2) / 2, level, text, ha='center', va='bottom', 
                         color='black', fontsize=12, zorder=15)
        
        else:  # Horizontal orientation
            # Find maximum "height" (width) of ANY bar in range
            for i in range(start_idx, end_idx + 1):
                bar_width = error_tops[i] if error_tops and i < len(error_tops) else bar_info[i]['height']
                if abs(bar_width) > max_height_in_range:
                    max_height_in_range = abs(bar_width)
            
            x_for_level = max_height_in_range
            level = x_for_level * (1 + random.uniform(0.15, 0.30))
            
            height1 = error_tops[idx1] if error_tops and idx1 < len(error_tops) else bar_info[idx1]['height']
            height2 = error_tops[idx2] if error_tops and idx2 < len(error_tops) else bar_info[idx2]['height']
            
            if bracket_style == 'extended':
                gap = x_for_level * 0.05
                start_x1 = height1 + gap
                start_x2 = height2 + gap
                ax.plot([start_x1, level, level, start_x2], [pos1, pos1, pos2, pos2], 
                       lw=1.2, c='black', zorder=15)
            else:  # 'standard'
                tip_height = x_for_level * 0.05
                ax.plot([level - tip_height, level, level, level - tip_height], 
                       [pos1, pos1, pos2, pos2], lw=1.2, c='black', zorder=15)
            
            txt = ax.text(level, (pos1 + pos2) / 2, text, ha='left', va='center', 
                         color='black', fontsize=12, zorder=15)
        
        annotations.append(txt)
    
    elif mode == 'letters':
        letters = random.sample(['a', 'b', 'c', 'd'], k=min(len(bar_info), 4))
        
        for i, info in enumerate(bar_info):
            if i >= len(letters): 
                break
            
            pos, height = info['center'], info['height']
            base_y = error_tops[i] if error_tops and i < len(error_tops) else height
            offset = 0.05 * y_max
            y_pos = base_y + offset if height >= 0 else base_y - offset
            va = 'bottom' if height >= 0 else 'top'
            
            if orientation == 'vertical':
                txt = ax.text(pos, y_pos, letters[i], ha='center', va=va, fontsize=10)
            else:
                txt = ax.text(y_pos, pos, letters[i], ha='left', va='center', fontsize=10)
            
            annotations.append(txt)
    
    return annotations

def add_error_bars(ax, bar_info, orientation='vertical', measurement_type='biological'):
    """Add realistic error bars with measurement-specific characteristics"""
    error_artists = []
    error_tops = [info['height'] for info in bar_info]  # Initialize with bar heights
    
    for i, info in enumerate(bar_info):
        if random.random() < 0.7 and info['height'] >= 0:  # 70% chance for error bars
            center, value = info['center'], info['height']
            
            # Realistic error bar calculation based on measurement type
            if measurement_type == 'biological':
                # Biological replicates: SEM or SD
                error_type = np.random.choice(['sem', 'sd'], p=[0.7, 0.3])
                n_replicates = np.random.choice([3, 4, 5, 6, 8], p=[0.4, 0.3, 0.15, 0.10, 0.05])
                
                # CV based on assay type
                cv = np.random.uniform(0.10, 0.30)  # 10-30% CV for biological data
                sd = value * cv
                
                if error_type == 'sem':
                    error = sd / np.sqrt(n_replicates)
                else:
                    error = sd
                    
            elif measurement_type == 'analytical':
                # Analytical chemistry: typically smaller errors
                cv = np.random.uniform(0.02, 0.08)  # 2-8% CV
                error = value * cv
                
            elif measurement_type == 'survey':
                # Survey data: confidence intervals
                error = value * np.random.uniform(0.05, 0.15)  # 5-15% margin of error
                
            else:  # Default
                error = value * np.random.uniform(0.08, 0.20)
            
            # Create error bar
            if orientation == 'vertical':
                artist = ax.errorbar(center, value, yerr=error, fmt='none', 
                                   ecolor='black', capsize=4, elinewidth=1.2, 
                                   capthick=1.2, zorder=10)
                error_tops[i] = value + error
            else:
                artist = ax.errorbar(value, center, xerr=error, fmt='none', 
                                   ecolor='black', capsize=4, elinewidth=1.2, 
                                   capthick=1.2, zorder=10)
                error_tops[i] = value + error
                
            error_artists.append(artist)
    
    return error_artists, error_tops

def add_data_labels(ax, artists, orientation='vertical', chart_type='bar', 
                   error_tops=None, bar_info_list=None):
    """
    Add data labels to chart elements with correct positioning for stacked bars.
    
    CRITICAL FIX: Uses bar_info_list metadata to correctly position labels
    on stacked bar segments and match with error bars.
    """
    labels = []
    
    # Create lookup for bar info if available
    bar_info_centers = None
    if bar_info_list:
        bar_info_centers = [b['center'] for b in bar_info_list]
    
    for artist in artists:
        if isinstance(artist, patches.Rectangle) and chart_type in ['bar', 'histogram']:
            matched_idx = None
            matched_bar_info = None
            
            # Determine artist's center in data coordinates
            if orientation == 'vertical':
                artist_center = artist.get_x() + artist.get_width() / 2.0
                artist_height = artist.get_height()
                artist_bottom = artist.get_y()
            else:  # horizontal
                artist_center = artist.get_y() + artist.get_height() / 2.0
                artist_height = artist.get_width()
                artist_bottom = artist.get_x()
            
            # Match to bar_info using center AND bottom position (critical for stacked bars)
            if bar_info_list:
                min_distance = float('inf')
                for idx, b_info in enumerate(bar_info_list):
                    # Check center match
                    center_diff = abs(b_info['center'] - artist_center)
                    
                    # Check bottom position match (critical for stacked bars)
                    bottom_diff = abs(b_info.get('bottom', 0) - artist_bottom)
                    
                    # Combined distance metric
                    distance = center_diff + bottom_diff
                    
                    if distance < min_distance:
                        min_distance = distance
                        matched_idx = idx
                        matched_bar_info = b_info
            
            # Use segment height as label value (NOT cumulative for stacked)
            if matched_bar_info:
                label_value = matched_bar_info['height']
            else:
                if orientation == 'vertical':
                    label_value = artist_height if artist.get_y() >= 0 else -artist_height
                else:  # horizontal
                    label_value = artist_height if artist.get_x() >= 0 else -artist_height
            
            if abs(label_value) < 0.01: 
                continue
            
            label_text = f'{label_value:.1f}'
            
            # Position label at TOP of segment
            if orientation == 'vertical':
                x_pos = artist_center
                offset = 0.02 * (ax.get_ylim()[1] - ax.get_ylim()[0])
                
                if label_value >= 0:
                    # Use error bar top as anchor if available
                    anchor_y = error_tops[matched_idx] if matched_idx is not None and error_tops else (matched_bar_info['height'] if matched_bar_info else artist.get_y() + artist.get_height())
                    y_pos = anchor_y + offset
                    va = 'bottom'
                else:  # Negative bars
                    anchor_y = artist.get_y()
                    y_pos = anchor_y - offset
                    va = 'top'
                
                txt = ax.text(x_pos, y_pos, label_text, ha='center', va=va, 
                             fontsize=7, zorder=12)
                labels.append(txt)
            
            else:  # horizontal
                y_pos = artist_center
                offset = 0.02 * (ax.get_xlim()[1] - ax.get_xlim()[0])
                
                if label_value >= 0:
                    anchor_x = error_tops[matched_idx] if matched_idx is not None and error_tops else (matched_bar_info['height'] if matched_bar_info else artist.get_x() + artist.get_width())
                    x_pos = anchor_x + offset
                    ha = 'left'
                else:  # Negative bars
                    anchor_x = artist.get_x()
                    x_pos = anchor_x - offset
                    ha = 'right'
                
                txt = ax.text(x_pos, y_pos, label_text, ha=ha, va='center',
                             fontsize=7, zorder=12)
                labels.append(txt)
        
        elif isinstance(artist, patches.Wedge) and chart_type == 'pie':  # For pie charts
            ang = (artist.theta2 - artist.theta1)/2. + artist.theta1
            y = np.sin(np.deg2rad(ang)); x = np.cos(np.deg2rad(ang))
            value = (artist.theta2 - artist.theta1) / 360
            
            if value > 0.05:
                txt = ax.text(0.7 * x, 0.7 * y, f'{value:.0%}', ha='center', va='center', 
                             fontsize=8, color='white', zorder=12,
                             bbox=dict(boxstyle="round,pad=0.2", fc='black', ec="none", alpha=0.4))
                labels.append(txt)
    
    return labels

def add_treatment_key_xaxis(ax, bar_info_list):
    """Add treatment key annotations below X-axis"""
    annotation_artists = []
    treatment_labels = COMPARATIVE_LABELS
    centers = [info['center'] for info in bar_info_list]
    
    if len(centers) != 4: 
        return annotation_artists  # Return empty list
    
    ax.set_xlabel(''); ax.set_xticklabels([]); ax.tick_params(axis='x', length=0)
    
    treatment1, treatment2 = random.choice(treatment_labels)
    y_pos1, y_pos2 = -0.15, -0.25
    
    text1 = ax.text(-0.1, y_pos1, f"{treatment1}", transform=ax.transAxes, 
                   ha='right', va='center', fontsize=10)
    text2 = ax.text(-0.1, y_pos2, f"{treatment2}", transform=ax.transAxes, 
                   ha='right', va='center', fontsize=10)
    
    annotation_artists.extend([text1, text2])
    
    symbols = [('-', '-'), ('+', '-'), ('-', '+'), ('+', '+')]
    blended_transform = transforms.blended_transform_factory(ax.transData, ax.transAxes)
    
    for i, center in enumerate(centers):
        ax.text(center, y_pos1, symbols[i][0], transform=blended_transform, 
               ha='center', va='center', fontsize=12)
        ax.text(center, y_pos2, symbols[i][1], transform=blended_transform, 
               ha='center', va='center', fontsize=12)
    
    return annotation_artists

# ===================================================================================
# == CHART-SPECIFIC GENERATOR FUNCTIONS (COMPLETE WITH BUG FIXES) ==
# ===================================================================================

def _generate_bar_chart(ax, theme_name, theme_config, style_config, debug_mode=False):
    """
    CRITICAL FIXES:
    - Complete stacked bar annotation metadata
    - Proper dual-axis handling
    - Consistent return structure for all code paths
    - Error bar matching for stacked segments
    """
    
    # Initialize return values at start
    data_artists = []
    other_artists = []
    bar_info_list = []
    orientation = style_config.get('orientation', 'vertical')
    error_tops = []
    axis_related_artists = []
    scale_axis_info = {'primary_scale_axis': 'y' if orientation == 'vertical' else 'x'}
    
    if debug_mode:
        print(f"DEBUG: _generate_bar_chart - Theme: {theme_name}, Style: {style_config}")
        print(f"DEBUG: _generate_bar_chart - Orientation: {orientation}")
    
    # --- DUAL Y-AXIS LOGIC ---
    if style_config.get('orientation', 'vertical') == 'vertical' and random.random() < 0.15:
        print(" - Generating dual Y-axis bar chart with scientific styles")
        is_scientific = True
        ax2 = ax.twinx()
        
        num_bars_1 = random.randint(2, 5)
        num_bars_2 = random.randint(2, 5)
        max_scale_1 = random.choice([50, 100, 200])
        max_scale_2 = random.choice([500, 1000, 2000])
        
        data_1 = generate_realistic_data(num_bars_1, max_scale_1, domain='scientific')
        data_2 = generate_realistic_data(num_bars_2, max_scale_2, domain='scientific')
        
        if debug_mode:
            print(f"DEBUG: Dual-axis chart - Data sets: {len(data_1)} and {len(data_2)} values")
            print(f"DEBUG: Dual-axis chart - Max scales: {max_scale_1} and {max_scale_2}")
        
        bar_width = 0.8
        positions_1 = np.arange(num_bars_1)
        gap = 2
        positions_2 = np.arange(num_bars_2) + num_bars_1 + gap
        all_positions = np.concatenate([positions_1, positions_2])
        
        labels_1 = [f'Cond {i+1}' for i in range(num_bars_1)]
        labels_2 = [f'Treat {i+1}' for i in range(num_bars_2)]
        all_labels = labels_1 + labels_2
        
        bar_styles = [{'facecolor': 'white', 'edgecolor': 'black', 'hatch': h} 
                     for h in ['', '////', '....', 'xxxx']]
        random.shuffle(bar_styles)
        style_1, style_2 = random.sample(bar_styles, 2)
        
        rects1 = ax.bar(positions_1, data_1, width=bar_width, zorder=2, 
                       label='Group 1', **style_1)
        rects2 = ax2.bar(positions_2, data_2, width=bar_width, zorder=2, 
                        label='Group 2', **style_2)
        
        data_artists = list(rects1) + list(rects2)
        
        # CRITICAL: Store complete metadata for BOTH axis groups
        bar_info_list_1, bar_info_list_2 = [], []
        
        for i, r in enumerate(rects1):
            bar_info_list_1.append({
                'center': r.get_x() + r.get_width()/2, 
                'height': r.get_height(), 
                'width': r.get_width(),
                'bottom': r.get_y(),
                'top': r.get_y() + r.get_height(),
                'axis': 'primary'
            })
        
        for i, r in enumerate(rects2):
            bar_info_list_2.append({
                'center': r.get_x() + r.get_width()/2, 
                'height': r.get_height(), 
                'width': r.get_width(),
                'bottom': r.get_y(),
                'top': r.get_y() + r.get_height(),
                'axis': 'secondary'
            })
        
        error_artists_1, error_tops_1 = add_error_bars(ax, bar_info_list_1, orientation='vertical')
        error_artists_2, error_tops_2 = add_error_bars(ax2, bar_info_list_2, orientation='vertical')
        
        other_artists.extend(error_artists_1)
        other_artists.extend(error_artists_2)
        
        combined_error_tops = error_tops_1 + error_tops_2
        
        ax.set_xlabel(random.choice(SCIENTIFIC_X_LABELS))
        ax.set_ylabel(random.choice(SCIENTIFIC_Y_LABELS))
        ax2.set_ylabel(random.choice(SCIENTIFIC_Y_LABELS))
        
        # CRITICAL: Atomic position and label setting
        ax.set_xticks(all_positions)
        ax.set_xticklabels(all_labels, rotation=45, ha='right')
        
        ax.set_ylim(0, max_scale_1 * 1.2)
        ax2.set_ylim(0, max_scale_2 * 1.2)
        
        ax.grid(False)
        ax2.grid(False)
        
        if random.random() < 0.05:
            ax.spines['bottom'].set_visible(False)
            ax.tick_params(axis='x', length=0)
        
        scale_axis_info = {'primary_scale_axis': 'y', 'secondary_scale_axis': 'y2'}
        
        if debug_mode:
            print(f"DEBUG: Dual-axis chart completed - {len(data_artists)} data artists, {len(other_artists)} other artists")
        
        return data_artists, other_artists, bar_info_list_1 + bar_info_list_2, \
               orientation, combined_error_tops, axis_related_artists, scale_axis_info
    
    # --- STANDARD BAR CHART LOGIC ---
    is_scientific = style_config.get('is_scientific', False)
    style = style_config['style']
    pattern = style_config['pattern']
    
    HATCHES = ["/", "\\", "|", "-", "+", "x", "o", "O", ".", "*"]
    
    has_treatment_axis = False
    
    num_bars = random.randint(3, 8)
    max_scale = random.choice([50, 100, 200, 500, 750, 1000, 2000])
    allow_negative = random.random() < 0.15 and not is_scientific
    data_pattern_type = 'diverging' if allow_negative else None
    
    orientation = 'horizontal' if num_bars > 6 and random.random() < 0.40 else 'vertical'
    style_config['orientation'] = orientation
    
    if debug_mode:
        print(f"DEBUG: Standard bar chart - Style: {style}, Pattern: {pattern}, Scientific: {is_scientific}")
        print(f"DEBUG: Standard bar chart - Num bars: {num_bars}, Max scale: {max_scale}, Orientation: {orientation}")
    
    ticks_setter = ax.set_xticks if orientation == 'vertical' else ax.set_yticks
    
    if is_scientific:
        num_groups, bars_per_group = random.randint(2, 6), random.randint(1, 4)
        bar_styles = [{'facecolor': 'white', 'edgecolor': 'black', 'hatch': h} 
                     for h in ['', '////', '....', 'xxxx']]
        random.shuffle(bar_styles)
        
        bar_width = 0.8 / bars_per_group; group_width = bar_width * bars_per_group
        
        for i in range(num_groups):
            group_center = i * (group_width + 0.4)
            data = generate_realistic_data(bars_per_group, max_scale, 
                                         allow_negative=False, domain='scientific')
            
            for j in range(bars_per_group):
                pos = group_center - (group_width / 2) + (j + 0.5) * bar_width
                value = data[j]
                bar_style = bar_styles[j % len(bar_styles)]
                
                if orientation == 'vertical':
                    bar_container = ax.bar(pos, value, width=bar_width, **bar_style, zorder=2)
                    bar_info_list.append({
                        'center': pos, 
                        'height': value, 
                        'width': bar_width,
                        'bottom': 0,
                        'top': value
                    })
                else:
                    bar_container = ax.barh(pos, value, height=bar_width, **bar_style, zorder=2)
                    bar_info_list.append({
                        'center': pos, 
                        'height': value, 
                        'width': bar_width,
                        'bottom': 0,
                        'top': value
                    })
                
                data_artists.extend(bar_container.patches)
        
        ticks_positions = [i * (group_width + 0.4) for i in range(num_groups)]
        tick_labels = [f'Group {g+1}' for g in range(num_groups)]
        
        ticks_setter(ticks_positions, tick_labels)
        
        if len(bar_info_list) == 4 and random.random() < 0.30 and orientation == 'vertical':
            axis_related_artists.extend(add_treatment_key_xaxis(ax, bar_info_list))
            has_treatment_axis = True
    
    else:  # Standard Styles
        palette_name = theme_config.get('palette', 'viridis')
        
        if isinstance(palette_name, list): 
            colors = [palette_name[i % len(palette_name)] for i in range(num_bars * 2)]
        else: 
            cmap = colormaps.get(palette_name); 
            colors = [cmap(i / (num_bars * 1.5)) for i in range(num_bars * 2)]
        
        categories = [f'Category {i+1}' for i in range(num_bars)]
        
        if random.random() < 0.2: 
            categories = [c[:random.randint(5,8)] + '...' if len(c) > 8 else c for c in categories]
        
        if style == 'side_by_side':
            y_values1 = generate_realistic_data(num_bars, max_scale, allow_negative, data_pattern_type)
            y_values2 = generate_realistic_data(num_bars, max_scale, allow_negative, data_pattern_type)
            
            bar_width = 0.35; indices = np.arange(num_bars)
            
            if orientation == 'vertical':
                rects1 = ax.bar(indices - bar_width/2, y_values1, width=bar_width, 
                               label='Series 1', color=colors[0], zorder=3)
                rects2 = ax.bar(indices + bar_width/2, y_values2, width=bar_width, 
                               label='Series 2', color=colors[1], zorder=3)
                
                # CRITICAL: Store metadata for BOTH series
                for i in range(num_bars):
                    bar_info_list.append({
                        'center': indices[i] - bar_width/2, 
                        'height': y_values1[i], 
                        'width': bar_width,
                        'bottom': 0,
                        'top': y_values1[i],
                        'series_idx': 0
                    })
                    bar_info_list.append({
                        'center': indices[i] + bar_width/2, 
                        'height': y_values2[i], 
                        'width': bar_width,
                        'bottom': 0,
                        'top': y_values2[i],
                        'series_idx': 1
                    })
            else:
                pos1 = indices - bar_width/2
                pos2 = indices + bar_width/2
                rects1 = ax.barh(pos1, y_values1, height=bar_width, 
                                label='Series 1', color=colors[0], zorder=3)
                rects2 = ax.barh(pos2, y_values2, height=bar_width, 
                                label='Series 2', color=colors[1], zorder=3)
                
                for i in range(num_bars):
                    bar_info_list.append({
                        'center': pos1[i], 
                        'height': y_values1[i], 
                        'width': bar_width,
                        'bottom': 0,
                        'top': y_values1[i],
                        'series_idx': 0
                    })
                    bar_info_list.append({
                        'center': pos2[i], 
                        'height': y_values2[i], 
                        'width': bar_width,
                        'bottom': 0,
                        'top': y_values2[i],
                        'series_idx': 1
                    })
            
            ticks_setter(indices, categories)
            data_artists.extend(list(rects1) + list(rects2))
        
        elif style == 'stacked':
            y_values1 = generate_realistic_data(num_bars, max_scale/2, allow_negative=False)
            y_values2 = generate_realistic_data(num_bars, max_scale/2, allow_negative=False)
            
            bar_width = 0.7; indices = np.arange(num_bars)
            
            if orientation == 'vertical':
                rects1 = ax.bar(indices, y_values1, width=bar_width, 
                               label='Portion 1', color=colors[0], zorder=3)
                rects2 = ax.bar(indices, y_values2, width=bar_width, bottom=y_values1,
                               label='Portion 2', color=colors[1], zorder=3)
            else:
                rects1 = ax.barh(indices, y_values1, height=bar_width, 
                                label='Portion 1', color=colors[0], zorder=3)
                rects2 = ax.barh(indices, y_values2, height=bar_width, left=y_values1,
                                label='Portion 2', color=colors[1], zorder=3)
            
            ticks_setter(indices, categories)
            data_artists.extend(list(rects1) + list(rects2))
            
            # CRITICAL: Store metadata for EACH stacked segment
            for i in range(num_bars):
                center_pos = indices[i]
                # Bottom segment
                bar_info_list.append({
                    'center': center_pos, 
                    'height': y_values1[i], 
                    'width': bar_width,
                    'bottom': 0,
                    'top': y_values1[i],
                    'series_idx': 0,
                    'bar_idx': i
                })
                # Top segment
                bar_info_list.append({
                    'center': center_pos, 
                    'height': y_values2[i], 
                    'width': bar_width,
                    'bottom': y_values1[i],  # CRITICAL: Bottom of top segment
                    'top': y_values1[i] + y_values2[i],  # CRITICAL: Cumulative top
                    'series_idx': 1,
                    'bar_idx': i
                })
        
        else:  # default, touching, 3d_effect
            y_values = generate_realistic_data(num_bars, max_scale, allow_negative, data_pattern_type)
            
            bar_width = 0.95 if style == 'touching' else 0.8
            gap = 0.05 if style == 'touching' else 0.2
            indices = np.arange(num_bars) * (bar_width + gap)
            
            if orientation == 'vertical':
                rects = ax.bar(indices, y_values, width=bar_width, color=colors, zorder=3)
                for i in range(num_bars):
                    bar_info_list.append({
                        'center': indices[i], 
                        'height': y_values[i], 
                        'width': bar_width,
                        'bottom': 0,
                        'top': y_values[i]
                    })
            else:
                rects = ax.barh(indices, y_values, height=bar_width, color=colors, zorder=3)
                for i in range(num_bars):
                    bar_info_list.append({
                        'center': indices[i], 
                        'height': y_values[i], 
                        'width': bar_width,
                        'bottom': 0,
                        'top': y_values[i]
                    })
            
            ticks_setter(indices, categories)
            data_artists.extend(list(rects))
    
    # Apply pattern styles
    if pattern != 'none':
        for bar in data_artists:
            fc = bar.get_facecolor()
            if pattern == 'hollow': 
                bar.set_facecolor('none'); bar.set_edgecolor(fc); bar.set_linewidth(1.5)
            elif pattern == 'dotted': 
                bar.set_hatch('..')
            elif pattern == 'striped': 
                bar.set_hatch('//')
            elif pattern == 'hatch': 
                bar.set_hatch(random.choice(HATCHES))
    
    if style == '3d_effect': 
        add_bar_shadows(ax, data_artists, ax.figure)
    
    if not is_scientific and random.random() < 0.3 and style != 'stacked':
        add_jitter_overlay(ax, bar_info_list, orientation)
    
    # --- Coordinated logic for error bars and significance markers ---
    error_bar_artists, error_tops = [], []
    
    if (is_scientific or (not is_scientific and random.random() < 0.30)) and style != 'stacked':
        error_bar_artists, error_tops = add_error_bars(ax, bar_info_list, orientation)
        other_artists.extend(error_bar_artists)
    else:
        error_tops = [b['height'] for b in bar_info_list]
    
    if random.random() < 0.1 and style != 'stacked':
        data_label_artists = add_data_labels(ax, data_artists, orientation, 'bar', 
                                            error_tops=error_tops, bar_info_list=bar_info_list)
        other_artists.extend(data_label_artists)
    
    if is_scientific:
        y_max_limit = ax.get_ylim()[1] if orientation == 'vertical' else ax.get_xlim()[1]
        other_artists.extend(add_significance_markers(ax, bar_info_list, y_max_limit, 
                                                     orientation, error_tops=error_tops))
    
    if allow_negative:
        if orientation == 'vertical': 
            ax.axhline(0, color='black', linewidth=0.8, zorder=1)
        else: 
            ax.axvline(0, color='black', linewidth=0.8, zorder=1)
    else:
        if orientation == 'vertical': 
            ax.set_ylim(bottom=0)
        else: 
            ax.set_xlim(left=0)
    
    ax.set_ylabel(random.choice(SCIENTIFIC_Y_LABELS if is_scientific else BUSINESS_Y_LABELS))
    
    if not has_treatment_axis:
        ax.set_xlabel(random.choice(SCIENTIFIC_X_LABELS if is_scientific else BUSINESS_X_LABELS))
    
    if random.random() < 0.3 and orientation == 'vertical': 
        ax.tick_params(axis='x', labelrotation=0)
    
    if is_scientific and orientation == 'vertical' and random.random() < 0.05:
        ax.spines['bottom'].set_visible(False)
        ax.tick_params(axis='x', length=0)
    
    # CRITICAL: Ensure all code paths return complete metadata
    if not bar_info_list:
        # Emergency fallback: extract from data_artists
        for artist in data_artists:
            if isinstance(artist, patches.Rectangle):
                if orientation == 'vertical':
                    bar_info_list.append({
                        'center': artist.get_x() + artist.get_width() / 2,
                        'height': artist.get_height(),
                        'width': artist.get_width(),
                        'bottom': artist.get_y(),
                        'top': artist.get_y() + artist.get_height()
                    })
                else:
                    bar_info_list.append({
                        'center': artist.get_y() + artist.get_height() / 2,
                        'height': artist.get_width(),
                        'width': artist.get_height(),
                        'bottom': artist.get_x(),
                        'top': artist.get_x() + artist.get_width()
                    })
    
    if debug_mode:
        print(f"DEBUG: _generate_bar_chart returning - data_artists: {len(data_artists)}, other_artists: {len(other_artists)}, bar_info_list: {len(bar_info_list)}")
        print(f"DEBUG: Scale axis info: {scale_axis_info}")
    
    return data_artists, other_artists, bar_info_list, orientation, error_tops, \
           axis_related_artists, scale_axis_info, None  # No keypoint data for bar charts

def _generate_line_chart(ax, theme_name, theme_config, is_scientific, debug_mode=False):
    """Enhanced line chart with keypoint detection."""
    theme = apply_chart_theme(ax, theme_name)
    
    num_series = random.randint(1, 4)
    num_points = random.randint(8, 25)
    max_scale = random.choice([50, 100, 500, 1000])
    
    data_artists = []
    other_artists = []
    keypoint_info = []
    x = np.arange(num_points)
    
    palette = theme.get('palette', 'viridis')
    colors = palette[:num_series] if isinstance(palette, list) else [colormaps.get(palette)(i/num_series) for i in range(num_series)]
    
    for series_idx in range(num_series):
        y_data = generate_realistic_data(num_points, max_scale, allow_negative=is_scientific,
                                        domain='scientific' if is_scientific else 'business')
        
        line, = ax.plot(x, y_data, marker='o', markersize=5, linewidth=2,
                       color=colors[series_idx], label=f'Series {series_idx+1}', zorder=3)
        data_artists.append(line)
        
        inflection_pts = detect_inflection_points(x, y_data, threshold=0.1)
        peaks, valleys = detect_extrema(x, y_data)
        
        keypoint_info.append({
            'series_idx': series_idx,
            'start': (x[0], y_data[0], 0),
            'end': (x[-1], y_data[-1], len(x)-1),
            'inflections': inflection_pts,
            'peaks': peaks,
            'valleys': valleys,
            'boundary_points': list(zip(x, y_data, range(len(x)))),
            'all_points': list(zip(x, y_data, range(len(x))))  # **ADD THIS LINE**
        })
    
    ax.set_xlabel(random.choice(SCIENTIFIC_X_LABELS if is_scientific else BUSINESS_X_LABELS))
    ax.set_ylabel(random.choice(SCIENTIFIC_Y_LABELS if is_scientific else BUSINESS_Y_LABELS))
    
    if num_series > 1 and random.random() < 0.7:
        legend = ax.legend(loc='best')
        other_artists.append(legend)
    
    return data_artists, other_artists, [], 'vertical', None, [], {'primary_scale_axis': 'y'}, keypoint_info

def _generate_scatter_chart(ax, theme_name, theme_config, is_scientific, debug_mode=False):
    """Enhanced scatter with realistic correlation structures and sample sizes"""
    theme = apply_chart_theme(ax, theme_name)
    palette = theme.get('palette', 'viridis')
    
    # Realistic sample sizes based on publication analysis
    if is_scientific:
        num_points = np.random.choice([15, 20, 25, 30, 50, 75, 100], 
                                     p=[0.15, 0.25, 0.20, 0.15, 0.15, 0.05, 0.05])
    else:
        num_points = np.random.choice([50, 100, 200, 500], 
                                     p=[0.20, 0.40, 0.30, 0.10])
    
    max_scale = random.choice([50, 100, 200, 500, 1000])
    
    # Realistic correlation patterns with realistic R² values
    relationship = random.choices([
        'strong_positive',    # R² = 0.64-0.81
        'moderate_positive',  # R² = 0.36-0.64  
        'weak_positive',      # R² = 0.09-0.36
        'no_correlation',     # R² = 0-0.09
        'strong_negative',    # R² = 0.64-0.81
        'moderate_negative',  # R² = 0.36-0.64
        'nonlinear',         # Quadratic, exponential relationships
        'clustered'          # Multiple distinct groups
    ], weights=[0.20, 0.25, 0.20, 0.15, 0.05, 0.05, 0.05, 0.05])[0]
    
    data_artists = []
    other_artists = []
    
    # Generate X data with realistic distribution
    x_data = generate_realistic_data(
        num_points, max_scale, 
        allow_negative=False,
        pattern_type='linear' if relationship != 'clustered' else None,
        domain='scientific' if is_scientific else 'business'
    )
    
    if relationship == 'clustered':
        # Generate realistic cluster data
        num_clusters = np.random.choice([2, 3, 4], p=[0.5, 0.3, 0.2])
        x_data, y_data = [], []
        
        for cluster_idx in range(num_clusters):
            cluster_size = max(5, num_points // num_clusters + np.random.randint(-3, 4))
            
            # Well-separated cluster centers
            mean_x = random.uniform(0.15, 0.85) * max_scale
            mean_y = random.uniform(0.15, 0.85) * max_scale
            
            # Realistic covariance (elliptical clusters)
            cov_xx = random.uniform(0.015, 0.08) * max_scale**2
            cov_yy = random.uniform(0.015, 0.08) * max_scale**2
            cov_xy = random.uniform(-0.5, 0.5) * np.sqrt(cov_xx * cov_yy)
            
            cov = [[cov_xx, cov_xy], [cov_xy, cov_yy]]
            cluster_data = np.random.multivariate_normal([mean_x, mean_y], cov, cluster_size)
            
            x_data.extend(cluster_data[:, 0])
            y_data.extend(cluster_data[:, 1])
        
        x_data = np.array(x_data)
        y_data = np.array(y_data)
    else:
        # Sort X for clearer trend visualization
        x_data = np.sort(x_data)
        
        # Generate Y based on X with realistic correlations
        if relationship in ['strong_positive', 'strong_negative']:
            # R² ≈ 0.75-0.90
            target_r_squared = np.random.uniform(0.64, 0.81)
            slope = np.random.uniform(0.5, 1.5) * (1 if 'positive' in relationship else -1)
            
        elif relationship in ['moderate_positive', 'moderate_negative']:
            # R² ≈ 0.40-0.65
            target_r_squared = np.random.uniform(0.36, 0.64)
            slope = np.random.uniform(0.3, 0.8) * (1 if 'positive' in relationship else -1)
            
        elif relationship in ['weak_positive', 'weak_negative']:
            # R² ≈ 0.10-0.35
            target_r_squared = np.random.uniform(0.09, 0.36)
            slope = np.random.uniform(0.1, 0.5) * (1 if 'positive' in relationship else -1)
            
        elif relationship == 'no_correlation':
            # R² ≈ 0-0.09
            target_r_squared = np.random.uniform(0.0, 0.09)
            slope = np.random.uniform(-0.2, 0.2)
        
        elif relationship == 'nonlinear':
            # Nonlinear relationships
            nonlinear_type = np.random.choice(['quadratic', 'exponential', 'logarithmic'])
            
            if nonlinear_type == 'quadratic':
                a = np.random.uniform(-0.002, 0.002)
                b = np.random.uniform(-0.5, 0.5)
                c = np.random.uniform(0.2, 0.5) * max_scale
                y_data = a * x_data**2 + b * x_data + c
                
            elif nonlinear_type == 'exponential':
                a = np.random.uniform(0.05, 0.15)
                b = np.random.uniform(0.01, 0.03)
                c = np.random.uniform(0, max_scale * 0.2)
                y_data = a * np.exp(b * x_data / max_scale) + c
                y_data = np.clip(y_data, 0, max_scale)
                
            elif nonlinear_type == 'logarithmic':
                a = np.random.uniform(10, 30)
                b = np.random.uniform(0, max_scale * 0.3)
                y_data = a * np.log(x_data + 1) + b
            
            # Add noise
            noise_cv = np.random.uniform(0.08, 0.15)
            noise = np.random.normal(0, np.abs(y_data) * noise_cv, num_points)
            y_data += noise
        else:
            # Default linear
            target_r_squared = 0.5
            slope = 0.5
        
        if relationship != 'nonlinear':
            # Generate linear relationship with specific R²
            intercept = max_scale * np.random.uniform(0.1, 0.3)
            y_perfect = slope * (x_data - np.mean(x_data)) + intercept
            
            # Add noise to achieve target R²
            noise_variance = np.var(y_perfect) * ((1 - target_r_squared) / target_r_squared)
            noise = np.random.normal(0, np.sqrt(noise_variance), num_points)
            y_data = y_perfect + noise
    
    # Ensure realistic bounds
    y_data = np.clip(y_data, 0 if not is_scientific else -max_scale*0.2, max_scale * 1.2)
    x_data = np.clip(x_data, 0, max_scale * 1.2)
    
    # Realistic point styling based on sample size
    scatter_kwargs = {
        'alpha': np.random.uniform(0.6, 0.8),
        'zorder': 2,
        'marker': np.random.choice(['o', 's', '^', 'D', '+'])
    }
    
    # Size scaling with sample size (larger datasets = smaller points)
    if num_points < 30:
        scatter_kwargs['s'] = np.random.randint(60, 100)
    elif num_points < 100:
        scatter_kwargs['s'] = np.random.randint(30, 60)
    elif num_points < 500:
        scatter_kwargs['s'] = np.random.randint(15, 30)
    else:
        scatter_kwargs['s'] = np.random.randint(5, 15)
    
    # Store point size for radius calculation
    point_size = scatter_kwargs['s']
    
    # Color strategy
    if isinstance(palette, list) and palette:
        scatter_kwargs['c'] = palette[0]
    else:
        scatter_kwargs['c'] = '#2E86AB'
    
    scatter = ax.scatter(x_data, y_data, **scatter_kwargs)
    data_artists.append(scatter)
    
    # Add trend line for correlated data
    if relationship not in ['no_correlation', 'clustered'] and np.random.random() < 0.7:
        # Fit trend line
        coeffs = np.polyfit(x_data, y_data, 1)
        trend_line = np.poly1d(coeffs)
        x_trend = np.linspace(np.min(x_data), np.max(x_data), 100)
        
        line_color = palette[1] if isinstance(palette, list) and len(palette) > 1 else '#D62728'
        line, = ax.plot(x_trend, trend_line(x_trend), '--', 
                       color=line_color, alpha=0.8, linewidth=2, zorder=1)
        other_artists.append(line)
    
    # Set labels
    ax.set_xlabel(np.random.choice(SCIENTIFIC_X_LABELS if is_scientific else BUSINESS_X_LABELS))
    ax.set_ylabel(np.random.choice(SCIENTIFIC_Y_LABELS if is_scientific else BUSINESS_Y_LABELS))
    
    # Realistic axis limits with padding
    x_range = np.max(x_data) - np.min(x_data)
    y_range = np.max(y_data) - np.min(y_data)
    
    ax.set_xlim(np.min(x_data) - 0.05*x_range, np.max(x_data) + 0.05*x_range)
    ax.set_ylim(np.min(y_data) - 0.05*y_range, np.max(y_data) + 0.05*y_range)
    
    # **NEW: Build scatter point metadata with coordinates and radius**
    # Convert matplotlib scatter point size to radius in data coordinates
    # scatter 's' parameter is in points^2, radius calculation requires axis transformation
    fig = ax.figure
    dpi = fig.dpi if fig else 72.0
    
    # Calculate approximate radius in data coordinates
    # Point size 's' is area in points^2, so radius in points = sqrt(s/pi)
    radius_points = np.sqrt(point_size / np.pi)
    
    # Transform radius from display coordinates to data coordinates
    # Get approximate data-to-display scaling factor from axis limits
    x_display_range = ax.transData.transform([[ax.get_xlim()[1], 0]])[0][0] - \
                      ax.transData.transform([[ax.get_xlim()[0], 0]])[0][0]
    x_data_range = ax.get_xlim()[1] - ax.get_xlim()[0]
    x_scale_factor = x_data_range / x_display_range if x_display_range != 0 else 1.0
    
    y_display_range = ax.transData.transform([[0, ax.get_ylim()[1]]])[0][1] - \
                      ax.transData.transform([[0, ax.get_ylim()[0]]])[0][1]
    y_data_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    y_scale_factor = y_data_range / y_display_range if y_display_range != 0 else 1.0
    
    # Average radius in data coordinates (approximate)
    radius_data = radius_points * (x_scale_factor + y_scale_factor) / 2.0
    
    # Build scatter metadata structure
    scatter_metadata = {
        'relationship': relationship,
        'num_points': num_points,
        'point_size': point_size,
        'radius_data': radius_data,  # Approximate radius in data coordinates
        'points': [
            {
                'x': float(x_data[i]),
                'y': float(y_data[i]),
                'index': i,
                'radius': radius_data  # Same radius for all points (uniform size)
            }
            for i in range(len(x_data))
        ]
    }
    
    return data_artists, other_artists, [], 'vertical', [], [], \
           {'primary_scale_axis': 'x', 'secondary_scale_axis': 'y'}, scatter_metadata

def _generate_boxplot_chart(ax, theme_name, theme_config, is_scientific, 
                           box_width=0.6, outlier_style='circle', show_significance=True, debug_mode=False):
    """Generate boxplot with realistic data and complete annotation metadata"""
    
    # Apply theme
    theme = apply_chart_theme(ax, theme_name)
    if not theme:
        theme = {'palette': 'viridis'}
    
    # Generate realistic data
    num_groups = random.randint(3, 8)
    max_scale = 100
    
    datas = [generate_realistic_data(num_points=random.randint(20, 50), max_scale=max_scale,
                                   allow_negative=is_scientific, pattern_type=None)
             for _ in range(num_groups)]
    
    # Handle empty or invalid data
    if not datas or any(len(d) == 0 for d in datas):
        return [], [], [], 'vertical', [], [], {}, None
    
    # Create boxplot
    bp = ax.boxplot(datas, patch_artist=True, widths=box_width,
                   flierprops={'marker': {'circle': 'o', 'star': '*', 'diamond': 'D'}.get(outlier_style, 'o'),
                              'markersize': 5, 'alpha': 0.6})
    
    # Apply styling
    data_artists = _apply_box_styles(bp, theme, is_scientific)
    _apply_line_styles(bp)  # Median, whisker, cap styles
    
    # Add jitter overlay for scientific plots (20% chance)
    if is_scientific and random.random() < 0.2:
        for i, d in enumerate(datas):
            x_coords = np.random.normal(i + 1, 0.04, size=len(d))
            ax.plot(x_coords, d, '.', color='black', alpha=0.3, zorder=10)
    
    # Set labels
    ax.set_ylabel(random.choice(SCIENTIFIC_Y_LABELS if is_scientific else BUSINESS_Y_LABELS))
    ax.set_xlabel(random.choice(SCIENTIFIC_X_LABELS if is_scientific else BUSINESS_X_LABELS))
    ax.set_xticklabels([f'G{i+1}' for i in range(num_groups)])
    
    # Collect error bar artists (whiskers and caps)
    error_groups = []
    for g in range(num_groups):
        group_artists = [
            bp['whiskers'][2*g], bp['whiskers'][2*g + 1],
            bp['caps'][2*g], bp['caps'][2*g + 1]
        ]
        error_groups.append(group_artists)
    
    # Add significance markers
    bar_info_list = []
    sig_artists = []
    
    if show_significance and random.random() < 0.5:
        max_y = 0
        error_tops = []
        
        for g in range(num_groups):
            top = bp['whiskers'][2*g+1].get_ydata()[1]
            max_y = max(max_y, top + abs(top) * 0.1)
            error_tops.append(top)
            
            center = g + 1
            bar_info_list.append({'center': center, 'height': top, 'width': box_width})
        
        sig_artists = add_significance_markers(ax, bar_info_list, max_y, 'vertical', error_tops)
    
    # Collect other artists
    other_artists_list = []
    for group in error_groups:
        other_artists_list.extend(group)  # Flatten whiskers and caps
    
    if bp['fliers']:
        other_artists_list.extend(bp['fliers'])  # Use extend for fliers
    
    if sig_artists:
        other_artists_list.extend(sig_artists)  # Use extend for significance markers
    
    # **NEW: Extract median line coordinates**
    # Each median is a matplotlib Line2D object with x and y data arrays
    median_metadata = []
    
    for group_idx, median_line in enumerate(bp['medians']):
        # Get x and y coordinates from Line2D object
        x_coords = median_line.get_xdata()  # Array of x coordinates (typically 2 points: left and right ends)
        y_coords = median_line.get_ydata()  # Array of y coordinates (typically 2 identical values)
        
        # Extract endpoints: lower-left and upper-right corners of median line
        # For horizontal median lines: y values are constant, x varies
        if len(x_coords) >= 2 and len(y_coords) >= 2:
            # Lower-left endpoint (minimum x, y value)
            lower_left = {
                'x': float(x_coords[0]),
                'y': float(y_coords[0])
            }
            
            # Upper-right endpoint (maximum x, y value)  
            upper_right = {
                'x': float(x_coords[-1]),
                'y': float(y_coords[-1])
            }
            
            # Median value (constant y-coordinate)
            median_value = float(y_coords[0])
            
            median_metadata.append({
                'group_index': group_idx,
                'group_label': f'G{group_idx+1}',
                'median_value': median_value,
                'lower_left': lower_left,
                'upper_right': upper_right,
                'center_x': float((x_coords[0] + x_coords[-1]) / 2.0),  # X-center of median line
                'line_length': float(x_coords[-1] - x_coords[0])  # Horizontal span of median line
            })
    
    # Build complete boxplot metadata
    boxplot_metadata = {
        'num_groups': num_groups,
        'box_width': box_width,
        'medians': median_metadata
    }
    
    # Return 8 values to match expected unpacking in generator.py
    return data_artists, other_artists_list, bar_info_list, 'vertical', [], [], \
           {'primary_scale_axis': 'y', 'boxplot_raw': bp}, boxplot_metadata


def _apply_box_styles(bp, theme, is_scientific):
    """Apply styling to boxplot boxes based on theme and context"""
    data_artists = bp['boxes']
    num_groups = len(data_artists)
    
    if is_scientific and random.random() < 0.9:
        scientific_style = random.choice(['hollow', 'grayscale'])
        
        if scientific_style == 'hollow':
            for patch in data_artists:
                patch.set_facecolor('none')
                patch.set_edgecolor('black')
                patch.set_linewidth(1.2)
        
        elif scientific_style == 'grayscale':
            colors = ['#FFFFFF', '#DDDDDD', '#BBBBBB', '#999999']
            for i, patch in enumerate(data_artists):
                patch.set_facecolor(colors[i % len(colors)])
                patch.set_edgecolor('black')
                patch.set_linewidth(1.2)
    
    else:
        palette = theme.get('palette', 'viridis')
        colors = []
        
        if isinstance(palette, list):
            colors = [palette[i % len(palette)] for i in range(num_groups)]
        elif isinstance(palette, str):
            try:
                cmap = colormaps.get(palette)
                colors = [cmap(i / num_groups) for i in range(num_groups)]
            except ValueError:
                cmap = colormaps.get('viridis')
                colors = [cmap(i / num_groups) for i in range(num_groups)]
        
        for patch, color in zip(data_artists, colors):
            patch.set_facecolor(color)
            patch.set_edgecolor('black')
            patch.set_linewidth(1.2)
    
    return data_artists


def _apply_line_styles(bp):
    """Apply consistent styling to medians, whiskers, and caps"""
    for median in bp['medians']:
        median.set_color('black')
        median.set_linewidth(1.5)
    
    for whisker in bp['whiskers']:
        whisker.set_color('black')
        whisker.set_linewidth(1.2)
    
    for cap in bp['caps']:
        cap.set_color('black')
        cap.set_linewidth(1.2)

def _generate_pie_chart(ax, theme_name, theme_config, is_scientific, debug_mode=False):
    """Enhanced pie chart with geometric keypoint calculation."""
    theme = apply_chart_theme(ax, theme_name)
    
    for spine in ['left', 'bottom', 'top', 'right']:
        ax.spines[spine].set_visible(False)
    ax.set_xticks([])
    ax.set_yticks([])
    
    num_slices = random.randint(3, 8)
    data = [random.uniform(10, 100) for _ in range(num_slices)]
    labels = [f'Item {i+1}' for i in range(num_slices)]
    
    explode = [0.0] * num_slices
    if random.random() < 0.4:
        explode[random.randint(0, num_slices-1)] = 0.10
    
    palette = theme.get('palette', 'viridis')
    colors = [palette[i % len(palette)] for i in range(num_slices)] if isinstance(palette, list) else [colormaps.get(palette)(i/num_slices) for i in range(num_slices)]
    
    wedges, texts, autotexts = ax.pie(data, explode=explode, labels=labels, colors=colors,
                                       autopct='%1.1f%%', startangle=90,
                                       wedgeprops={'edgecolor': 'white', 'linewidth': 1.5},
                                       pctdistance=0.7, labeldistance=1.1)
    ax.axis('equal')

    pie_geometry = calculate_pie_geometry(wedges, ax)
    
    return wedges, autotexts + texts, [], 'vertical', [], [], {'primary_scale_axis': 'none'}, pie_geometry


def _generate_histogram(ax, theme_name, theme_config, is_scientific, debug_mode=False):
    """Generate histogram with realistic data distribution"""
    # Apply general theme settings (background, grid, etc.)
    theme = apply_chart_theme(ax, theme_name)
    
    num_bins = random.randint(8, 20)
    data = np.random.normal(loc=random.uniform(-10, 10), scale=random.uniform(5, 15), size=500)
    
    # Prioritize using theme's color palette
    hist_color = None
    palette = theme.get('palette')
    
    if isinstance(palette, list) and palette:
        # If palette is a list of colors, choose one
        hist_color = random.choice(palette)
    elif isinstance(palette, str):
        # If palette is a colormap name, get a representative color from it
        try:
            # Get a color from the middle of the colormap
            hist_color = colormaps.get(palette)(0.4)
        except (ValueError, AttributeError):
            # If colormap name is invalid, hist_color remains None
            pass
    
    # Fall back to original hardcoded colors if theme palette is not usable
    if hist_color is None:
        hist_color = random.choice(['#4472C4', '#5B9BD5', '#66C2A5'])
    
    n, bins, patches = ax.hist(data, bins=num_bins, color=hist_color, zorder=2)
    
    data_artists = patches
    
    bar_info_list = []
    for r in data_artists:
        bar_info_list.append({
            'center': r.get_x() + r.get_width()/2, 
            'height': r.get_height(), 
            'width': r.get_width(),
            'bottom': 0,
            'top': r.get_height()
        })
    
    ax.set_ylabel(random.choice(HISTOGRAM_Y_LABELS))
    ax.set_xlabel(random.choice(SCIENTIFIC_X_LABELS if is_scientific else BUSINESS_X_LABELS))
    
    # Histogram data labels typically show frequency/count values on top of bars
    data_label_artists = []
    
    # Add data labels with 10% probability (histograms don't always have labels)
    if random.random() < 0.1:
        # Select subset of bars to label (not all bars, typically higher frequency ones)
        # Sort bars by height and label top 30-50% of bars
        sorted_bars = sorted(zip(patches, n), key=lambda x: x[1], reverse=True)
        num_to_label = max(3, int(len(sorted_bars) * random.uniform(0.3, 0.5)))
        bars_to_label = sorted_bars[:num_to_label]
        
        for patch, height in bars_to_label:
            if height > 0:  # Only label non-empty bars
                x_pos = patch.get_x() + patch.get_width() / 2.0
                y_pos = height
                
                # Format label: show integer count
                label_text = f'{int(height)}'
                
                # Add text annotation
                text_artist = ax.text(
                    x_pos, y_pos,
                    label_text,
                    ha='center',
                    va='bottom',
                    fontsize=9,
                    color='black',
                    zorder=3
                )
                data_label_artists.append(text_artist)
    
    # Return 8 values: include data_label_artists in other_artists
    # Data labels are "other_artists" not "data_artists"
    return data_artists, data_label_artists, bar_info_list, 'vertical', [], [], \
           {'primary_scale_axis': 'y'}, None

def _generate_area_chart(ax, theme_name, theme_config, is_scientific, debug_mode=False):
    """Enhanced area chart with keypoint detection."""
    theme = apply_chart_theme(ax, theme_name)
    
    num_series = random.randint(1, 4)
    num_points = random.randint(8, 25)
    max_scale = random.choice([50, 100, 500, 1000])
    
    data_artists = []
    other_artists = []
    keypoint_info = []
    x = np.arange(num_points)
    
    series_data = [generate_realistic_data(num_points, max_scale // num_series, allow_negative=False,
                                          domain='scientific' if is_scientific else 'business') 
                   for _ in range(num_series)]
    
    palette = theme.get('palette', 'viridis')
    colors = palette[:num_series] if isinstance(palette, list) else [colormaps.get(palette)(i/num_series) for i in range(num_series)]
    
    y_stack = np.zeros(num_points)
    for series_idx, (data, color) in enumerate(zip(series_data, colors)):
        area = ax.fill_between(x, y_stack, y_stack + data, color=color, alpha=0.7,
                               label=f'Series {series_idx+1}', zorder=2)
        data_artists.append(area)
        
        boundary_y = y_stack + data
        line, = ax.plot(x, boundary_y, color='white', linewidth=1.5, alpha=0.9, zorder=3)
        other_artists.append(line)
        
        inflection_pts = detect_inflection_points(x, boundary_y, threshold=0.1)
        peaks, valleys = detect_extrema(x, boundary_y)
        
        keypoint_info.append({
            'series_idx': series_idx,
            'start': (x[0], boundary_y[0], 0),
            'end': (x[-1], boundary_y[-1], len(x)-1),
            'inflections': inflection_pts,
            'peaks': peaks,
            'valleys': valleys,
            'boundary_points': list(zip(x, boundary_y, range(len(x)))),
            'fill_bottom': list(zip(x, y_stack, range(len(x)))),
            'fill_top': list(zip(x, boundary_y, range(len(x))))
        })
        
        y_stack += data
    
    ax.set_xlabel(random.choice(SCIENTIFIC_X_LABELS if is_scientific else BUSINESS_X_LABELS))
    ax.set_ylabel(random.choice(SCIENTIFIC_Y_LABELS if is_scientific else BUSINESS_Y_LABELS))
    
    if num_series > 1 and random.random() < 0.7:
        legend = ax.legend(loc='best')
        other_artists.append(legend)
    
    return data_artists, other_artists, [], 'vertical', None, [], {'primary_scale_axis': 'y'}, keypoint_info

def _generate_heatmap_chart(ax, theme_name, theme_config, is_scientific, debug_mode=False):
    """Generate heatmap with realistic correlation matrix or data grid"""
    theme = apply_chart_theme(ax, theme_name)
    
    # Remove axes for clean heatmap appearance
    ax.set_xticks([])
    ax.set_yticks([])
    
    # Generate realistic heatmap dimensions
    if is_scientific:
        rows, cols = random.choice([(5, 5), (6, 6), (8, 8), (10, 10)])  # Correlation matrices
    else:
        rows, cols = random.choice([(4, 12), (6, 8), (8, 6), (12, 4)])  # Business data grids
    
    # Generate realistic data
    if is_scientific and rows == cols:
        # Correlation matrix - symmetric
        data = np.random.uniform(0.1, 0.9, (rows, cols))
        # Make symmetric
        data = (data + data.T) / 2
        # Set diagonal to 1
        np.fill_diagonal(data, 1.0)
    else:
        # Regular data matrix
        data = np.random.uniform(0, 100, (rows, cols))
    
    # Create heatmap
    im = ax.imshow(data, cmap='viridis', aspect='auto', zorder=2)
    
    # Add colorbar
    cbar = ax.figure.colorbar(im, ax=ax)
    
    data_artists = [im]
    other_artists = [cbar]
    
    return data_artists, other_artists, [], 'vertical', [], [], \
           {'primary_scale_axis': 'none'}, None

# Additional helper functions for completeness
def add_jitter_overlay(ax, bar_info, orientation='vertical'):
    """Add jitter points overlaid on bars for scientific visualization"""
    for info in bar_info:
        center_pos, mean_val, width_val = info['center'], info['height'], info['width']
        
        if mean_val == 0: 
            continue
        
        n_points = random.randint(8, 20)
        points = np.random.normal(loc=mean_val, scale=abs(mean_val) * random.uniform(0.1, 0.25), size=n_points)
        jitter = np.random.uniform(-width_val * 0.3, width_val * 0.3, size=n_points)
        
        if orientation == 'vertical':
            ax.scatter(center_pos + jitter, points, c='black', s=8, alpha=0.3, zorder=10)
        else:
            ax.scatter(points, center_pos + jitter, c='black', s=8, alpha=0.3, zorder=10)


def detect_inflection_points(x_data, y_data, threshold=0.1):
    """Detect inflection points using second derivative analysis."""
    if len(x_data) < 3:
        return []
    
    inflection_points = []
    y_range = max(y_data) - min(y_data)
    
    for i in range(1, len(y_data) - 1):
        d2y = y_data[i+1] - 2*y_data[i] + y_data[i-1]
        if abs(d2y) > threshold * y_range:
            inflection_points.append((x_data[i], y_data[i], i))
    
    return inflection_points

def detect_extrema(x_data, y_data):
    """Detect local maxima (peaks) and minima (valleys)."""
    if len(y_data) < 3:
        return [], []
    
    peaks, valleys = [], []
    for i in range(1, len(y_data) - 1):
        if y_data[i] > y_data[i-1] and y_data[i] > y_data[i+1]:
            peaks.append((x_data[i], y_data[i], i))
        elif y_data[i] < y_data[i-1] and y_data[i] < y_data[i+1]:
            valleys.append((x_data[i], y_data[i], i))
    
    return peaks, valleys

def calculate_pie_geometry(wedges, ax):
    """Calculate geometric keypoints for pie chart."""
    if not wedges:
        return None
    
    center_x = np.mean([w.center[0] for w in wedges])
    center_y = np.mean([w.center[1] for w in wedges])
    
    wedge_geometry = []
    for idx, wedge in enumerate(wedges):
        radius = wedge.r
        theta1 = np.deg2rad(wedge.theta1)
        theta2 = np.deg2rad(wedge.theta2)
        theta_mid = (theta1 + theta2) / 2
        
        wedge_geometry.append({
            'wedge_idx': idx,
            'center': wedge.center,
            'radius': radius,
            'theta1_deg': wedge.theta1,
            'theta2_deg': wedge.theta2,
            'arc_start': (wedge.center[0] + radius * np.cos(theta1),
                         wedge.center[1] + radius * np.sin(theta1)),
            'arc_end': (wedge.center[0] + radius * np.cos(theta2),
                       wedge.center[1] + radius * np.sin(theta2)),
            'arc_mid': (wedge.center[0] + radius * np.cos(theta_mid),
                       wedge.center[1] + radius * np.sin(theta_mid)),
            'wedge_label_point': (wedge.center[0] + (radius * 0.7) * np.cos(theta_mid),
                                 wedge.center[1] + (radius * 0.7) * np.sin(theta_mid)),
            'angle_span': wedge.theta2 - wedge.theta1
        })
    
    return {'center_point': (center_x, center_y), 'wedges': wedge_geometry}