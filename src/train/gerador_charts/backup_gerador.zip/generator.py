from collections import defaultdict, namedtuple
BoundingBox = namedtuple('BoundingBox', ['x0', 'y0', 'x1', 'y1'])
import time
import matplotlib
matplotlib.use('Agg')

from matplotlib import patches, rcParams, transforms, colormaps
import matplotlib.pyplot as plt
import numpy as np
import os, io, random, math, traceback, warnings, json, subprocess
from scipy.ndimage import gaussian_filter
from PIL import Image, ImageFilter, ImageOps, ImageEnhance, ImageDraw, ImageFont
from matplotlib import colormaps
from matplotlib.colors import ListedColormap
from matplotlib.container import ErrorbarContainer
import matplotlib.lines
from matplotlib.collections import PolyCollection, PathCollection, QuadMesh

from themes import THEMES, CHART_TITLES, SCIENTIFIC_Y_LABELS, BUSINESS_Y_LABELS, SCIENTIFIC_X_LABELS, BUSINESS_X_LABELS
from effects import (
    apply_jpeg_compression_effect, apply_noise_effect, apply_blur_effect, 
    apply_motion_blur_effect, apply_low_res_effect, apply_pixelation_effect, 
    apply_posterize_effect, apply_color_variation_effect, apply_ui_chrome_effect, 
    apply_watermark_effect, apply_vignette_effect, apply_scanner_streaks_effect, 
    apply_clipping_effect, apply_printing_artifacts_effect, apply_mouse_cursor_effect, 
    apply_text_degradation_effect, apply_grid_occlusion_effect, apply_scan_rotation_effect, 
    apply_grayscale_effect, apply_perspective_effect
)

from chart import (_generate_bar_chart, _generate_line_chart, _generate_scatter_chart, 
                   _generate_boxplot_chart, _generate_heatmap_chart, _generate_pie_chart, 
                   _generate_area_chart, _generate_histogram, add_data_labels, apply_chart_theme)


warnings.filterwarnings("ignore", category=UserWarning)

# Import merge functionality
try:
    from merge_json import batch_merge_all
except ImportError:
    print("Warning: merge_json.py not found. JSON merging functionality will be disabled.")
    batch_merge_all = None

# ===================================================================================
# ==                               CONFIGURATION                                   ==
# ===================================================================================
GENERATION_CONFIG = {
    "debug_mode": False,
    "debug_annotations": False,  # Detailed annotation processing logs
    "debug_artists": False,      # Detailed artist processing logs
    "debug_coords": False,       # Detailed coordinate transformation logs
    "num_images": 50, 
    "output_dir": "test_generation",
    "seed": 42,

"CLASS_MAP_BAR": {
    "0": "chart",
    "1": "bar",
    "2": "axis_title",
    "3": "significance_marker",
    "4": "error_bar",
    "5": "legend",
    "6": "chart_title",
    "7": "data_label",
    "8": "axis_labels"
  },
  "CLASS_MAP_PIE_OBJ": {
    "0": "chart",
    "1": "wedge",
    "2": "legend",
    "3": "chart_title",
    "4": "data_label",
    "5": "connector_line"
},
"CLASS_MAP_PIE_POSE": {
    "0": "center_point",
    "1": "arc_boundary",
    "2": "wedge_center",
    "3": "wedge_start",
    "4": "wedge_end"
},
"CLASS_MAP_LINE_OBJ": {
    "0": "chart",
    "1": "line_segment",
    "2": "axis_title",
    "3": "legend",
    "4": "chart_title",
    "5": "data_label",
    "6": "axis_labels"
},
"CLASS_MAP_LINE_POSE": {
    "0": "line_boundary",
    "1": "data_point",
    "2": "inflection_point",
    "3": "line_start",
    "4": "line_end"
},
  "CLASS_MAP_SCATTER": {
    "0": "chart",
    "1": "data_point",
    "2": "axis_title",
    "3": "significance_marker",
    "4": "error_bar",
    "5": "legend",
    "6": "chart_title",
    "7": "data_label",
    "8": "axis_labels"
  },
  "CLASS_MAP_BOX": {
    "0": "chart",
    "1": "box",
    "2": "axis_title",
    "3": "significance_marker",
    "4": "range_indicator",
    "5": "legend",
    "6": "chart_title",
    "7": "median_line",
    "8": "axis_labels",
    "9": "outlier"
  },
  "CLASS_MAP_HISTOGRAM": {
    "0": "chart",
    "1": "bar",
    "2": "axis_title",
    "3": "legend",
    "4": "chart_title",
    "5": "data_label",
    "6": "axis_labels"
  },
  "CLASS_MAP_HEATMAP": {
    "0": "chart",
    "1": "cell",
    "2": "axis_title",
    "3": "color_bar",
    "4": "legend",
    "5": "chart_title",
    "6": "data_label",
    "7": "axis_labels",
    "8": "significance_marker"
  },
  "CLASS_MAP_AREA_POSE": {
    "0": "area_fill",
    "1": "area_boundary",
    "2": "inflection_point",
    "3": "area_start",
    "4": "area_end",
  },
  "CLASS_MAP_AREA_OBJ": {
    "0": "chart",
    "1": "axis_title",
    "2": "legend",
    "3": "chart_title",
    "4": "data_label",
    "5": "axis_labels"
  },

    "scenario_weights": {
        "single": 100,
        "overlay": 0,
        "multi": 0,
    },

    "chart_types": {
        "bar":       {"weight": 10, "enabled": True},
        "line":      {"weight": 10, "enabled": True},
        "scatter":   {"weight": 20, "enabled": True},
        "box":       {"weight": 20,  "enabled": True},
        "pie":       {"weight": 10, "enabled": True},
        "area":      {"weight": 10, "enabled": True},
        "histogram": {"weight": 10, "enabled": True},
        "heatmap":   {"weight": 10,  "enabled": True},
    },
    
    "bar_chart_config": {
        "scientific_ratio": 0.6,
        "styles": {
            "standard":             {"weight": 30},
            "compare_side_by_side": {"weight": 25},
            "stacked":              {"weight": 20},
            "touching":             {"weight": 15},
            "3d_effect":            {"weight": 10},
        },
        "patterns": {
            "none":    {"weight": 50}, "hatch":   {"weight": 20}, "hollow":  {"weight": 10},
            "striped": {"weight": 10}, "dotted":  {"weight": 10},
        }
    },
    
    "realism_effects": {
        "blur":               {"p": 0.1, "params": {"radius_range": (0.25, 0.50)}},
        "motion_blur":        {"p": 0.15, "params": {"radius_range": (2, 5), "angle_range": (0, 360)}},
        "low_res":            {"p": 0.15, "params": {"scale_range": (0.25, 0.4)}},
        "noise":              {"p": 0.05, "params": {"sigma_range": (1, 4)}},
        "jpeg_compression":   {"p": 0.20, "params": {"quality_range": (50, 90)}},
        "pixelation":         {"p": 0.05, "params": {"factor_options": [2, 3]}},
        "posterize":          {"p": 0.05, "params": {"color_options": [16, 32, 64]}},
        "color_variation":    {"p": 0.05, "params": {"shift_range": (0.97, 1.03)}},
        "ui_chrome":          {"p": 0.05, "params": {}},
        "watermark":          {"p": 0.05, "params": {"opacity_range": (0.04, 0.12)}},
        "vignette":           {"p": 0.05, "params": {}},
        "scanner_streaks":    {"p": 0.05, "params": {}},
        "clipping":           {"p": 0.0, "params": {"clip_range_pct": (0.01, 0.04)}},
        "printing_artifacts": {"p": 0.05, "params": {"texture_alpha": (0.05, 0.1), "blur_radius": (0.2, 0.4)}},
        "mouse_cursor":       {"p": 0.05, "params": {}},
        "text_degradation":   {"p": 0.05, "params": {"blur_radius_range": (0.4, 0.6), "pixelate_scale_options": [2, 3]}},
        "grid_occlusion":     {"p": 0.0, "params": {}},
        "scan_rotation":      {"p": 0.0, "params": {"angle_range": (-1, 1)}},
        "grayscale":          {"p": 0.05, "params": {}},
        "perspective":        {"p": 0.0, "params": {"magnitude": 0.5}},
    },
    
    # Post-processing options
    "merge_json_files": True,  # Set to True to merge the 3 JSON files into 1 comprehensive JSON
}

# Chart-type-specific class maps
CHART_CLASS_MAPS = {
    'bar': GENERATION_CONFIG['CLASS_MAP_BAR'],
    'scatter': GENERATION_CONFIG['CLASS_MAP_SCATTER'],
    'box': GENERATION_CONFIG['CLASS_MAP_BOX'],
    'histogram': GENERATION_CONFIG['CLASS_MAP_HISTOGRAM'],
    'heatmap': GENERATION_CONFIG['CLASS_MAP_HEATMAP'],
    'area_obj': GENERATION_CONFIG['CLASS_MAP_AREA_OBJ'], 
    'area_pose': GENERATION_CONFIG['CLASS_MAP_AREA_POSE'],
    'pie_obj': GENERATION_CONFIG['CLASS_MAP_PIE_OBJ'],
    'pie_pose': GENERATION_CONFIG['CLASS_MAP_PIE_POSE'],
    'line_obj': GENERATION_CONFIG['CLASS_MAP_LINE_OBJ'],
    'line_pose': GENERATION_CONFIG['CLASS_MAP_LINE_POSE']   
}

# ===================================================================================
# == UTILITY FUNCTIONS
# ===================================================================================

def is_float(text):
    try:
        float(text)
        return True
    except (ValueError, TypeError):
        return False

def ensure_dir(d):
    if not os.path.exists(d):
        os.makedirs(d, exist_ok=True)

def bbox_to_yolo_norm(x0, y0, x1, y1, img_w, img_h):
    if img_w == 0 or img_h == 0: 
        return 0, 0, 0, 0
    dw = 1. / img_w
    dh = 1. / img_h
    x = (x0 + x1) / 2.0
    y = (y0 + y1) / 2.0
    w = x1 - x0
    h = y1 - y0
    return x * dw, y * dh, w * dw, h * dh

def bbox_to_xyxy(bbox, img_h):
    """Convert matplotlib bbox to [x0, y0, x1, y1] xyxy format"""
    if hasattr(bbox, 'extents'):
        x0, y0, x1, y1 = bbox.extents
    else:
        x0, y0, x1, y1 = bbox
    return [int(x0), int(img_h - y1), int(x1), int(img_h - y0)]

def bbox_to_xyxy_absolute(bbox, img_h):
    """Convert matplotlib bbox to [x0, y0, x1, y1] absolute xyxy format"""
    if hasattr(bbox, 'extents'):
        x0, y0, x1, y1 = bbox.extents
    else:
        x0, y0, x1, y1 = bbox
    # Convert from matplotlib coordinates to image coordinates
    abs_y0 = int(img_h - y1)
    abs_y1 = int(img_h - y0)
    return [int(x0), abs_y0, int(x1), abs_y1]

def create_reverse_class_map(cls_map):
    """Create reverse mapping: class_name -> class_id"""
    return {v: k for k, v in cls_map.items()}

def get_granular_annotations(fig, chart_info_map, cls_map):
    """
    ENHANCED VERSION WITH CRITICAL BUG FIXES
    
    Key fixes:
    1. Proper artist visibility validation
    2. Robust bounding box calculation with error handling
    3. Enhanced artist type detection for Rectangle objects
    4. Improved add_unique_annotation filtering
    5. Comprehensive debug logging
    6. Fixed class map lookup to handle integer keys correctly
    """
    
    # CRITICAL FIX: Create reverse map for string lookups
    reverse_map = create_reverse_class_map(cls_map)
    
    # CRITICAL FIX: Ensure renderer is ready
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    if renderer is None:
        print("WARNING: Could not obtain renderer, annotations will be empty")
        return []
    
    annotations = []
    fig_bbox = fig.get_window_extent(renderer)
    seen_annotations = set()
    
    def add_unique_annotation(class_id, bbox):
        """FIXED: More robust bbox validation"""
        if bbox is None:
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: Skipping annotation - bbox is None")
            return False
            
        # Handle different bbox types
        try:
            if hasattr(bbox, 'width') and hasattr(bbox, 'height'):
                width, height = bbox.width, bbox.height
                x0, y0, x1, y1 = bbox.x0, bbox.y0, bbox.x1, bbox.y1
            elif hasattr(bbox, 'extents'):
                x0, y0, x1, y1 = bbox.extents
                width, height = x1 - x0, y1 - y0
            else:
                x0, y0, x1, y1 = bbox
                width, height = x1 - x0, y1 - y0
                
        except (AttributeError, ValueError, TypeError) as e:
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: Bbox extraction failed: {e}")
            return False
        
        # CRITICAL FIX: More lenient size validation
        if width <= 0.5 or height <= 0.5:  # Was > 1, now > 0.5
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: Bbox too small - w:{width:.2f}, h:{height:.2f}")
            return False
            
        # CRITICAL FIX: More precise deduplication
        key = (class_id, round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1))  # Was 2 decimals, now 1
        if key not in seen_annotations:
            annotations.append({'class_id': class_id, 'bbox': bbox})
            seen_annotations.add(key)
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: Added annotation - class:{class_id}, bbox:[{x0:.1f},{y0:.1f},{x1:.1f},{y1:.1f}]")
            return True
        else:
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: Duplicate annotation filtered - class:{class_id}")
            return False
    
    for ax_idx, ax in enumerate(fig.axes):
        if not ax.get_visible():
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: AX[{ax_idx}]: Skipping invisible axis")
            continue
            
        chart_info = chart_info_map.get(ax, {})
        chart_type = chart_info.get('chart_type_str')
        
        if GENERATION_CONFIG.get('debug_mode', False):
            print(f"DEBUG: AX[{ax_idx}]: Processing chart_type={chart_type}")
        
        # CRITICAL FIX: Enhanced Chart Title detection
        if 'chart_title' in reverse_map:
            title = ax.title
            if title and title.get_visible() and title.get_text().strip():
                try:
                    title_bbox = title.get_window_extent(renderer)
                    if add_unique_annotation(reverse_map['chart_title'], title_bbox):
                        if GENERATION_CONFIG.get('debug_mode', False):
                            print(f"DEBUG: AX[{ax_idx}]: Added chart title annotation")
                except Exception as e:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Chart title bbox failed: {e}")
        
        # CRITICAL FIX: Enhanced Legend detection
        if 'legend' in reverse_map:
            legend = ax.get_legend()
            if legend and legend.get_visible():
                try:
                    legend_bbox = legend.get_window_extent(renderer)
                    if add_unique_annotation(reverse_map['legend'], legend_bbox):
                        if GENERATION_CONFIG.get('debug_mode', False):
                            print(f"DEBUG: AX[{ax_idx}]: Added legend annotation")
                except Exception as e:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Legend bbox failed: {e}")
        
        # CRITICAL FIX: Enhanced Axis Title detection
        if 'axis_title' in reverse_map:
            # X-axis title
            if ax.xaxis.label.get_visible() and ax.xaxis.label.get_text().strip():
                try:
                    xlabel_bbox = ax.xaxis.label.get_window_extent(renderer)
                    if add_unique_annotation(reverse_map['axis_title'], xlabel_bbox):
                        if GENERATION_CONFIG.get('debug_mode', False):
                            print(f"DEBUG: AX[{ax_idx}]: Added x-axis title annotation")
                except Exception as e:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: X-axis title bbox failed: {e}")
            
            # Y-axis title  
            if ax.yaxis.label.get_visible() and ax.yaxis.label.get_text().strip():
                try:
                    ylabel_bbox = ax.yaxis.label.get_window_extent(renderer)
                    if add_unique_annotation(reverse_map['axis_title'], ylabel_bbox):
                        if GENERATION_CONFIG.get('debug_mode', False):
                            print(f"DEBUG: AX[{ax_idx}]: Added y-axis title annotation")
                except Exception as e:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Y-axis title bbox failed: {e}")
        
        # CRITICAL FIX: Enhanced Axis Labels detection
        if 'axis_labels' in reverse_map:
            scale_axis_info = chart_info.get('scale_axis_info', {})
            primary_scale_axis = scale_axis_info.get('primary_scale_axis', 'y')
            
            # X-axis labels
            x_labels_added = 0
            for label in ax.get_xticklabels():
                if label.get_visible() and label.get_text().strip():
                    try:
                        label_bbox = label.get_window_extent(renderer)
                        if add_unique_annotation(reverse_map['axis_labels'], label_bbox):
                            x_labels_added += 1
                    except Exception as e:
                        if GENERATION_CONFIG.get('debug_mode', False):
                            print(f"DEBUG: AX[{ax_idx}]: X-label bbox failed: {e}")
                            
            # Y-axis labels
            y_labels_added = 0
            for label in ax.get_yticklabels():
                if label.get_visible() and label.get_text().strip():
                    try:
                        label_bbox = label.get_window_extent(renderer)
                        if add_unique_annotation(reverse_map['axis_labels'], label_bbox):
                            y_labels_added += 1
                    except Exception as e:
                        if GENERATION_CONFIG.get('debug_mode', False):
                            print(f"DEBUG: AX[{ax_idx}]: Y-label bbox failed: {e}")
                            
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: AX[{ax_idx}]: Added {x_labels_added} x-labels, {y_labels_added} y-labels")
        
        # CRITICAL FIX: Enhanced Bar chart data artist processing
        if chart_type == 'bar' and 'bar' in reverse_map:
            data_artists = chart_info.get('data_artists', [])
            bars_added = 0
            
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: AX[{ax_idx}]: Processing {len(data_artists)} bar data artists")
            
            for artist_idx, artist in enumerate(data_artists):
                if artist is None:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Artist {artist_idx} is None")
                    continue
                    
                # Enhanced visibility check
                try:
                    is_visible = artist.get_visible()
                except:
                    is_visible = True  # Assume visible if check fails
                    
                if not is_visible:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Artist {artist_idx} not visible")
                    continue
                
                # CRITICAL FIX: More robust Rectangle detection
                is_rectangle = (isinstance(artist, patches.Rectangle) or 
                              str(type(artist).__name__) == 'Rectangle' or
                              hasattr(artist, 'get_x') and hasattr(artist, 'get_y') and 
                              hasattr(artist, 'get_width') and hasattr(artist, 'get_height'))
                
                if is_rectangle:
                    try:
                        # CRITICAL FIX: Enhanced bbox extraction
                        artist_bbox = artist.get_window_extent(renderer)
                        if artist_bbox and add_unique_annotation(reverse_map['bar'], artist_bbox):
                            bars_added += 1
                            if GENERATION_CONFIG.get('debug_mode', False):
                                print(f"DEBUG: AX[{ax_idx}]: Added bar annotation #{artist_idx}")
                    except Exception as e:
                        if GENERATION_CONFIG.get('debug_mode', False):
                            print(f"DEBUG: AX[{ax_idx}]: Bar bbox failed for artist {artist_idx}: {e}")
                else:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Artist {artist_idx} type: {type(artist).__name__} - not Rectangle")
                        
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: AX[{ax_idx}]: Successfully added {bars_added} bar annotations")

        elif chart_type == 'histogram':
            # HISTOGRAM - FIX AXIS TITLE vs AXIS LABELS CONFUSION
            debug = GENERATION_CONFIG.get('debug_mode', False)
            if debug:
                print(f"DEBUG [AX{ax_idx}] HISTOGRAM axis processing override")
            
            # Override the general axis processing for histograms
            if 'axis_title' in reverse_map:
                titles_added = 0
                # Axis TITLES (xlabel/ylabel - these should be axis_title)
                if ax.xaxis.label.get_visible() and ax.xaxis.label.get_text().strip():
                    try:
                        xlabel_bbox = ax.xaxis.label.get_window_extent(renderer)
                        if add_unique_annotation(reverse_map['axis_title'], xlabel_bbox):
                            titles_added += 1
                            if debug:
                                print(f"DEBUG [AX{ax_idx}] Added histogram X-axis TITLE")
                    except Exception as e:
                        if debug:
                            print(f"DEBUG [AX{ax_idx}] Histogram X-title error: {e}")
                
                # X-axis title
                if ax.yaxis.label.get_visible() and ax.yaxis.label.get_text().strip():
                    try:
                        ylabel_bbox = ax.yaxis.label.get_window_extent(renderer)
                        if add_unique_annotation(reverse_map['axis_title'], ylabel_bbox):
                            titles_added += 1
                            if debug:
                                print(f"DEBUG [AX{ax_idx}] Added histogram Y-axis TITLE")
                    except Exception as e:
                        if debug:
                            print(f"DEBUG [AX{ax_idx}] Histogram Y-title error: {e}")
                
                if debug:
                    print(f"DEBUG [AX{ax_idx}] HISTOGRAM axis titles: {titles_added}")
                # Y-axis title
            
            if 'axis_labels' in reverse_map:
                labels_added = 0
                # Axis LABELS (tick labels - these should be axis_labels)
                for label in ax.get_xticklabels():
                    if label.get_visible() and label.get_text().strip():
                        try:
                            label_bbox = label.get_window_extent(renderer)
                            if add_unique_annotation(reverse_map['axis_labels'], label_bbox):
                                labels_added += 1
                        except Exception as e:
                            if debug:
                                print(f"DEBUG [AX{ax_idx}] Histogram X-label error: {e}")
                
                # X-axis tick labels
                for label in ax.get_yticklabels():
                    if label.get_visible() and label.get_text().strip():
                        try:
                            label_bbox = label.get_window_extent(renderer)
                            if add_unique_annotation(reverse_map['axis_labels'], label_bbox):
                                labels_added += 1
                        except Exception as e:
                            if debug:
                                print(f"DEBUG [AX{ax_idx}] Histogram Y-label error: {e}")
                
                if debug:
                    print(f"DEBUG [AX{ax_idx}] HISTOGRAM axis labels: {labels_added}")
                # Y-axis tick labels
            
            # **NEW: Add data label annotation for histogram**
            if 'data_label' in reverse_map:
                data_labels_added = 0
                other_artists = chart_info.get('other_artists', [])
                
                if debug:
                    print(f"DEBUG [AX{ax_idx}] Processing {len(other_artists)} other_artists for data labels")
                
                # Data labels are stored in other_artists (text annotations)
                for artist_idx, artist in enumerate(other_artists):
                    # Check if artist is a Text object
                    if hasattr(artist, 'get_text') and hasattr(artist, 'get_window_extent'):
                        try:
                            # Verify it's visible and has content
                            if artist.get_visible() and artist.get_text().strip():
                                label_bbox = artist.get_window_extent(renderer)
                                
                                if add_unique_annotation(reverse_map['data_label'], label_bbox):
                                    data_labels_added += 1
                                    if debug:
                                        print(f"DEBUG [AX{ax_idx}] Added data label: '{artist.get_text()}'")
                        except Exception as e:
                            if debug:
                                print(f"DEBUG [AX{ax_idx}] Data label bbox failed for artist {artist_idx}: {e}")
                
                if debug:
                    print(f"DEBUG [AX{ax_idx}] HISTOGRAM data labels: {data_labels_added}")

        # Enhanced Box plot processing with fallback
        elif chart_type == 'box':
            bp_artists = chart_info.get('boxplot_dict')
            
            if GENERATION_CONFIG.get('debug_mode', False):
                print(f"DEBUG: AX[{ax_idx}]: Boxplot dict: {bp_artists is not None} | Keys: {list(bp_artists.keys()) if bp_artists else 'None'}")
                print(f"DEBUG: AX[{ax_idx}]: Boxes: {len(bp_artists.get('boxes', [])) if bp_artists else 0}")
            
            boxes_processed = False
            if bp_artists and bp_artists.get('boxes'):
                if GENERATION_CONFIG.get('debug_mode', False):
                    print(f"DEBUG: AX[{ax_idx}]: Processing boxplot with {len(bp_artists['boxes'])} boxes")
                
                # Boxes
                if 'box' in reverse_map:
                    added = 0
                    for box_artist in bp_artists['boxes']:
                        if box_artist and box_artist.get_visible():
                            try:
                                bbox = box_artist.get_window_extent(renderer)
                                if bbox.width > 0.5 and bbox.height > 0.5 and add_unique_annotation(reverse_map['box'], bbox):
                                    added += 1
                            except Exception as e:
                                if GENERATION_CONFIG.get('debug_mode', False):
                                    print(f"DEBUG: AX[{ax_idx}]: Box bbox error: {e}")
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Added {added} box annotations")
                
                # Medians
                if 'median_line' in reverse_map:
                    added = 0
                    for median in bp_artists.get('medians', []):
                        if median and median.get_visible():
                            try:
                                orig_bbox = median.get_window_extent(renderer)
                                # CRITICAL FIX: Always pad FIRST, then check size
                                pad = 3
                                padded = transforms.Bbox.from_extents(
                                    orig_bbox.x0, orig_bbox.y0 - pad,
                                    orig_bbox.x1, orig_bbox.y1 + pad
                                )
                                
                                # Check padded bbox (not original)
                                if padded.width > 0.5 and padded.height > 0.5:
                                    if add_unique_annotation(reverse_map['median_line'], padded):
                                        added += 1
                            except Exception as e:
                                if GENERATION_CONFIG.get('debug_mode', False):
                                    print(f"DEBUG: AX[{ax_idx}]: Median error: {e}")
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Added {added} median annotations")
                
                # Range indicators (Whiskers and Caps)
                if 'range_indicator' in reverse_map:
                    added = 0
                    num_boxes = len(bp_artists.get('boxes', []))
                    whiskers = bp_artists.get('whiskers', [])
                    caps = bp_artists.get('caps', [])
                    for i in range(num_boxes):
                        try:
                            artists = []
                            idxs = [2*i, 2*i + 1]
                            for idx in idxs:
                                if len(whiskers) > idx and whiskers[idx]:
                                    artists.append(whiskers[idx])
                                if len(caps) > idx and caps[idx]:
                                    artists.append(caps[idx])
                            
                            bboxes = []
                            for art in artists:
                                if art and art.get_visible():
                                    try:
                                        bbox = art.get_window_extent(renderer)
                                        if bbox:
                                            # Always add the bbox; zero-width or zero-height elements should be padded
                                            width, height = bbox.width, bbox.height
                                            if width <= 0.5 or height <= 0.5:
                                                # Pad thin elements to make them detectable
                                                min_size = 3
                                                padded_bbox = transforms.Bbox.from_extents(
                                                    bbox.x0 - min_size/2, bbox.y0 - min_size/2,
                                                    bbox.x1 + min_size/2, bbox.y1 + min_size/2
                                                )
                                                bboxes.append(padded_bbox)
                                            else:
                                                # Normal elements (both width and height > 0.5)
                                                bboxes.append(bbox)
                                    except Exception as e:
                                        if GENERATION_CONFIG.get('debug_mode', False):
                                            print(f"DEBUG: AX[{ax_idx}]: Error processing range indicator artist: {e}")
                                        pass
                            
                            if bboxes:
                                union_bbox = transforms.Bbox.union(bboxes)
                                if union_bbox.width > 0.5 and add_unique_annotation(reverse_map['range_indicator'], union_bbox):
                                    added += 1
                        except Exception as e:
                            if GENERATION_CONFIG.get('debug_mode', False):
                                print(f"DEBUG: AX[{ax_idx}]: Range {i} error: {e}")
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Added {added} range annotations")
                
                # Outliers (Fliers)
                if 'outlier' in reverse_map:
                    added = 0
                    for flier in bp_artists.get('fliers', []):
                        if flier and flier.get_visible():
                            try:
                                xdata, ydata = flier.get_xdata(), flier.get_ydata()
                                for x, y in zip(xdata, ydata):
                                    px, py = ax.transData.transform_point((x, y))
                                    size = 3
                                    bbox = transforms.Bbox.from_extents(
                                        px - size, py - size, px + size, py + size
                                    )
                                    if bbox.width > 0.5 and add_unique_annotation(reverse_map['outlier'], bbox):
                                        added += 1
                            except Exception as e:
                                if GENERATION_CONFIG.get('debug_mode', False):
                                    print(f"DEBUG: AX[{ax_idx}]: Outlier error: {e}")
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Added {added} outlier annotations")
                
                boxes_processed = True
            
            # FALLBACK: If boxplot_dict failed, use data_artists
            if not boxes_processed and 'box' in reverse_map:
                added = 0
                for artist in chart_info.get('data_artists', []):
                    if isinstance(artist, patches.Rectangle) and artist.get_visible():
                        try:
                            bbox = artist.get_window_extent(renderer)
                            if bbox.width > 0.5 and add_unique_annotation(reverse_map['box'], bbox):
                                added += 1
                        except Exception as e:
                            if GENERATION_CONFIG.get('debug_mode', False):
                                print(f"DEBUG: AX[{ax_idx}]: Fallback box error: {e}")
                if GENERATION_CONFIG.get('debug_mode', False):
                    print(f"DEBUG: AX[{ax_idx}]: Fallback added {added} box annotations from data_artists")
        
        # === SCATTER CHARTS - INDIVIDUAL POINT ANNOTATION (ENHANCED DEBUG) ===
        elif chart_type == 'scatter' and 'data_point' in reverse_map:
            data_artists = chart_info.get('data_artists', [])
            points_added = 0
            debug = GENERATION_CONFIG.get('debug_mode', False)

            if debug:
                print(f"DEBUG: AX[{ax_idx}]: SCATTER processing {len(data_artists)} artists")

            for artist_idx, artist in enumerate(data_artists):
                if debug:
                    print(f"DEBUG: AX[{ax_idx}]: Artist {artist_idx}: {type(artist).__name__}")

                if not isinstance(artist, PathCollection):
                    if debug:
                        print(f"DEBUG: AX[{ax_idx}]: Not PathCollection, skipping")
                    continue

                try:
                    offsets = artist.get_offsets()
                    sizes = artist.get_sizes()

                    if debug:
                        print(f"DEBUG: AX[{ax_idx}]: Offsets: {offsets.shape}, Sizes: {sizes}")

                    if len(offsets) == 0:
                        if debug:
                            print(f"DEBUG: AX[{ax_idx}]: No offsets")
                        continue

                    is_uniform_size = (sizes.size == 1)
                    # CRITICAL: Use figure DPI for proper pixel conversion
                    points_to_pixels = 72.0 / fig.dpi

                    if debug:
                        print(f"DEBUG: AX[{ax_idx}]: DPI={fig.dpi}, conversion={points_to_pixels}")
                        print(f"DEBUG: AX[{ax_idx}]: Will process {len(offsets)} points")

                    # CRITICAL: Annotate each point individually
                    for i, (x_data, y_data) in enumerate(offsets):
                        px, py = ax.transData.transform_point((x_data, y_data))
                        s = sizes[0] if is_uniform_size else sizes[i]
                        radius = (np.sqrt(s) / np.sqrt(np.pi)) * points_to_pixels

                        bbox = transforms.Bbox.from_extents(
                            px - radius, py - radius, px + radius, py + radius
                        )

                        if debug and i < 3:
                            print(f"DEBUG: Point {i}: data=({x_data:.2f},{y_data:.2f}) → "
                                  f"display=({px:.1f},{py:.1f}), size={s:.1f}, radius={radius:.2f}")

                        if bbox.width > 0.5 and bbox.height > 0.5:
                            if add_unique_annotation(reverse_map['data_point'], bbox):
                                points_added += 1
                                if debug and i < 3:
                                    print(f"DEBUG: Point {i}: ADDED")
                        else:
                            if debug and i < 3:
                                print(f"DEBUG: Point {i}: TOO SMALL")
                except Exception as e:
                    if debug:
                        print(f"DEBUG: AX[{ax_idx}]: Scatter error: {e}")
                        import traceback
                        traceback.print_exc()

            if debug:
                print(f"DEBUG: AX[{ax_idx}]: SCATTER TOTAL: {points_added} points added")

        # === HEATMAP CHARTS - CELLS AND COLORBAR ===
        elif chart_type == 'heatmap':
            cells_added = 0
            colorbar_added = 0
            debug = GENERATION_CONFIG.get('debug_mode', False)

            if debug:
                print(f"DEBUG: AX[{ax_idx}]: HEATMAP processing")

            # CRITICAL: Individual cell annotation
            if 'cell' in reverse_map:
                data_artists = chart_info.get('data_artists', [])

                for artist_idx, artist in enumerate(data_artists):
                    if debug:
                        print(f"DEBUG: AX[{ax_idx}]: Heatmap artist {artist_idx}: {type(artist).__name__}")

                    if not isinstance(artist, QuadMesh):
                        if debug:
                            print(f"DEBUG: AX[{ax_idx}]: Not QuadMesh, skipping")
                        continue

                    try:
                        # Get individual cell paths from QuadMesh
                        paths = artist.get_paths()

                        if debug:
                            print(f"DEBUG: AX[{ax_idx}]: QuadMesh has {len(paths)} cell paths")

                        # CRITICAL: Annotate each cell individually
                        for cell_idx, path in enumerate(paths):
                            vertices = path.vertices

                            if len(vertices) < 4:
                                continue

                            # Transform vertices to display coordinates
                            display_coords = ax.transData.transform(vertices)

                            x_min = np.min(display_coords[:, 0])
                            y_min = np.min(display_coords[:, 1])
                            x_max = np.max(display_coords[:, 0])
                            y_max = np.max(display_coords[:, 1])

                            bbox = transforms.Bbox.from_extents(x_min, y_min, x_max, y_max)

                            if debug and cell_idx < 5:
                                print(f"DEBUG: Cell {cell_idx}: bbox=[{x_min:.1f},{y_min:.1f},"
                                      f"{x_max:.1f},{y_max:.1f}], w={bbox.width:.1f}, h={bbox.height:.1f}")

                            # Use smaller threshold for heatmap cells
                            if bbox.width > 1.0 and bbox.height > 1.0:
                                if add_unique_annotation(reverse_map['cell'], bbox):
                                    cells_added += 1
                                    if debug and cell_idx < 5:
                                        print(f"DEBUG: Cell {cell_idx}: ADDED")
                            elif debug and cell_idx < 5:
                                print(f"DEBUG: Cell {cell_idx}: TOO SMALL")

                    except Exception as e:
                        if debug:
                            print(f"DEBUG: AX[{ax_idx}]: Heatmap cell error: {e}")

            # CRITICAL: Colorbar annotation
            if 'color_bar' in reverse_map:
                # Search all figure axes for colorbar
                for ax_candidate in fig.axes:
                    if ax_candidate == ax:
                        continue  # Skip main heatmap axis

                    try:
                        ax_bbox = ax_candidate.get_window_extent(renderer)

                        if ax_bbox.height == 0 or ax_bbox.width == 0:
                            continue

                        aspect_ratio = ax_bbox.width / ax_bbox.height

                        if debug:
                            print(f"DEBUG: AX[{ax_idx}]: Potential colorbar axis: "
                                  f"aspect={aspect_ratio:.2f}, size=({ax_bbox.width:.1f}x{ax_bbox.height:.1f})")

                        # Colorbar detection heuristics
                        is_vertical_colorbar = (aspect_ratio < 0.3 and ax_bbox.height > 50)
                        is_horizontal_colorbar = (aspect_ratio > 3.0 and ax_bbox.width > 50)

                        if is_vertical_colorbar or is_horizontal_colorbar:
                            if add_unique_annotation(reverse_map['color_bar'], ax_bbox):
                                colorbar_added += 1
                                if debug:
                                    print(f"DEBUG: AX[{ax_idx}]: COLORBAR ADDED "
                                          f"({'vertical' if is_vertical_colorbar else 'horizontal'})")
                            break
                    except Exception as e:
                        if debug:
                            print(f"DEBUG: AX[{ax_idx}]: Colorbar detection error: {e}")

            if debug:
                print(f"DEBUG: AX[{ax_idx}]: HEATMAP TOTAL: {cells_added} cells, {colorbar_added} colorbar")
        
        # === HISTOGRAM - FIX AXIS TITLE vs AXIS LABELS CONFUSION ===
        elif chart_type == 'histogram':
            # Override the general axis processing for histograms
            debug = GENERATION_CONFIG.get('debug_mode', False)

            if debug:
                print(f"DEBUG: AX[{ax_idx}]: HISTOGRAM axis processing override")

            # CRITICAL: Distinguish between axis TITLES and axis LABELS (tick labels)

            # Axis TITLES (xlabel/ylabel) - these should be 'axis_title'
            if 'axis_title' in reverse_map:
                titles_added = 0

                # X-axis title
                if ax.xaxis.label.get_visible() and ax.xaxis.label.get_text().strip():
                    try:
                        xlabel_bbox = ax.xaxis.label.get_window_extent(renderer)
                        if add_unique_annotation(reverse_map['axis_title'], xlabel_bbox):
                            titles_added += 1
                            if debug:
                                print(f"DEBUG: AX[{ax_idx}]: Added histogram X-axis TITLE")
                    except Exception as e:
                        if debug:
                            print(f"DEBUG: AX[{ax_idx}]: Histogram X-title error: {e}")

                # Y-axis title
                if ax.yaxis.label.get_visible() and ax.yaxis.label.get_text().strip():
                    try:
                        ylabel_bbox = ax.yaxis.label.get_window_extent(renderer)
                        if add_unique_annotation(reverse_map['axis_title'], ylabel_bbox):
                            titles_added += 1
                            if debug:
                                print(f"DEBUG: AX[{ax_idx}]: Added histogram Y-axis TITLE")
                    except Exception as e:
                        if debug:
                            print(f"DEBUG: AX[{ax_idx}]: Histogram Y-title error: {e}")

                if debug:
                    print(f"DEBUG: AX[{ax_idx}]: HISTOGRAM axis titles: {titles_added}")

            # Axis LABELS (tick labels) - these should be 'axis_labels' 
            if 'axis_labels' in reverse_map:
                labels_added = 0

                # X-axis tick labels
                for label in ax.get_xticklabels():
                    if label.get_visible() and label.get_text().strip():
                        try:
                            label_bbox = label.get_window_extent(renderer)
                            if add_unique_annotation(reverse_map['axis_labels'], label_bbox):
                                labels_added += 1
                        except Exception as e:
                            if debug:
                                print(f"DEBUG: AX[{ax_idx}]: Histogram X-label error: {e}")

                # Y-axis tick labels  
                for label in ax.get_yticklabels():
                    if label.get_visible() and label.get_text().strip():
                        try:
                            label_bbox = label.get_window_extent(renderer)
                            if add_unique_annotation(reverse_map['axis_labels'], label_bbox):
                                labels_added += 1
                        except Exception as e:
                            if debug:
                                print(f"DEBUG: AX[{ax_idx}]: Histogram Y-label error: {e}")

                if debug:
                    print(f"DEBUG: AX[{ax_idx}]: HISTOGRAM axis labels: {labels_added}")

        # Line chart keypoints
        elif chart_type == 'line' and chart_info.get('keypoint_info'):
            for series_kpts in chart_info['keypoint_info']:
                series_idx = series_kpts['series_idx']
                
                # Start/end points
                for pt_type, pt_data in [('line_start', series_kpts['start']), ('line_end', series_kpts['end'])]:
                    if pt_type in reverse_map:
                        x, y, idx = pt_data
                        px, py = ax.transData.transform_point((x, y))
                        bbox = transforms.Bbox.from_extents(px-4, py-4, px+4, py+4)
                        add_unique_annotation(reverse_map[pt_type], bbox)
                
                # Inflection points
                if 'inflection_point' in reverse_map:
                    for x, y, idx in series_kpts['inflections']:
                        px, py = ax.transData.transform_point((x, y))
                        bbox = transforms.Bbox.from_extents(px-3, py-3, px+3, py+3)
                        add_unique_annotation(reverse_map['inflection_point'], bbox)

        # Area chart keypoints (similar structure to line)
        elif chart_type == 'area' and chart_info.get('keypoint_info'):
            for series_kpts in chart_info['keypoint_info']:
                if 'area_start' in reverse_map:
                    x, y, idx = series_kpts['start']
                    px, py = ax.transData.transform_point((x, y))
                    bbox = transforms.Bbox.from_extents(px-4, py-4, px+4, py+4)
                    add_unique_annotation(reverse_map['area_start'], bbox)
                
                if 'inflection_point' in reverse_map:
                    for x, y, idx in series_kpts['inflections']:
                        px, py = ax.transData.transform_point((x, y))
                        bbox = transforms.Bbox.from_extents(px-3, py-3, px+3, py+3)
                        add_unique_annotation(reverse_map['inflection_point'], bbox)

        # Pie chart geometric keypoints
        elif chart_type == 'pie' and chart_info.get('pie_geometry'):
            pie_geo = chart_info['pie_geometry']
            
            # Center point
            if 'center_point' in reverse_map and 'center_point' in pie_geo:
                cx, cy = pie_geo['center_point']
                px, py = ax.transData.transform_point((cx, cy))
                bbox = transforms.Bbox.from_extents(px-5, py-5, px+5, py+5)
                add_unique_annotation(reverse_map['center_point'], bbox)
            
            # Arc boundaries for each wedge
            if 'arc_boundary' in reverse_map:
                for wedge_geo in pie_geo['wedges']:
                    for arc_pt in ['arc_start', 'arc_end', 'arc_mid']:
                        ax_pt, ay_pt = wedge_geo[arc_pt]
                        px, py = ax.transData.transform_point((ax_pt, ay_pt))
                        bbox = transforms.Bbox.from_extents(px-3, py-3, px+3, py+3)
                        add_unique_annotation(reverse_map['arc_boundary'], bbox)
            
            # Wedge centers
            if 'wedge_center' in reverse_map:
                for wedge_geo in pie_geo['wedges']:
                    wx, wy = wedge_geo['wedge_label_point']
                    px, py = ax.transData.transform_point((wx, wy))
                    bbox = transforms.Bbox.from_extents(px-4, py-4, px+4, py+4)
                    add_unique_annotation(reverse_map['wedge_center'], bbox)
        
        # Process other artists for error bars, text annotations, etc.
        other_artists = chart_info.get('other_artists', [])
        if GENERATION_CONFIG.get('debug_mode', False):
            print(f"DEBUG: AX[{ax_idx}]: Processing {len(other_artists)} other artists")
            
        for artist_idx, artist in enumerate(other_artists):
            if artist is None:
                continue
                
            try:
                is_visible = artist.get_visible()
            except:
                is_visible = True
                
            if not is_visible:
                continue
            
            # Error bars
            if hasattr(artist, 'lines') and len(getattr(artist, 'lines', [])) >= 3 and 'error_bar' in reverse_map:
                try:
                    # ErrorbarContainer processing
                    plotline, caplines, barlinecols = artist.lines
                    if barlinecols and caplines:
                        artist_bbox = artist.get_window_extent(renderer)
                        add_unique_annotation(reverse_map['error_bar'], artist_bbox)
                except Exception as e:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Error bar processing failed: {e}")
            
            # Text annotations
            elif hasattr(artist, 'get_text'):
                try:
                    text_content = artist.get_text().strip()
                    if text_content:
                        # Significance markers
                        if text_content in ['*', '**', '***', 'ns', 'a', 'b', 'c', 'd'] and 'significance_marker' in reverse_map:
                            artist_bbox = artist.get_window_extent(renderer)
                            add_unique_annotation(reverse_map['significance_marker'], artist_bbox)
                        # Data labels  
                        elif 'data_label' in reverse_map:
                            # Check if numeric
                            try:
                                float(text_content.replace('%', '').replace(',', ''))
                                artist_bbox = artist.get_window_extent(renderer)
                                add_unique_annotation(reverse_map['data_label'], artist_bbox)
                            except ValueError:
                                pass  # Not numeric
                except Exception as e:
                    if GENERATION_CONFIG.get('debug_mode', False):
                        print(f"DEBUG: AX[{ax_idx}]: Text processing failed: {e}")
    
        if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_annotations', False):
            print(f"DEBUG: Total annotations generated: {len(annotations)}")
            class_counts = {}
            for ann in annotations:
                class_id = ann['class_id']
                class_counts[class_id] = class_counts.get(class_id, 0) + 1
            print(f"DEBUG: Class distribution: {class_counts}")
        
        return annotations

def filter_overlapping_annotations(annotations, iou_threshold=0.7):
    """Remove annotations with high IoU overlap within the same class."""
    def bbox_iou(bbox1, bbox2):
        x1 = max(bbox1.x0, bbox2.x0)
        y1 = max(bbox1.y0, bbox2.y0)
        x2 = min(bbox1.x1, bbox2.x1)
        y2 = min(bbox1.y1, bbox2.y1)
        
        if x2 < x1 or y2 < y1:
            return 0.0
        
        inter_area = (x2 - x1) * (y2 - y1)
        bbox1_area = (bbox1.x1 - bbox1.x0) * (bbox1.y1 - bbox1.y0)
        bbox2_area = (bbox2.x1 - bbox2.x0) * (bbox2.y1 - bbox2.y0)
        union_area = bbox1_area + bbox2_area - inter_area
        
        return inter_area / union_area if union_area > 0 else 0.0
    
    by_class = defaultdict(list)
    for ann in annotations:
        by_class[ann['class_id']].append(ann)
    
    filtered = []
    for class_id, class_anns in by_class.items():
        class_anns.sort(key=lambda a: (a['bbox'].x1 - a['bbox'].x0) * (a['bbox'].y1 - a['bbox'].y0), reverse=True)
        
        keep = []
        for ann in class_anns:
            is_duplicate = False
            for kept_ann in keep:
                if bbox_iou(ann['bbox'], kept_ann['bbox']) > iou_threshold:
                    is_duplicate = True
                    break
            if not is_duplicate:
                keep.append(ann)
        
        filtered.extend(keep)
    
    return filtered


# In generator.py after filter_overlapping_annotations()
def extract_area_pose_annotations(fig, chart_info_map, clsmap_pose, img_w, img_h):
    """
    Extract pose-style annotations for area charts with keypoints.
    Returns list of dicts with class_id, bbox, and keypoints.
    """
    keypoint_annotations = []
    renderer = fig.canvas.get_renderer()
    
    for ax in fig.axes:
        if not ax.get_visible():
            continue
            
        chartinfo = chart_info_map.get(ax, {})
        charttype = chartinfo.get('chart_type_str', '')
        
        if charttype != 'area':
            continue
            
        keypoint_info = chartinfo.get('keypoint_info', [])
        if not keypoint_info:
            continue
            
        data_artists = chartinfo.get('data_artists', [])
        
        # Process each series
        for series_idx, (artist, series_kpts) in enumerate(zip(data_artists, keypoint_info)):
            # Extract area_fill bounding box from PolyCollection artist
            try:
                artist_bbox = artist.get_window_extent(renderer)
                x0, y0, x1, y1 = artist_bbox.x0, artist_bbox.y0, artist_bbox.x1, artist_bbox.y1
                
                # Convert to image coordinates
                img_y0 = img_h - y1
                img_y1 = img_h - y0
                
                # Normalize bbox coordinates
                x_center = ((x0 + x1) / 2.0) / img_w
                y_center = ((img_y0 + img_y1) / 2.0) / img_h
                width = (x1 - x0) / img_w
                height = (img_y1 - img_y0) / img_h
                
                # Clamp to [0, 1]
                x_center = max(0.0, min(1.0, x_center))
                y_center = max(0.0, min(1.0, y_center))
                width = max(0.0, min(1.0, width))
                height = max(0.0, min(1.0, height))
                
            except Exception as e:
                print(f"WARNING: Failed to extract area_fill bbox: {e}")
                continue
            
            # area_fill annotation (class 0)
            keypoints_fill = []
            
            # Extract boundary points as keypoints
            boundary_points = series_kpts.get('boundary_points', [])
            for x_data, y_data, idx in boundary_points:
                # Transform data coordinates to display coordinates
                px, py = ax.transData.transform_point((x_data, y_data))
                
                # Convert to image coordinates
                img_py = img_h - py
                
                # Normalize
                norm_x = px / img_w
                norm_y = img_py / img_h
                
                # Clamp
                norm_x = max(0.0, min(1.0, norm_x))
                norm_y = max(0.0, min(1.0, norm_y))
                
                keypoints_fill.append((norm_x, norm_y))
            
            keypoint_annotations.append({
                'class_id': int(clsmap_pose.get('area_fill', '0')),
                'bbox': [x_center, y_center, width, height],
                'keypoints': keypoints_fill
            })
            
            # area_boundary annotation (class 1)
            # Use same bbox as area_fill but keypoints are boundary line
            keypoints_boundary = keypoints_fill  # Same as fill for area charts
            
            keypoint_annotations.append({
                'class_id': int(clsmap_pose.get('area_boundary', '1')),
                'bbox': [x_center, y_center, width, height],
                'keypoints': keypoints_boundary
            })
            
            # inflection_point annotations (class 2)
            inflections = series_kpts.get('inflections', [])
            for x_data, y_data, idx in inflections:
                px, py = ax.transData.transform_point((x_data, y_data))
                img_py = img_h - py
                
                # Create small bbox around inflection point
                bbox_size = 8  # pixels
                norm_x = px / img_w
                norm_y = img_py / img_h
                norm_w = bbox_size / img_w
                norm_h = bbox_size / img_h
                
                # Single keypoint at inflection location
                keypoint_annotations.append({
                    'class_id': int(clsmap_pose.get('inflection_point', '2')),
                    'bbox': [
                        max(0.0, min(1.0, norm_x)),
                        max(0.0, min(1.0, norm_y)),
                        max(0.0, min(1.0, norm_w)),
                        max(0.0, min(1.0, norm_h))
                    ],
                    'keypoints': [(norm_x, norm_y)]
                })
            
            # area_start annotation (class 3)
            start_x, start_y, start_idx = series_kpts['start']
            px, py = ax.transData.transform_point((start_x, start_y))
            img_py = img_h - py
            
            norm_x = px / img_w
            norm_y = img_py / img_h
            bbox_size = 8
            
            keypoint_annotations.append({
                'class_id': int(clsmap_pose.get('area_start', '3')),
                'bbox': [
                    max(0.0, min(1.0, norm_x)),
                    max(0.0, min(1.0, norm_y)),
                    max(0.0, min(1.0, bbox_size / img_w)),
                    max(0.0, min(1.0, bbox_size / img_h))
                ],
                'keypoints': [(norm_x, norm_y)]
            })
            
            # area_end annotation (class 4)
            end_x, end_y, end_idx = series_kpts['end']
            px, py = ax.transData.transform_point((end_x, end_y))
            img_py = img_h - py
            
            norm_x = px / img_w
            norm_y = img_py / img_h
            
            keypoint_annotations.append({
                'class_id': int(clsmap_pose.get('area_end', '4')),
                'bbox': [
                    max(0.0, min(1.0, norm_x)),
                    max(0.0, min(1.0, norm_y)),
                    max(0.0, min(1.0, bbox_size / img_w)),
                    max(0.0, min(1.0, bbox_size / img_h))
                ],
                'keypoints': [(norm_x, norm_y)]
            })
    
    return keypoint_annotations


def extract_pie_pose_annotations(fig, chart_info_map, clsmap_pose, img_w, img_h):
    """
    Extract pose-style annotations for pie charts with keypoints.
    Returns list of dicts with class_id, bbox, and keypoints.
    """
    keypoint_annotations = []
    renderer = fig.canvas.get_renderer()
    
    for ax in fig.axes:
        if not ax.get_visible():
            continue
            
        chartinfo = chart_info_map.get(ax, {})
        charttype = chartinfo.get('chart_type_str', '')
        
        if charttype != 'pie':
            continue
            
        pie_geometry = chartinfo.get('pie_geometry', None)
        if not pie_geometry:
            continue
            
        # Extract center point (class 0)
        center_point = pie_geometry.get('center_point', None)
        if center_point:
            cx, cy = center_point
            px, py = ax.transData.transform_point((cx, cy))
            
            # Convert to image coordinates
            img_py = img_h - py
            
            # Normalize
            norm_x = px / img_w
            norm_y = img_py / img_h
            
            # Clamp
            norm_x = max(0.0, min(1.0, norm_x))
            norm_y = max(0.0, min(1.0, norm_y))
            
            # Create small bbox around center point
            bbox_size = 10  # pixels
            
            keypoint_annotations.append({
                'class_id': int(clsmap_pose.get('center_point', '0')),
                'bbox': [
                    max(0.0, min(1.0, norm_x)),
                    max(0.0, min(1.0, norm_y)),
                    max(0.0, min(1.0, bbox_size / img_w)),
                    max(0.0, min(1.0, bbox_size / img_h))
                ],
                'keypoints': [(norm_x, norm_y)]
            })
        
        # Extract wedge-level annotations
        wedges_info = pie_geometry.get('wedges', [])
        
        for wedge_geo in wedges_info:
            # Extract arc boundary points (class 1)
            arc_start = wedge_geo.get('arc_start', None)
            arc_end = wedge_geo.get('arc_end', None)
            arc_mid = wedge_geo.get('arc_mid', None)
            
            if arc_start and arc_end and arc_mid:
                # Collect arc boundary keypoints
                arc_keypoints = []
                
                for arc_pt in [arc_start, arc_end, arc_mid]:
                    px, py = ax.transData.transform_point(arc_pt)
                    img_py = img_h - py
                    
                    norm_x = max(0.0, min(1.0, px / img_w))
                    norm_y = max(0.0, min(1.0, img_py / img_h))
                    
                    arc_keypoints.append((norm_x, norm_y))
                
                # Calculate bbox encompassing all arc points
                all_x = [kp[0] for kp in arc_keypoints]
                all_y = [kp[1] for kp in arc_keypoints]
                
                bbox_x_min = min(all_x)
                bbox_x_max = max(all_x)
                bbox_y_min = min(all_y)
                bbox_y_max = max(all_y)
                
                bbox_x_center = (bbox_x_min + bbox_x_max) / 2.0
                bbox_y_center = (bbox_y_min + bbox_y_max) / 2.0
                bbox_width = bbox_x_max - bbox_x_min
                bbox_height = bbox_y_max - bbox_y_min
                
                keypoint_annotations.append({
                    'class_id': int(clsmap_pose.get('arc_boundary', '1')),
                    'bbox': [bbox_x_center, bbox_y_center, bbox_width, bbox_height],
                    'keypoints': arc_keypoints
                })
            
            # Extract wedge center (class 2)
            wedge_label_point = wedge_geo.get('wedge_label_point', None)
            if wedge_label_point:
                wx, wy = wedge_label_point
                px, py = ax.transData.transform_point((wx, wy))
                img_py = img_h - py
                
                norm_x = max(0.0, min(1.0, px / img_w))
                norm_y = max(0.0, min(1.0, img_py / img_h))
                
                bbox_size = 8
                
                keypoint_annotations.append({
                    'class_id': int(clsmap_pose.get('wedge_center', '2')),
                    'bbox': [
                        norm_x,
                        norm_y,
                        max(0.0, min(1.0, bbox_size / img_w)),
                        max(0.0, min(1.0, bbox_size / img_h))
                    ],
                    'keypoints': [(norm_x, norm_y)]
                })
            
            # Extract wedge start (class 3)
            if arc_start:
                sx, sy = arc_start
                px, py = ax.transData.transform_point((sx, sy))
                img_py = img_h - py
                
                norm_x = max(0.0, min(1.0, px / img_w))
                norm_y = max(0.0, min(1.0, img_py / img_h))
                
                bbox_size = 8
                
                keypoint_annotations.append({
                    'class_id': int(clsmap_pose.get('wedge_start', '3')),
                    'bbox': [
                        norm_x,
                        norm_y,
                        max(0.0, min(1.0, bbox_size / img_w)),
                        max(0.0, min(1.0, bbox_size / img_h))
                    ],
                    'keypoints': [(norm_x, norm_y)]
                })
            
            # Extract wedge end (class 4)
            if arc_end:
                ex, ey = arc_end
                px, py = ax.transData.transform_point((ex, ey))
                img_py = img_h - py
                
                norm_x = max(0.0, min(1.0, px / img_w))
                norm_y = max(0.0, min(1.0, img_py / img_h))
                
                bbox_size = 8
                
                keypoint_annotations.append({
                    'class_id': int(clsmap_pose.get('wedge_end', '4')),
                    'bbox': [
                        norm_x,
                        norm_y,
                        max(0.0, min(1.0, bbox_size / img_w)),
                        max(0.0, min(1.0, bbox_size / img_h))
                    ],
                    'keypoints': [(norm_x, norm_y)]
                })
    
    return keypoint_annotations
# In generator.py after extract_pie_pose_annotations()

def extract_line_pose_annotations(fig, chart_info_map, clsmap_pose, img_w, img_h):
    """
    Extract pose-style annotations for line charts with keypoints.
    Returns list of dicts with class_id, bbox, and keypoints.
    """
    keypoint_annotations = []
    renderer = fig.canvas.get_renderer()
    
    for ax in fig.axes:
        if not ax.get_visible():
            continue
            
        chartinfo = chart_info_map.get(ax, {})
        charttype = chartinfo.get('chart_type_str', '')
        
        if charttype != 'line':
            continue
            
        keypoint_info = chartinfo.get('keypoint_info', [])
        if not keypoint_info:
            continue
            
        data_artists = chartinfo.get('data_artists', [])
        
        # Process each series
        for series_idx, (artist, series_kpts) in enumerate(zip(data_artists, keypoint_info)):
            # Extract line boundary (class 0) - all points on the line
            all_points = series_kpts.get('all_points', [])
            
            if not all_points:
                continue
            
            # Convert all points to keypoint format
            boundary_keypoints = []
            
            for x_data, y_data, idx in all_points:
                px, py = ax.transData.transform_point((x_data, y_data))
                img_py = img_h - py
                
                norm_x = max(0.0, min(1.0, px / img_w))
                norm_y = max(0.0, min(1.0, img_py / img_h))
                
                boundary_keypoints.append((norm_x, norm_y))
            
            # Calculate bbox encompassing line
            try:
                artist_bbox = artist.get_window_extent(renderer)
                x0, y0, x1, y1 = artist_bbox.x0, artist_bbox.y0, artist_bbox.x1, artist_bbox.y1
                
                # Convert to image coordinates
                img_y0 = img_h - y1
                img_y1 = img_h - y0
                
                # Normalize bbox
                x_center = ((x0 + x1) / 2.0) / img_w
                y_center = ((img_y0 + img_y1) / 2.0) / img_h
                width = (x1 - x0) / img_w
                height = (img_y1 - img_y0) / img_h
                
                # Clamp
                x_center = max(0.0, min(1.0, x_center))
                y_center = max(0.0, min(1.0, y_center))
                width = max(0.0, min(1.0, width))
                height = max(0.0, min(1.0, height))
                
            except Exception as e:
                print(f"WARNING: Failed to extract line boundary bbox: {e}")
                continue
            
            # line_boundary annotation (class 0)
            keypoint_annotations.append({
                'class_id': int(clsmap_pose.get('line_boundary', '0')),
                'bbox': [x_center, y_center, width, height],
                'keypoints': boundary_keypoints
            })
            
            # data_point annotations (class 1) - sample every Nth point to avoid clutter
            sample_interval = max(1, len(all_points) // 10)  # Sample ~10 points max
            sampled_points = all_points[::sample_interval]
            
            for x_data, y_data, idx in sampled_points:
                px, py = ax.transData.transform_point((x_data, y_data))
                img_py = img_h - py
                
                norm_x = max(0.0, min(1.0, px / img_w))
                norm_y = max(0.0, min(1.0, img_py / img_h))
                
                bbox_size = 6
                
                keypoint_annotations.append({
                    'class_id': int(clsmap_pose.get('data_point', '1')),
                    'bbox': [
                        norm_x,
                        norm_y,
                        max(0.0, min(1.0, bbox_size / img_w)),
                        max(0.0, min(1.0, bbox_size / img_h))
                    ],
                    'keypoints': [(norm_x, norm_y)]
                })
            
            # inflection_point annotations (class 2)
            inflections = series_kpts.get('inflections', [])
            for x_data, y_data, idx in inflections:
                px, py = ax.transData.transform_point((x_data, y_data))
                img_py = img_h - py
                
                norm_x = max(0.0, min(1.0, px / img_w))
                norm_y = max(0.0, min(1.0, img_py / img_h))
                
                bbox_size = 8
                
                keypoint_annotations.append({
                    'class_id': int(clsmap_pose.get('inflection_point', '2')),
                    'bbox': [
                        norm_x,
                        norm_y,
                        max(0.0, min(1.0, bbox_size / img_w)),
                        max(0.0, min(1.0, bbox_size / img_h))
                    ],
                    'keypoints': [(norm_x, norm_y)]
                })
            
            # line_start annotation (class 3)
            start_x, start_y, start_idx = series_kpts['start']
            px, py = ax.transData.transform_point((start_x, start_y))
            img_py = img_h - py
            
            norm_x = max(0.0, min(1.0, px / img_w))
            norm_y = max(0.0, min(1.0, img_py / img_h))
            bbox_size = 8
            
            keypoint_annotations.append({
                'class_id': int(clsmap_pose.get('line_start', '3')),
                'bbox': [
                    norm_x,
                    norm_y,
                    max(0.0, min(1.0, bbox_size / img_w)),
                    max(0.0, min(1.0, bbox_size / img_h))
                ],
                'keypoints': [(norm_x, norm_y)]
            })
            
            # line_end annotation (class 4)
            end_x, end_y, end_idx = series_kpts['end']
            px, py = ax.transData.transform_point((end_x, end_y))
            img_py = img_h - py
            
            norm_x = max(0.0, min(1.0, px / img_w))
            norm_y = max(0.0, min(1.0, img_py / img_h))
            
            keypoint_annotations.append({
                'class_id': int(clsmap_pose.get('line_end', '4')),
                'bbox': [
                    norm_x,
                    norm_y,
                    max(0.0, min(1.0, bbox_size / img_w)),
                    max(0.0, min(1.0, bbox_size / img_h))
                ],
                'keypoints': [(norm_x, norm_y)]
            })
    
    return keypoint_annotations



def apply_realism_effects(pil_img, annotations, effects_config):
    """Apply realism effects and return modified image and annotations."""
    effect_function_map = {
        "blur": apply_blur_effect, 
        "motion_blur": apply_motion_blur_effect,
        "low_res": apply_low_res_effect, 
        "noise": apply_noise_effect,
        "jpeg_compression": apply_jpeg_compression_effect, 
        "pixelation": apply_pixelation_effect,
        "posterize": apply_posterize_effect, 
        "color_variation": apply_color_variation_effect,
        "ui_chrome": apply_ui_chrome_effect, 
        "watermark": apply_watermark_effect,
        "vignette": apply_vignette_effect, 
        "scanner_streaks": apply_scanner_streaks_effect,
        "clipping": apply_clipping_effect, 
        "printing_artifacts": apply_printing_artifacts_effect,
        "mouse_cursor": apply_mouse_cursor_effect, 
        "text_degradation": apply_text_degradation_effect,
        "grid_occlusion": apply_grid_occlusion_effect, 
        "scan_rotation": apply_scan_rotation_effect,
        "grayscale": apply_grayscale_effect, 
        "perspective": apply_perspective_effect,
    }
    
    total_dx, total_dy = 0, 0
    
    for effect_name, effect_config in effects_config.items():
        if random.random() < effect_config.get('p', 0):
            func = effect_function_map.get(effect_name)
            if not func: 
                continue
            
            print(f"    - Applying effect: {effect_name}")
            params = effect_config.get('params', {})
            
            try:
                if effect_name == 'clipping':
                    pil_img, dx, dy = func(pil_img, **params)
                    total_dx += dx
                    total_dy += dy
                elif effect_name == 'scan_rotation':
                    result = func(pil_img, **params)
                    pil_img = result[0]
                else:
                    pil_img = func(pil_img, **params)
            except Exception as e:
                print(f"      [WARNING] Failed to apply effect '{effect_name}': {e}")
    
    # Apply offset to annotations
    if total_dx != 0 or total_dy != 0:
        print(f"    - Applying total annotation offset: dx={total_dx}, dy={total_dy}")
        for ann in annotations:
            bbox = ann['bbox']
            new_bbox = transforms.Bbox.from_extents(
                bbox.x0 + total_dx, bbox.y0 + total_dy,
                bbox.x1 + total_dx, bbox.y1 + total_dy
            )
            ann['bbox'] = new_bbox
    
    return pil_img, annotations

def save_annotations_yolo(annotations, img_w, img_h, output_path):
    """Save in proper YOLO format with normalization"""
    with open(output_path, 'w') as f:
        for ann in annotations:
            class_id = ann['class_id']
            bbox = ann['bbox']
            
            # Extract bbox coordinates
            if hasattr(bbox, 'extents'):
                x0, y0, x1, y1 = bbox.extents
            else:
                x0, y0, x1, y1 = bbox
            
            # Convert matplotlib (bottom-left) to image (top-left) coordinates
            img_y0 = img_h - y1  # Top edge
            img_y1 = img_h - y0  # Bottom edge
            
            # Clamp to bounds
            img_x0 = max(0.0, min(float(x0), img_w))
            img_x1 = max(img_x0, min(float(x1), img_w))
            img_y0 = max(0.0, min(float(img_y0), img_h))
            img_y1 = max(img_y0, min(float(img_y1), img_h))
            
            # YOLO format: normalized center and dimensions
            x_center = (img_x0 + img_x1) / 2.0 / img_w
            y_center = (img_y0 + img_y1) / 2.0 / img_h
            width = (img_x1 - img_x0) / img_w
            height = (img_y1 - img_y0) / img_h
            
            # Clamp to [0, 1]
            x_center = max(0.0, min(1.0, x_center))
            y_center = max(0.0, min(1.0, y_center))
            width = max(0.0, min(1.0, width))
            height = max(0.0, min(1.0, height))
            
            f.write(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}\n")

# In generator.py after save_annotations_yolo()
def save_annotations_pose(keypoint_annotations, img_w, img_h, output_path):
    """
    Save pose-style annotations with keypoints.
    Format: <class-index> <x> <y> <width> <height> <px1> <py1> <px2> <py2> ... <pxn> <pyn>
    All coordinates normalized to [0, 1]
    """
    with open(output_path, 'w') as f:
        for ann in keypoint_annotations:
            class_id = ann['class_id']
            bbox = ann['bbox']  # Normalized bbox: [x_center, y_center, width, height]
            keypoints = ann['keypoints']  # List of (x, y) tuples in normalized coords
            
            # Write: class_id x_center y_center width height px1 py1 px2 py2 ...
            line_parts = [str(class_id)]
            line_parts.extend([f"{coord:.6f}" for coord in bbox])
            
            # Add all keypoint coordinates
            for kp_x, kp_y in keypoints:
                line_parts.append(f"{kp_x:.6f}")
                line_parts.append(f"{kp_y:.6f}")
            
            f.write(' '.join(line_parts) + '\n')



def convert_numpy_types(obj):
    if isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {k: convert_numpy_types(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(i) for i in obj]
    return obj

def get_detailed_annotations(fig, chart_info_map, cls_map, img_w, img_h, raw_annotations=None):
    """Extract comprehensive metadata with xyxy coordinates and text content
    
    Args:
        raw_annotations: Optional list of raw annotation dicts from get_granular_annotations
    """
    renderer = fig.canvas.get_renderer()
    fig_bbox = fig.get_window_extent(renderer)
    seen = set()
    
    detailed_metadata = {
        "chart_type": None,
        "orientation": None,
        "scale_labels": [],
        "tick_labels": [],
        "chart_title": [],
        "axis_title": [],
        "legend": [],
        "bar": [],
        "data_point": [],
        "error_bar": [],
        "significance_marker": [],
        "data_label": [],
        "box": [],
        "median_line": [],
        "range_indicator": [],
        "outlier": []
    }
    
    def add_annotation(element_type, bbox, text="", conf=1.0, extra=None):
        if not bbox or bbox.width <= 1 or bbox.height <= 1:
            return None
        
        key = (element_type, round(bbox.x0, 2), round(bbox.y0, 2), round(bbox.x1, 2), round(bbox.y1, 2))
        if key in seen:
            return None
        seen.add(key)
        
        xyxy = bbox_to_xyxy(bbox, img_h)
        entry = {"xyxy": xyxy, "conf": conf}
        if text:
            entry["text"] = text
        if extra:
            entry.update(extra)
        
        detailed_metadata[element_type].append(entry)
        return entry
    
    for ax in fig.axes:
        if not ax.get_visible():
            continue
        
        chart_info = chart_info_map.get(ax, {})
        chart_type = chart_info.get('chart_type_str', 'unknown')
        orientation = chart_info.get('orientation', 'vertical')
        
        detailed_metadata["chart_type"] = chart_type
        detailed_metadata["orientation"] = orientation
        
        # Chart Title
        if 'chart_title' in cls_map:
            title = ax.title
            if title and title.get_visible() and title.get_text():
                add_annotation("chart_title", title.get_window_extent(renderer), 
                             text=title.get_text().strip(), conf=1.0)
        
        # Axis Titles
        if 'axis_title' in cls_map:
            if ax.xaxis.label.get_visible() and ax.xaxis.label.get_text():
                add_annotation("axis_title", ax.xaxis.label.get_window_extent(renderer),
                             text=ax.xaxis.label.get_text().strip(), conf=1.0, 
                             extra={"axis": "x"})
            if ax.yaxis.label.get_visible() and ax.yaxis.label.get_text():
                add_annotation("axis_title", ax.yaxis.label.get_window_extent(renderer),
                             text=ax.yaxis.label.get_text().strip(), conf=1.0,
                             extra={"axis": "y"})
        
        # Scale Labels (Tick Labels)
        if 'axis_labels' in cls_map:
            # Use the scale axis information from the chart generation
            scale_axis_info = chart_info.get('scale_axis_info', {})
            primary_scale_axis = scale_axis_info.get('primary_scale_axis', 'y')
            secondary_scale_axis = scale_axis_info.get('secondary_scale_axis', None)
            
            # Process X-axis labels
            for label in ax.get_xticklabels():
                if label.get_visible() and label.get_text():
                    txt = label.get_text().strip()
                    # Check if X-axis is a scale axis
                    if is_float(txt) and (primary_scale_axis == 'x' or secondary_scale_axis == 'x'):
                        add_annotation("scale_labels", label.get_window_extent(renderer),
                                     text=txt, conf=1.0, extra={"axis": "x", "is_numeric": True})
                    else:
                        add_annotation("tick_labels", label.get_window_extent(renderer),
                                     text=txt, conf=1.0, extra={"axis": "x", "is_numeric": is_float(txt)})
            
            # Process Y-axis labels
            for label in ax.get_yticklabels():
                if label.get_visible() and label.get_text():
                    txt = label.get_text().strip()
                    # Check if Y-axis is a scale axis
                    if is_float(txt) and (primary_scale_axis == 'y' or secondary_scale_axis == 'y'):
                        add_annotation("scale_labels", label.get_window_extent(renderer),
                                     text=txt, conf=1.0, extra={"axis": "y", "is_numeric": True})
                    else:
                        add_annotation("tick_labels", label.get_window_extent(renderer),
                                     text=txt, conf=1.0, extra={"axis": "y", "is_numeric": is_float(txt)})
        
        # Legend
        if 'legend' in cls_map:
            legend = ax.get_legend()
            if legend and legend.get_visible():
                legend_texts = [t.get_text() for t in legend.get_texts() if t.get_visible()]
                add_annotation("legend", legend.get_window_extent(renderer),
                             conf=1.0, extra={"entries": legend_texts})
        
        # Data Elements
        for artist in chart_info.get('data_artists', []):
            if not artist or not artist.get_visible():
                continue
            
            # Line chart points
            if isinstance(artist, matplotlib.lines.Line2D) and chart_type == 'line':
                x_data, y_data = artist.get_xdata(), artist.get_ydata()
                for x, y in zip(x_data, y_data):
                    px, py = ax.transData.transform_point((x, y))
                    bbox = transforms.Bbox.from_extents(px - 5, py - 5, px + 5, py + 5)
                    add_annotation("data_point", bbox, conf=0.95, 
                                 extra={"x": float(x), "y": float(y)})
            
            # Scatter points
            elif 'PathCollection' in str(type(artist)) and chart_type == 'scatter':
                offsets = artist.get_offsets()
                sizes = artist.get_sizes()
                if len(offsets):
                    is_uniform = (sizes.size == 1)
                    pts_to_px = fig.dpi / 72.0
                    for i, (x, y) in enumerate(offsets):
                        px, py = ax.transData.transform_point((x, y))
                        s = sizes[0] if is_uniform else sizes[i]
                        r = np.sqrt(s / np.pi) * pts_to_px
                        bbox = transforms.Bbox.from_extents(px - r, py - r, px + r, py + r)
                        add_annotation("data_point", bbox, conf=0.95,
                                     extra={"x": float(x), "y": float(y), "size": float(s)})
            
            # Bar elements
            elif isinstance(artist, patches.Rectangle) and chart_type == 'bar':
                value = float(artist.get_height() if orientation == 'vertical' else artist.get_width())
                add_annotation("bar", artist.get_window_extent(renderer), conf=0.98,
                             extra={"value": value})
        
        # Box plot elements
        if chart_type == 'box':
            bp_dict = chart_info.get('boxplot_dict', {})
            if bp_dict:
                for box in bp_dict.get('boxes', []):
                    add_annotation("box", box.get_window_extent(renderer), conf=0.98)
                
                for median in bp_dict.get('medians', []):
                    bbox = median.get_window_extent(renderer)
                    padded = transforms.Bbox.from_extents(bbox.x0, bbox.y0 - 2, bbox.x1, bbox.y1 + 2)
                    add_annotation("median_line", padded, conf=0.97)
                
                for i in range(len(bp_dict.get('boxes', []))):
                    try:
                        w1 = bp_dict['whiskers'][2 * i]
                        w2 = bp_dict['whiskers'][2 * i + 1]
                        c1 = bp_dict['caps'][2 * i]
                        c2 = bp_dict['caps'][2 * i + 1]
                        combined = transforms.Bbox.union([
                            w1.get_window_extent(renderer),
                            w2.get_window_extent(renderer),
                            c1.get_window_extent(renderer),
                            c2.get_window_extent(renderer)
                        ])
                        add_annotation("range_indicator", combined, conf=0.96)
                    except IndexError:
                        continue
                
                for flier in bp_dict.get('fliers', []):
                    for x, y in zip(flier.get_xdata(), flier.get_ydata()):
                        px, py = ax.transData.transform_point((x, y))
                        bbox = transforms.Bbox.from_extents(px - 3, py - 3, px + 3, py + 3)
                        add_annotation("outlier", bbox, conf=0.94)
        
        # Error bars and text annotations
        for artist in chart_info.get('other_artists', []):
            if not artist:
                continue
            
            # Error bars
            if isinstance(artist, ErrorbarContainer):
                plotline, caplines, barlinecols = artist.lines
                if barlinecols and caplines:
                    stems = barlinecols[0].get_segments()
                    for i in range(min(len(stems), len(caplines) // 2)):
                        try:
                            p1 = ax.transData.transform(stems[i][0])
                            p2 = ax.transData.transform(stems[i][1])
                            stem_bbox = transforms.Bbox([p1, p2])
                            
                            cap1, cap2 = caplines[2 * i], caplines[2 * i + 1]
                            c1x, c1y = cap1.get_data()
                            c2x, c2y = cap2.get_data()
                            cap1_bbox = transforms.Bbox([
                                ax.transData.transform((c1x[0], c1y[0])),
                                ax.transData.transform((c1x[1], c1y[1]))
                            ])
                            cap2_bbox = transforms.Bbox([
                                ax.transData.transform((c2x[0], c2y[0])),
                                ax.transData.transform((c2x[1], c2y[1]))
                            ])
                            
                            final = transforms.Bbox.union([stem_bbox, cap1_bbox, cap2_bbox])
                            add_annotation("error_bar", final, conf=0.89)
                        except Exception:
                            continue
            
            # Text annotations
            elif isinstance(artist, matplotlib.text.Text) and artist.get_visible():
                txt = artist.get_text().strip()
                if not txt:
                    continue
                
                # Significance markers
                if txt in ['*', '**', '***', 'ns', 'a', 'b', 'c', 'd']:
                    add_annotation("significance_marker", artist.get_window_extent(renderer),
                                 text=txt, conf=0.92)
                # Data labels
                elif is_float(txt.replace('%', '')):
                    add_annotation("data_label", artist.get_window_extent(renderer),
                                 text=txt, conf=0.91)
    
    # CRITICAL FIX: Add raw XYXY coordinates at the end
    if raw_annotations:
        detailed_metadata["raw_annotations"] = []
        for ann in raw_annotations:
            bbox = ann['bbox']
            xyxy = bbox_to_xyxy_absolute(bbox, img_h)
            detailed_metadata["raw_annotations"].append({
                'class_id': int(ann['class_id']),
                'xyxy': [int(coord) for coord in xyxy]
            })
    
    return detailed_metadata

def create_unified_annotation(fig, chart_info_map, cls_map, img_w, img_h, annotations):
    """
    ENHANCED create_unified_annotation with critical bug fixes
    
    Key fixes:
    1. Proper coordinate transformation validation
    2. Enhanced text content extraction
    3. Better boundary checking
    4. Improved numeric detection
    """
    
    # Build reverse lookup map
    id_to_name = {v: k for k, v in cls_map.items()}
    
    # Create unified structure
    unified = {
        "image_width": int(img_w),
        "image_height": int(img_h),
        "annotations": []
    }
    
    # Extract text content from all text artists
    text_lookup = {}
    renderer = fig.canvas.get_renderer()
    
    for ax in fig.axes:
        if not ax.get_visible():
            continue
            
        chart_info = chart_info_map.get(ax, {})
        
        # Process all text artists
        for artist in chart_info.get('other_artists', []):
            if hasattr(artist, 'get_text') and artist.get_visible():
                try:
                    text_content = artist.get_text().strip()
                    if text_content:
                        bbox = artist.get_window_extent(renderer)
                        # CRITICAL FIX: More precise bbox key generation
                        key = (round(bbox.x0, 1), round(bbox.y0, 1), round(bbox.x1, 1), round(bbox.y1, 1))
                        text_lookup[key] = text_content
                        
                        if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_annotations', False):
                            print(f"DEBUG: Text lookup added: '{text_content}' at {key}")
                except Exception as e:
                    if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_annotations', False):
                        print(f"DEBUG: Text extraction failed: {e}")
    
    if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_annotations', False):
        print(f"DEBUG: create_unified_annotation - Processing {len(annotations)} annotations")
        print(f"DEBUG: create_unified_annotation - Text lookup contains {len(text_lookup)} entries")
    
    # Process each annotation
    for ann_idx, ann in enumerate(annotations):
        bbox = ann['bbox']
        
        # CRITICAL FIX: Enhanced coordinate transformation
        try:
            if hasattr(bbox, 'extents'):
                x0, y0, x1, y1 = bbox.extents
            else:
                x0, y0, x1, y1 = bbox
                
            # Convert from matplotlib coordinates to image coordinates
            # CRITICAL FIX: Proper coordinate transformation
            abs_x0 = max(0, min(int(x0), img_w - 1))
            abs_y0 = max(0, min(int(img_h - y1), img_h - 1))  # Flip Y coordinate
            abs_x1 = max(abs_x0 + 1, min(int(x1), img_w))
            abs_y1 = max(abs_y0 + 1, min(int(img_h - y0), img_h))  # Flip Y coordinate
            
            # Validate bounding box
            if abs_x1 <= abs_x0 or abs_y1 <= abs_y0:
                if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_coords', False):
                    print(f"DEBUG: Invalid bbox after transformation: [{abs_x0},{abs_y0},{abs_x1},{abs_y1}]")
                continue
                
        except Exception as e:
            if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_coords', False):
                print(f"DEBUG: Coordinate transformation failed for annotation {ann_idx}: {e}")
            continue
        
        # Build annotation entry
        class_id = int(ann['class_id'])
        class_name = id_to_name.get(class_id, "unknown")
        
        entry = {
            "class_id": class_id,
            "class_name": class_name,
            "xyxy": [abs_x0, abs_y0, abs_x1, abs_y1]
        }
        
        # CRITICAL FIX: Enhanced text content matching
        # Try multiple bbox key variations for text lookup
        bbox_keys_to_try = [
            (round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)),
            (round(x0, 0), round(y0, 0), round(x1, 0), round(y1, 0)),
            (round(x0, 2), round(y0, 2), round(x1, 2), round(y1, 2))
        ]
        
        text_content = None
        for key in bbox_keys_to_try:
            if key in text_lookup:
                text_content = text_lookup[key]
                break
        
        if text_content:
            entry["text"] = text_content
            
            # CRITICAL FIX: Enhanced numeric detection
            # Try to determine if text is numeric
            try:
                # Remove common non-numeric characters
                cleaned_text = text_content.replace('%', '').replace(',', '').replace('$', '').strip()
                float(cleaned_text)
                entry["is_numeric"] = True
            except (ValueError, TypeError):
                entry["is_numeric"] = False
                
            if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_annotations', False):
                print(f"DEBUG: Added text '{text_content}' to annotation {ann_idx}, numeric: {entry.get('is_numeric', False)}")
        
        unified["annotations"].append(entry)
        
        if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_coords', False):
            print(f"DEBUG: Added unified annotation {ann_idx}: class={class_name}, bbox=[{abs_x0},{abs_y0},{abs_x1},{abs_y1}]")
    
    if GENERATION_CONFIG.get('debug_mode', False) or GENERATION_CONFIG.get('debug_coords', False):
        print(f"DEBUG: create_unified_annotation - Created {len(unified['annotations'])} unified annotations")
    
    return unified
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default=None)
    parser.add_argument('--num', type=int, default=None)
    args = parser.parse_args()

    if args.config:
        import importlib.util
        spec = importlib.util.spec_from_file_location("config", args.config)
        config_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(config_module)
        cfg = config_module.OCR_TRAINING_CONFIG
    else:
        cfg = GENERATION_CONFIG

    if args.num:
        cfg['num_images'] = args.num

    random.seed(cfg['seed'])
    np.random.seed(cfg['seed'])
    
    # Check if debug mode is enabled via environment variable
    if os.environ.get('DEBUG_MODE', '').lower() in ['true', '1', 'yes']:
        cfg['debug_mode'] = True
    
    if cfg['debug_mode']:
        print("--- DEBUG MODE ENABLED ---")
        debug_dir = 'test'
        print(f"Output will be saved to '{debug_dir}/'")
        images_dir = debug_dir
        labels_dir = debug_dir
        ensure_dir(debug_dir)
    else:
        output_dir = cfg['output_dir']
        images_dir = os.path.join(output_dir, 'images')
        labels_dir = os.path.join(output_dir, 'labels')
        ensure_dir(images_dir)
        ensure_dir(labels_dir)

    chart_generators = {
        "bar": _generate_bar_chart,
        "line": _generate_line_chart,
        "scatter": _generate_scatter_chart,
        "box": _generate_boxplot_chart,
        "pie": _generate_pie_chart,
        "area": _generate_area_chart,
        "histogram": _generate_histogram,
        "heatmap": _generate_heatmap_chart,
    }

    if cfg['debug_mode']:
        print(f"DEBUG: Available chart types: {list(cfg['chart_types'].keys())}")
        print(f"DEBUG: Enabled chart types: {[k for k, v in cfg['chart_types'].items() if v['enabled']]}")
        print(f"DEBUG: Scenario weights: {cfg['scenario_weights']}")
        print(f"DEBUG: Number of images to generate: {cfg['num_images']}")

    start_time = time.time()
    for i in range(cfg['num_images']):
        iter_start = time.time()
        print(f"--- Generating image {i+1}/{cfg['num_images']} ---")
        plt.close('all')

        output_dpi = random.choice([96, 120, 150])
        
        if cfg['debug_mode']:
            print(f"DEBUG: Using DPI {output_dpi}")

        # Determine scenario
        scenarios, weights = zip(*cfg['scenario_weights'].items())
        scenario = random.choices(scenarios, weights=weights, k=1)[0]
        
        if cfg['debug_mode']:
            print(f"DEBUG: Selected scenario: {scenario}")
        
        if scenario == 'multi':
            nrows, ncols = random.choice([(1,2), (2,1), (2,2), (1,3), (3,1), (2,3), (3,2), (3,3)])
            fig, axes = plt.subplots(nrows, ncols, figsize=(ncols*5, nrows*4), dpi=output_dpi)
            axes = np.array(axes).flatten()
            
            if cfg['debug_mode']:
                print(f"DEBUG: Created multi-axis chart: {nrows}x{ncols}")
        else:
            fig, ax = plt.subplots(figsize=(7, 5), dpi=output_dpi)
            axes = [ax]
            
            if cfg['debug_mode']:
                print(f"DEBUG: Created single-axis chart: 1x1")

        chart_info_map = {}

        for ax_idx, ax in enumerate(axes):
            chart_types, weights = zip(*[(k, v['weight']) for k, v in cfg['chart_types'].items() if v['enabled']])
            chart_type = random.choices(chart_types, weights=weights, k=1)[0]
            print(f"  - Type: {chart_type} (Scenario: {scenario})")
            
            if cfg['debug_mode']:
                print(f"DEBUG: AX[{ax_idx}]: Chart type selected: {chart_type}")
                print(f"DEBUG: AX[{ax_idx}]: Chart types and weights: {list(zip(chart_types, weights))}")

            # Get correct class map for this chart type
            cls_map = CHART_CLASS_MAPS.get(chart_type, CHART_CLASS_MAPS['bar'])
            
            if cfg['debug_mode']:
                print(f"DEBUG: AX[{ax_idx}]: Class map: {cls_map}")
            
            theme_name = random.choice(list(THEMES.keys()))
            theme_config = THEMES[theme_name]
            print(f"  - Theme: {theme_name}")
            
            if cfg['debug_mode']:
                print(f"DEBUG: AX[{ax_idx}]: Theme selected: {theme_name}")

            is_scientific = random.random() < cfg['bar_chart_config']['scientific_ratio']
            style_config = {}

            generator_func = chart_generators[chart_type]
            
            # Initialize all possible return variables
            boxplot_dict = {}
            scale_axis_info = {}
            keypoint_data = None
            
            if chart_type == 'box':
                if cfg['debug_mode']:
                    print(f"DEBUG: AX[{ax_idx}]: Calling box plot generator")
                data_artists, other_artists, bar_info_list, orientation, error_tops, axis_related_artists, boxplot_dict, scale_axis_info = generator_func(ax, theme_name, theme_config, is_scientific, debug_mode=cfg['debug_mode'])
                keypoint_data = None  # Box plots don't have keypoint data
            else:
                if cfg['debug_mode']:
                    print(f"DEBUG: AX[{ax_idx}]: Calling generator for {chart_type}")
                if chart_type == 'bar':
                    if cfg['debug_mode']:
                        print(f"DEBUG: AX[{ax_idx}]: Setting up bar chart style config")
                    styles, weights = zip(*[(k, v['weight']) for k, v in cfg['bar_chart_config']['styles'].items()])
                    style_config['style'] = random.choices(styles, weights=weights, k=1)[0]
                    patterns, weights = zip(*[(k, v['weight']) for k, v in cfg['bar_chart_config']['patterns'].items()])
                    style_config['pattern'] = random.choices(patterns, weights=weights, k=1)[0]
                    style_config['is_scientific'] = is_scientific
                
                # Handle the 8-element return from all chart generators
                result = generator_func(ax, theme_name, theme_config, style_config if chart_type == 'bar' else is_scientific, debug_mode=cfg['debug_mode'])
                
                # Check if the result has 8 elements (new enhanced functions) or 7 (legacy)
                if len(result) == 8:
                    data_artists, other_artists, bar_info_list, orientation, error_tops, axis_related_artists, scale_axis_info, keypoint_data = result
                else:  # Legacy function returning 7 elements
                    data_artists, other_artists, bar_info_list, orientation, error_tops, axis_related_artists, scale_axis_info = result
                    keypoint_data = None
            
            other_artists.extend(axis_related_artists)
            
            if cfg['debug_mode']:
                print(f"DEBUG: AX[{ax_idx}]: Generated {len(data_artists)} data artists, {len(other_artists)} other artists")
                print(f"DEBUG: AX[{ax_idx}]: Scale axis info: {scale_axis_info}")
            
            ax.set_title(random.choice(CHART_TITLES), fontsize=14, pad=15)
            if random.random() < 0.6 and chart_type not in ['pie', 'heatmap']:
                ax.legend(loc=random.choice(['upper right', 'best']))

            chart_info_map[ax] = {
                'chart_type_str': chart_type,
                'data_artists': data_artists,
                'other_artists': other_artists,
                'axis_related_artists': axis_related_artists,
                'boxplot_dict': boxplot_dict,
                'scale_axis_info': scale_axis_info,
                'keypoint_info': keypoint_data,  
                'pie_geometry': keypoint_data if chart_type == 'pie' else None  
            }

            # Store keypoint metadata for line, area, and pie charts
            if chart_type in ['line', 'area'] and keypoint_data is not None:
                chart_info_map[ax]['keypoint_info'] = keypoint_data
            elif chart_type == 'pie' and keypoint_data is not None:
                chart_info_map[ax]['pie_geometry'] = keypoint_data

        fig.tight_layout(pad=2.0)

        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=output_dpi)
        buf.seek(0)

        # Determine the primary chart type for annotation extraction
        primary_chart_type = chart_info_map.get(axes[0], {}).get('chart_type_str', 'bar')
        cls_map = CHART_CLASS_MAPS.get(primary_chart_type, CHART_CLASS_MAPS['bar'])
        
        if cfg['debug_mode']:
            print(f"DEBUG: Primary chart type for annotation: {primary_chart_type}")
            print(f"DEBUG: Using class map for annotations: {cls_map}")

        annotations = get_granular_annotations(fig, chart_info_map, cls_map)
        
        if cfg['debug_mode']:
            print(f"DEBUG: Total annotations detected: {len(annotations)}")
            class_counts = {}
            for ann in annotations:
                class_id = ann['class_id']
                class_counts[class_id] = class_counts.get(class_id, 0) + 1
            print(f"DEBUG: Annotation class distribution: {class_counts}")

        pil_img_for_check = Image.open(buf).convert('RGB')
        img_w, img_h = pil_img_for_check.size

        # Filter low-variance annotations
        filtered_annotations = []
        PIXEL_STD_DEV_THRESHOLD = 10

        # Get class IDs for axis_labels and legend
        axis_labels_class_id = next((k for k, v in cls_map.items() if v == 'axis_labels'), None)
        legend_class_id = next((k for k, v in cls_map.items() if v == 'legend'), None)

        for ann in annotations:
            if (axis_labels_class_id is not None and ann['class_id'] == axis_labels_class_id) or \
               (legend_class_id is not None and ann['class_id'] == legend_class_id):
                bbox = ann['bbox']
                
                if legend_class_id is not None and ann['class_id'] == legend_class_id:
                    padding = 3
                    x0 = max(bbox.x0 + padding, bbox.x0)
                    y0 = max(bbox.y0 + padding, bbox.y0)
                    x1 = max(bbox.x1 - padding, x0 + 1)
                    y1 = max(bbox.y1 - padding, y0 + 1)
                    ann['bbox'] = BoundingBox(x0, y0, x1, y1)
                else:
                    x0, y0, x1, y1 = bbox.x0, bbox.y0, bbox.x1, bbox.y1
                
                crop_box = (int(x0), int(img_h - y1), int(x1), int(img_h - y0))

                if crop_box[0] < crop_box[2] and crop_box[1] < crop_box[3]:
                    label_crop = pil_img_for_check.crop(crop_box)
                    l_crop = label_crop.convert('L')
                    std_dev = np.array(l_crop).std()

                    if std_dev > PIXEL_STD_DEV_THRESHOLD:
                        filtered_annotations.append(ann)
            else:
                filtered_annotations.append(ann)
        
        annotations = filtered_annotations

        # Dual-axis post-processing
        if len(fig.axes) == 2 and any(v == 'axis_labels' for v in cls_map.values()):
            print("    - Applying post-processing fix for dual-axis chart annotations.")
            axis_label_class_id = next((k for k, v in cls_map.items() if v == 'axis_labels'), None)
            if axis_label_class_id is not None:
                renderer = fig.canvas.get_renderer()
                main_ax_bbox = axes[0].get_window_extent(renderer)
                xaxis_y_threshold = main_ax_bbox.y0
                
                if cfg['debug_mode']:
                    print(f"DEBUG: Dual-axis processing - threshold Y: {xaxis_y_threshold}")
                
                x_axis_labels_to_filter = []
                annotations_to_keep = []
                
                for ann in annotations:
                    is_class_8 = (ann['class_id'] == axis_label_class_id)
                    is_on_x_axis = (ann['bbox'].y1 < xaxis_y_threshold)
                    
                    if is_class_8 and is_on_x_axis:
                        x_axis_labels_to_filter.append(ann)
                    else:
                        annotations_to_keep.append(ann)
                
                deduplicated_x_labels = []
                seen_x_positions = []
                tolerance = 5
                
                for ann in sorted(x_axis_labels_to_filter, key=lambda a: a['bbox'].x0):
                    x_center = (ann['bbox'].x0 + ann['bbox'].x1) / 2
                    is_duplicate = any(abs(x_center - seen_x) < tolerance for seen_x in seen_x_positions)
                    
                    if not is_duplicate:
                        deduplicated_x_labels.append(ann)
                        seen_x_positions.append(x_center)
                
                annotations = annotations_to_keep + deduplicated_x_labels
                print(f"    - Kept {len(deduplicated_x_labels)} of {len(x_axis_labels_to_filter)} X-axis labels.")
                
                if cfg['debug_mode']:
                    print(f"DEBUG: After dual-axis processing - annotations: {len(annotations)}")

        # Apply realism effects
        buf.seek(0)
        pil_img = Image.open(buf).convert('RGB')
        
        if cfg['debug_mode']:
            print(f"DEBUG: Before realism effects - annotations: {len(annotations)}")
        
        pil_img, annotations = apply_realism_effects(pil_img, annotations, cfg['realism_effects'])
        
        if cfg['debug_mode']:
            print(f"DEBUG: After realism effects - annotations: {len(annotations)}")

        # Filter annotations by size and aspect ratio
        MIN_BBOX_SIZE = 8
        MAX_ASPECT_RATIO = 20.0
        
        valid_annotations = []
        for ann in annotations:
            bbox = ann['bbox']
            width = bbox.x1 - bbox.x0
            height = bbox.y1 - bbox.y0
                
            if chart_type == 'scatter':
                if width == 0 or height == 0:
                    continue
                valid_annotations.append(ann)
            else:     
                if width >= MIN_BBOX_SIZE and height >= MIN_BBOX_SIZE :
                    if width > 0 and height > 0:
                        aspect_ratio = max(width / height, height / width)
                        if aspect_ratio > MAX_ASPECT_RATIO:
                            print(f"    - Discarded annotation (extreme aspect ratio): {aspect_ratio:.1f}")
                            continue
                        valid_annotations.append(ann)
                else:
                    print(f"    - Discarded annotation (too small): class {ann['class_id']}, size {width:.1f}x{height:.1f}")

        annotations = valid_annotations
    
        # Filter out-of-bounds annotations
        img_w, img_h = pil_img.size
        final_valid_annotations = []
        for ann in annotations:
            bbox = ann['bbox']
            if (bbox.x0 >= 0 and bbox.y0 >= 0 and 
                bbox.x1 <= img_w and bbox.y1 <= img_h and
                bbox.x1 > bbox.x0 and bbox.y1 > bbox.y0):
                final_valid_annotations.append(ann)
            else:
                print(f"    - Discarded annotation (out of bounds after effects): class {ann['class_id']}")

        annotations = final_valid_annotations
        
        if cfg['debug_mode']:
            print(f"DEBUG: After size/aspect/bounds filtering - annotations: {len(annotations)}")
        
        annotations = filter_overlapping_annotations(annotations, iou_threshold=0.7)
        
        if cfg['debug_mode']:
            print(f"DEBUG: After overlap filtering - annotations: {len(annotations)}")

        # Save files
        base_filename = f"chart_{i:05d}"
        
        pil_img.save(os.path.join(images_dir, f"{base_filename}.png"))
        
        # Save YOLO format labels
        save_annotations_yolo(annotations, img_w, img_h, 
                             os.path.join(labels_dir, f"{base_filename}.txt"))


        # **NEW: Check if chart type is area and save dual-format annotations**
        primary_chart_type = chart_info_map.get(fig.axes[0], {}).get('chart_type_str', '')

        if primary_chart_type == 'area':
            # Save object detection format with CLASS_MAP_AREA_OBJ
            clsmap_obj = GENERATION_CONFIG['CLASS_MAP_AREA_OBJ']
            annotations_obj = get_granular_annotations(fig, chart_info_map, clsmap_obj)
            
            # Create separate directory for area object annotations
            area_obj_dir = os.path.join(output_dir, 'area_obj_labels')
            ensure_dir(area_obj_dir)
            save_annotations_yolo(annotations_obj, img_w, img_h, 
                                os.path.join(area_obj_dir, f"{base_filename}.txt"))
            
            # Save pose format with CLASS_MAP_AREA_POSE
            clsmap_pose = GENERATION_CONFIG['CLASS_MAP_AREA_POSE']
            # Convert string keys to reverse map
            clsmap_pose_reverse = {v: k for k, v in clsmap_pose.items()}
            
            keypoint_annotations = extract_area_pose_annotations(
                fig, chart_info_map, clsmap_pose_reverse, img_w, img_h
            )
            
            # Create separate directory for area pose annotations
            area_pose_dir = os.path.join(output_dir, 'area_pose_labels')
            ensure_dir(area_pose_dir)
            save_annotations_pose(keypoint_annotations, img_w, img_h,
                                os.path.join(area_pose_dir, f"{base_filename}.txt"))
            
            if cfg['debug_mode']:
                print(f"DEBUG: Saved {len(annotations_obj)} area object annotations")
                print(f"DEBUG: Saved {len(keypoint_annotations)} area pose annotations")

        elif primary_chart_type == 'pie':
            # **NEW: Save pie chart dual-format annotations**
            # Save object detection format with CLASS_MAP_PIE_OBJ
            clsmap_obj = GENERATION_CONFIG['CLASS_MAP_PIE_OBJ']
            annotations_obj = get_granular_annotations(fig, chart_info_map, clsmap_obj)
            
            pie_obj_dir = os.path.join(output_dir, 'pie_obj_labels')
            ensure_dir(pie_obj_dir)
            save_annotations_yolo(annotations_obj, img_w, img_h,
                                os.path.join(pie_obj_dir, f"{base_filename}.txt"))
            
            # Save pose format with CLASS_MAP_PIE_POSE
            clsmap_pose = GENERATION_CONFIG['CLASS_MAP_PIE_POSE']
            clsmap_pose_reverse = {v: k for k, v in clsmap_pose.items()}
            
            keypoint_annotations = extract_pie_pose_annotations(
                fig, chart_info_map, clsmap_pose_reverse, img_w, img_h
            )
            
            pie_pose_dir = os.path.join(output_dir, 'pie_pose_labels')
            ensure_dir(pie_pose_dir)
            save_annotations_pose(keypoint_annotations, img_w, img_h,
                                os.path.join(pie_pose_dir, f"{base_filename}.txt"))
            
            if cfg['debug_mode']:
                print(f"DEBUG: Saved {len(annotations_obj)} pie object annotations")
                print(f"DEBUG: Saved {len(keypoint_annotations)} pie pose annotations")

        elif primary_chart_type == 'line':
            # **NEW: Save line chart dual-format annotations**
            # Save object detection format with CLASS_MAP_LINE_OBJ
            clsmap_obj = GENERATION_CONFIG['CLASS_MAP_LINE_OBJ']
            annotations_obj = get_granular_annotations(fig, chart_info_map, clsmap_obj)
            
            line_obj_dir = os.path.join(output_dir, 'line_obj_labels')
            ensure_dir(line_obj_dir)
            save_annotations_yolo(annotations_obj, img_w, img_h,
                                os.path.join(line_obj_dir, f"{base_filename}.txt"))
            
            # Save pose format with CLASS_MAP_LINE_POSE
            clsmap_pose = GENERATION_CONFIG['CLASS_MAP_LINE_POSE']
            clsmap_pose_reverse = {v: k for k, v in clsmap_pose.items()}
            
            keypoint_annotations = extract_line_pose_annotations(
                fig, chart_info_map, clsmap_pose_reverse, img_w, img_h
            )
            
            line_pose_dir = os.path.join(output_dir, 'line_pose_labels')
            ensure_dir(line_pose_dir)
            save_annotations_pose(keypoint_annotations, img_w, img_h,
                                os.path.join(line_pose_dir, f"{base_filename}.txt"))
            
            if cfg['debug_mode']:
                print(f"DEBUG: Saved {len(annotations_obj)} line object annotations")
                print(f"DEBUG: Saved {len(keypoint_annotations)} line pose annotations")


        # Save single unified JSON
        unified_json = create_unified_annotation(fig, chart_info_map, cls_map, img_w, img_h, annotations)
        unified_json = convert_numpy_types(unified_json)
        with open(os.path.join(labels_dir, f"{base_filename}.json"), 'w') as f:
            json.dump(unified_json, f, indent=2)

        iter_time = time.time() - iter_start
        elapsed = time.time() - start_time
        eta = (elapsed / (i + 1)) * (cfg['num_images'] - i - 1)
        print(f"    ✓ Complete in {iter_time:.2f}s | ETA: {eta/60:.1f}m")
        print(f" ✓ Saved {len(annotations)} annotations")

    print("\n=== DATASET STATISTICS ===")
    class_counts = defaultdict(int)
    for i in range(cfg['num_images']):
        label_file = os.path.join(labels_dir, f"chart_{i:05d}.txt")
        if os.path.exists(label_file):
            with open(label_file, 'r') as f:
                for line in f:
                    class_id = int(line.split()[0])
                    class_counts[class_id] += 1

    # Use the combined class map for statistics
    combined_cls_map = {}
    for chart_type, chart_cls_map in CHART_CLASS_MAPS.items():
        if chart_type != 'pie':  # Skip pie since it has empty mapping
            for id_val, class_name in chart_cls_map.items():
                if id_val not in combined_cls_map:
                    combined_cls_map[id_val] = class_name

    for class_id, class_name in sorted(combined_cls_map.items(), key=lambda x: x[1]):
        print(f"  {class_name:20s}: {class_counts[class_id]:5d} instances")

    # Merge JSON files if enabled in config
    if cfg.get('merge_json_files', False) and batch_merge_all:
        print("\n--- Merging JSON files ---")
        batch_merge_all(labels_dir)
    
    if cfg['debug_mode']:
        print("\n--- Generation complete. Running visualization script... ---")
        try:
            subprocess.run(["python", "testar.py", debug_dir, "--show"], check=True)
        except FileNotFoundError:
            print("\n[ERROR] Could not find 'python'. Make sure Python is in your system's PATH.")
        except subprocess.CalledProcessError as e:
            print(f"\n[ERROR] 'testar.py' script failed with error: {e}")
        except Exception as e:
            print(f"\n[ERROR] An unexpected error occurred while trying to run testar.py: {e}")


if __name__ == '__main__':
    main()