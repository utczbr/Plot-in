#!/usr/bin/env python3
"""
Enhanced Annotation Viewer - Usage Examples
Combines obj_labels (detection boxes) and labels (pose keypoints) visualization
"""

import os
import sys
import glob
from pathlib import Path
from enhanced_annotation_viewer import EnhancedAnnotationViewer



def example_1_single_image_dual_format():
    """Example 1: Visualize single image with both obj_labels and labels"""
    print("="*70)
    print("EXAMPLE 1: Single Image - Dual Format Visualization")
    print("="*70)

    # For bar chart
    viewer = EnhancedAnnotationViewer(img_width=1050, img_height=750, chart_type='bar')

    result = viewer.visualize_dual_annotations(
        image_path='chart_00000.png',  # Replace with your image
        obj_label_path='obj_labels/chart_00000.txt',  # Detection boxes
        pose_label_path='labels/chart_00000.txt',     # Keypoints
        output_path='output/chart_00000_dual.png',
        draw_keypoint_indices=True
    )

    print("✅ Example 1 complete\n")
    return result


def example_2_batch_processing():
    """Example 2: Batch process all images in a directory"""
    print("="*70)
    print("EXAMPLE 2: Batch Processing with Auto-Detection")
    print("="*70)

    # Setup
    base_dir = 'test_generation'  # Your dataset directory
    images_dir = os.path.join(base_dir, 'images')
    output_dir = 'output/visualized'
    os.makedirs(output_dir, exist_ok=True)

    # Chart type to directory mapping
    chart_configs = [
        ('pie_obj', 'pie_obj_labels', None),
        ('pie_pose', None, 'pie_pose_labels'),
        ('line_obj', 'line_obj_labels', None),
        ('line_pose', None, 'line_pose_labels'),
        ('area_obj', 'area_obj_labels', None),
        ('area_pose', None, 'area_pose_labels'),
    ]

    # Find all images
    image_files = []
    for ext in ['*.png', '*.jpg', '*.jpeg']:
        image_files.extend(glob.glob(os.path.join(images_dir, ext)))

    if not image_files:
        print(f"⚠ No images found in {images_dir}")
        return

    print(f"Found {len(image_files)} images")

    processed = 0
    for image_path in sorted(image_files):
        base_name = os.path.splitext(os.path.basename(image_path))[0]

        # Try each chart configuration
        for chart_type, obj_dir, pose_dir in chart_configs:
            obj_label_path = os.path.join(base_dir, obj_dir, f"{base_name}.txt") if obj_dir else None
            pose_label_path = os.path.join(base_dir, pose_dir, f"{base_name}.txt") if pose_dir else None

            # Check if at least one label file exists
            obj_exists = obj_label_path and os.path.exists(obj_label_path)
            pose_exists = pose_label_path and os.path.exists(pose_label_path)

            if obj_exists or pose_exists:
                print(f"\n📊 Processing: {base_name} ({chart_type})")

                # Get image dimensions (you might want to detect this automatically)
                from PIL import Image
                img = Image.open(image_path)
                img_width, img_height = img.size

                viewer = EnhancedAnnotationViewer(
                    img_width=img_width, 
                    img_height=img_height, 
                    chart_type=chart_type
                )

                output_path = os.path.join(output_dir, f"{base_name}_{chart_type}_annotated.png")

                viewer.visualize_dual_annotations(
                    image_path=image_path,
                    obj_label_path=obj_label_path if obj_exists else None,
                    pose_label_path=pose_label_path if pose_exists else None,
                    output_path=output_path,
                    draw_keypoint_indices=False
                )

                processed += 1

    print(f"\n✅ Processed {processed} image-label combinations")


def example_3_comparison_view():
    """Example 3: Create side-by-side comparison of obj_labels vs labels"""
    print("="*70)
    print("EXAMPLE 3: Side-by-Side Comparison")
    print("="*70)

    from PIL import Image

    image_path = 'chart_00000.png'
    obj_label_path = 'obj_labels/chart_00000.txt'
    pose_label_path = 'labels/chart_00000.txt'

    # Create viewer
    viewer = EnhancedAnnotationViewer(img_width=1050, img_height=750, chart_type='bar')

    # Visualize obj_labels only
    img1 = viewer.visualize_dual_annotations(
        image_path=image_path,
        obj_label_path=obj_label_path,
        pose_label_path=None,
        output_path='output/comparison_obj_only.png'
    )

    # Visualize labels only
    img2 = viewer.visualize_dual_annotations(
        image_path=image_path,
        obj_label_path=None,
        pose_label_path=pose_label_path,
        output_path='output/comparison_pose_only.png',
        draw_keypoint_indices=True
    )

    # Visualize both combined
    img3 = viewer.visualize_dual_annotations(
        image_path=image_path,
        obj_label_path=obj_label_path,
        pose_label_path=pose_label_path,
        output_path='output/comparison_combined.png'
    )

    # Create side-by-side comparison
    width = img1.width
    height = img1.height
    comparison = Image.new('RGB', (width * 3, height), 'white')
    comparison.paste(img1, (0, 0))
    comparison.paste(img2, (width, 0))
    comparison.paste(img3, (width * 2, 0))
    comparison.save('output/comparison_all.png')

    print("✅ Created comparison views")
    print("   - obj_only: Detection boxes only")
    print("   - pose_only: Keypoints only")
    print("   - combined: Both overlaid")
    print("   - all: Side-by-side comparison\n")


def example_4_chart_type_specific():
    """Example 4: Chart-type specific visualizations"""
    print("="*70)
    print("EXAMPLE 4: Chart Type Specific Visualizations")
    print("="*70)

    # Define the area chart configuration using available files
    area_config = {
        'image': 'images/chart_00000.png',
        'obj_labels': 'area_obj_labels/chart_00000.txt',
        'pose_labels': 'area_pose_labels/chart_00000.txt',
        'description': 'Area chart with dual-format annotation'
    }

    print(f"\n📊 {area_config['description']}")

    if os.path.exists(area_config['image']):
        from PIL import Image
        img = Image.open(area_config['image'])
        img_width, img_height = img.size

        # 1. Visualize object detection labels
        print("   - Visualizing object detection annotations...")
        viewer_obj = EnhancedAnnotationViewer(
            img_width=img_width,
            img_height=img_height,
            chart_type='area_obj'
        )
        img_with_obj = viewer_obj.visualize_dual_annotations(
            image_path=area_config['image'],
            obj_label_path=area_config['obj_labels'] if os.path.exists(area_config['obj_labels']) else None,
            pose_label_path=None,
            output_path=None  # Don't save intermediate
        )
        print("   - Visualized object detection annotations.")

        # 2. Visualize pose estimation labels on top of the previous image
        print("   - Visualizing pose estimation annotations on the same image...")
        viewer_pose = EnhancedAnnotationViewer(
            img_width=img_width,
            img_height=img_height,
            chart_type='area_pose'
        )
        output_name = f"output/area_chart_dual_annotated.png"
        viewer_pose.visualize_dual_annotations(
            image_path=img_with_obj,  # Pass the PIL image object
            obj_label_path=None,
            pose_label_path=area_config['pose_labels'] if os.path.exists(area_config['pose_labels']) else None,
            output_path=output_name,
            draw_keypoint_indices=True
        )
        print(f"   - Final image saved to {output_name}")

    else:
        print(f"⚠ Skipping area chart example - image not found at {area_config['image']}")

    print("\n✅ Example 4 complete")


def example_5_custom_workflow():
    """Example 5: Custom workflow with directory auto-detection"""
    print("="*70)
    print("EXAMPLE 5: Intelligent Directory Detection")
    print("="*70)

    def find_label_files(image_path, base_dir):
        """Intelligently find obj_labels and labels for an image."""
        base_name = os.path.splitext(os.path.basename(image_path))[0]

        # Possible label directory patterns
        patterns = [
            ('obj_labels', 'labels'), 
            ('area_obj_labels', 'area_pose_labels'),
            ('pie_obj_labels', 'pie_pose_labels'),
            ('line_obj_labels', 'line_pose_labels'),
        ]

        for obj_dir, pose_dir in patterns:
            obj_path = os.path.join(base_dir, obj_dir, f"{base_name}.txt")
            pose_path = os.path.join(base_dir, pose_dir, f"{base_name}.txt")

            if os.path.exists(obj_path) or os.path.exists(pose_path):
                # Detect chart type from directory name
                chart_type = obj_dir.replace('_obj_labels', '').replace('_labels', '')
                if chart_type == 'obj':
                    chart_type = 'bar'

                return (
                    obj_path if os.path.exists(obj_path) else None,
                    pose_path if os.path.exists(pose_path) else None,
                    chart_type
                )

        return None, None, 'bar'

    # Process images
    base_dir = 'dataset'
    images_dir = os.path.join(base_dir, 'images')
    output_dir = 'output/auto_detected'
    os.makedirs(output_dir, exist_ok=True)

    for image_path in glob.glob(os.path.join(images_dir, '*.png'))[:5]:  # First 5
        obj_labels, pose_labels, chart_type = find_label_files(image_path, base_dir)

        if obj_labels or pose_labels:
            print(f"\n📊 {os.path.basename(image_path)} -> {chart_type}")

            from PIL import Image
            img = Image.open(image_path)

            viewer = EnhancedAnnotationViewer(
                img_width=img.width,
                img_height=img.height,
                chart_type=chart_type
            )

            output_path = os.path.join(output_dir, f"{os.path.basename(image_path)}")
            viewer.visualize_dual_annotations(
                image_path=image_path,
                obj_label_path=obj_labels,
                pose_label_path=pose_labels,
                output_path=output_path
            )

    print("\n✅ Auto-detection complete")


def main():
    """Main function to run examples"""
    os.makedirs('output', exist_ok=True)

    print("\n" + "="*70)
    print("ENHANCED ANNOTATION VIEWER - USAGE EXAMPLES")
    print("="*70)

    if len(sys.argv) > 1:
        example_num = sys.argv[1]
        examples = {
            '1': example_1_single_image_dual_format,
            '2': example_2_batch_processing,
            '3': example_3_comparison_view,
            '4': example_4_chart_type_specific,
            '5': example_5_custom_workflow
        }

        if example_num in examples:
            examples[example_num]()
        else:
            print(f"❌ Invalid example number. Choose 1-5")
    else:
        print("\n📖 Available Examples:")
        print("  1. Single Image - Dual Format")
        print("  2. Batch Processing")
        print("  3. Side-by-Side Comparison")
        print("  4. Chart Type Specific")
        print("  5. Intelligent Auto-Detection")
        print("\nUsage: python usage_examples.py [1-5]")
        print("\nRunning Example 1 as default...\n")
        example_1_single_image_dual_format()


if __name__ == '__main__':
    main()
